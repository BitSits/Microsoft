﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("Per Pixel Collision")]
[assembly: AssemblyProduct("Per Pixel Collision")]
[assembly: AssemblyDescription(
   "This tutorial shows a more advanced 2D collision scenario: pixel-perfect collision logic between the player and the obstacles yields a more realistic challenge.")]
[assembly: AssemblyCompany("Microsoft")]

[assembly: AssemblyCopyright("Copyright © Microsoft 2007")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("618D7DF3-B3C7-40aa-8B67-38E2A0F975F7")]


// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
[assembly: AssemblyVersion("1.0.0.0")]
