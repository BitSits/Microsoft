﻿#region File Description
//-----------------------------------------------------------------------------
// AssemblyInfo.cs
//
// Microsoft Game Technology Group
// Copyright (C) Microsoft Corporation. All rights reserved.
//-----------------------------------------------------------------------------
#endregion

using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("Tiled Sprites")]
[assembly: AssemblyProduct("TiledSprites")]
[assembly: AssemblyDescription("This sample shows how to manage data for tiling, animation, visibility determination, and virtualization of a 2D camera.")]
[assembly: AssemblyCompany("Microsoft")]
[assembly: AssemblyCopyright
   ("Copyright © Microsoft 2008")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components. 
// This should never be true for Xbox 360 assemblies.
[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("282cd7e3-5ffc-4e65-8ac6-833b530b872f")]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
[assembly: AssemblyVersion("1.0.0.0")]