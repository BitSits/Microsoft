#region File Description
//-----------------------------------------------------------------------------
// FlockingSample.cs
//
// Microsoft XNA Community Game Platform
// Copyright (C) Microsoft Corporation. All rights reserved.
//-----------------------------------------------------------------------------
#endregion

#region Using Statements
using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
#endregion

namespace Flocking
{
    #region FlockingAIParameters
    public struct AIParameters
    {
        /// <summary>
        /// how far away the animals see each other
        /// </summary>
        public float detectionDist;
        /// <summary>
        /// seperate from animals inside this distance
        /// </summary>
        public float separationDist;
        /// <summary>
        /// how much the animal tends to move in it's previous direction
        /// </summary>
        public float moveInOldDirInfluence;
        /// <summary>
        /// how much the animal tends to move with animals in it's detection distance
        /// </summary>
        public float moveInFlockDirInfluence;
        /// <summary>
        /// how much the animal tends to move randomly
        /// </summary>
        public float moveInRandomDirInfluence;
        /// <summary>
        /// how quickly the animal can turn
        /// </summary>
        public float maxTurnRadians;
        /// <summary>
        /// how much each nearby animal influences it's behavior
        /// </summary>
        public float perMemberWeight;
        /// <summary>
        /// how much dangerous animals influence it's behavior
        /// </summary>
        public float perDangerWeight;
    }
    #endregion
    /// <summary>
    /// This is the main type for your game
    /// </summary>
    public class FlockingSample : Microsoft.Xna.Framework.Game
    {

        #region Constants
        const int screenWidth = 853;
        const int screenHeight = 480;

        /// <summary>
        /// X location to start drawing the HUD from
        /// </summary>
        const int hudLocX = 205;
        /// <summary>
        /// Y location to start drawing the HUD from
        /// </summary>
        const int hudLocY = 30;

        /// <summary>
        /// min value for the distance sliders
        /// </summary>
        float sliderMin = 0.0f;
        /// <summary>
        /// max value for the distance sliders
        /// </summary>
        float sliderMax = 100.0f;

        //default value for the AI parameters
        const float detectionDefault = 70.0f;
        const float separationDefault = 50.0f;
        const float moveInOldDirInfluenceDefault = 1.0f;
        const float moveInFlockDirInfluenceDefault = 1.0f;
        const float moveInRandomDirInfluenceDefault = 0.05f;
        const float maxTurnRadiansDefault = 6.0f;
        const float perMemberWeightDefault = 1.0f;
        const float perDangerWeightDefault = 50.0f;
        #endregion

        #region Fields
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;

        InputState inputState;

        SpriteFont hudFont;

        Texture2D bButton;
        Texture2D xButton;
        Texture2D yButton;
        Texture2D onePixelWhite;

        Texture2D birdTex;
        Texture2D catTex;

        Cat cat;
        Flock flock;

        AIParameters flockParams;

        int selectionNum;

        #endregion

        #region Initialization

        public FlockingSample()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";

            graphics.PreferredBackBufferWidth = screenWidth;
            graphics.PreferredBackBufferHeight = screenHeight;

            graphics.MinimumVertexShaderProfile = ShaderProfile.VS_1_1;
            graphics.MinimumPixelShaderProfile = ShaderProfile.PS_1_1;

            inputState = new InputState();

            flock = null;

            bButton = null;
            xButton = null;
            yButton = null;

            cat = null;

            flockParams = new AIParameters();
            ResetAIParams();
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting
        /// to run. This is where it can query for any required services and load any
        /// non-graphic related content.  Calling base.Initialize will enumerate 
        /// through any components and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            base.Initialize();
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            spriteBatch = new SpriteBatch(GraphicsDevice);

            catTex = Content.Load<Texture2D>("cat");
            birdTex = Content.Load<Texture2D>("mouse");

            bButton = Content.Load<Texture2D>("xboxControllerButtonB");
            xButton = Content.Load<Texture2D>("xboxControllerButtonX");
            yButton = Content.Load<Texture2D>("xboxControllerButtonY");

            hudFont = Content.Load<SpriteFont>("HUDFont");

            onePixelWhite = new Texture2D(
                GraphicsDevice, 1, 1, 0, TextureUsage.None, SurfaceFormat.Color);
            onePixelWhite.SetData<Color>(new Color[] { Color.White });
        }

        #endregion

        #region Handle Input
        /// <summary>
        /// Poll gamepad input
        /// </summary>
        void HandleInput(GameTime gameTime)
        {
            float elapsedTime = (float)gameTime.ElapsedGameTime.TotalSeconds;

            //do we need to update the AI parameters this frame?
            bool aiParamUpdate = false;
            inputState.Update();
            
            // Check for exit.
            if (inputState.Exit)
            {
                Exit();
            }

            //update move for the cat
            if (cat != null)
            {
                cat.HandleInput(inputState);
            }

            //turn the cat on or off
            if (inputState.ToggleCatButton)
            {
                ToggleCat();
            }
            //toggles selection of the  detection and separation distances
            if (inputState.Up)
            {
                selectionNum = (selectionNum - 1) % 2;
                if (selectionNum < 0)
                {
                    selectionNum = 1;
                }
            }
            else if (inputState.Down)
            {
                selectionNum = (selectionNum + 1) % 2;
            }

            //scale the slider movement so it's not too fast or too slow
            float sliderMoveAmout = inputState.SliderMove * elapsedTime* 50;

            if (Math.Abs(sliderMoveAmout) > 0.01f)
            {
                aiParamUpdate = true;
                switch (selectionNum)
                {
                    //detection distance
                    //detection distance cannot be less than the separation distance
                    // and cannot be greater than the slider max value
                    case 0:
                        HandleSliderInput(ref flockParams.detectionDist,
                            ref sliderMoveAmout, ref flockParams.separationDist,
                            ref sliderMax, out flockParams.detectionDist);
                        break;
                    //separation distance
                    //separation distance cannot be less than the min value and
                    //cannot be greater than the detection distance
                    case 1:
                        HandleSliderInput(ref flockParams.separationDist,
                            ref sliderMoveAmout, ref sliderMin,
                            ref flockParams.detectionDist,
                            out flockParams.separationDist);
                        break;
                }
            }

            //resets flock parameters back to default
            if (inputState.ResetDistances)
            {
                ResetAIParams();
                aiParamUpdate = true;
            }

            //resets the location and orientation of the members of the flock
            if (inputState.ResetFlock)
            {
                flock.ResetFlock();
                aiParamUpdate = true;
            }

            if (aiParamUpdate)
            {
                flock.FlockParams = flockParams;
            }
        }

        /// <summary>
        /// Increment the slider up or down while keeping it inside the bounds
        /// </summary>
        /// <param name="sliderCurrentVal">current slider value</param>
        /// <param name="sliderMoveAmout">ammount to move teh slider</param>
        /// <param name="lowerBounds">lower bounds</param>
        /// <param name="upperBounds">upper bounds</param>
        /// <param name="sliderFinalVal">final value</param>
        private static void HandleSliderInput(ref float sliderVal, 
            ref float sliderMove, ref float lowerBounds, ref float upperBounds, 
            out float sliderFinal)
        {
            float temp = sliderVal + sliderMove;
            if (temp < lowerBounds)
            {
                temp = lowerBounds;
            }
            else if (temp > upperBounds)
            {
                temp = upperBounds;
            }

            sliderFinal = temp;
        }
        #endregion

        #region Update and Draw

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            HandleInput(gameTime);

            if (cat != null)
            {
                cat.Update(gameTime);
            }

            if (flock != null)
            {
                flock.Update(gameTime, cat);
            }
            else
            {
                SpawnFlock();
            }

            base.Update(gameTime);
        }

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            graphics.GraphicsDevice.Clear(Color.CornflowerBlue);

            spriteBatch.Begin();

            if (flock != null)
            {
                flock.Draw(spriteBatch, gameTime);
            }

            if (cat != null)
            {
                cat.Draw(spriteBatch, gameTime);
            }

            //draw all the HUD elements
            DrawBar(hudLocX, hudLocY, 20, (int)sliderMax, 
                flockParams.detectionDist / sliderMax, "Detection Distance:", 
                gameTime, selectionNum == 0);
            DrawBar(hudLocX, hudLocY+25, 20, (int)sliderMax, 
                flockParams.separationDist / sliderMax, "Separation Distance:", 
                gameTime, selectionNum == 1);

            spriteBatch.Draw(bButton, 
                new Vector2(hudLocX + 110.0f, hudLocY), Color.White);
            spriteBatch.Draw(xButton, 
                new Vector2(hudLocX + 110.0f, hudLocY + 20.0f), Color.White);
            spriteBatch.Draw(yButton, 
                new Vector2(hudLocX + 110.0f, hudLocY + 40.0f), Color.White);

            spriteBatch.DrawString(hudFont, "Reset Distances", 
                new Vector2(hudLocX + 135.0f, hudLocY), Color.White);
            spriteBatch.DrawString(hudFont, "Reset flock", 
                new Vector2(hudLocX + 135.0f, hudLocY+20.0f), Color.White);
            spriteBatch.DrawString(hudFont, "Spawn/remove cat", 
                new Vector2(hudLocX + 135.0f, hudLocY+40.0f), Color.White);
            spriteBatch.End();

            base.Draw(gameTime);
        }

        /// <summary>
        /// DrawBar is a helper function used by Draw. It is used to draw the three
        /// bars which display the tank's fuzzy weights.
        /// </summary>
        private void DrawBar(int x, int y, int barHeight, int maxWidth,
            float barWidthNormalized, string label, GameTime gameTime, 
            bool highlighted)
        {
            Color tintColor = Color.White;

            // if the bar is highlighted, we want to make it pulse with a red tint.
            if (highlighted)
            {
                // to do this, we'll first generate a value t, which we'll use to
                // determine how much tint to have.
                float t = (float)Math.Sin(10 * gameTime.TotalGameTime.TotalSeconds);

                // Sin varies from -1 to 1, and we want t to go from 0 to 1, so we'll 
                // scale it now.
                t = .5f + .5f * t;

                // finally, we'll calculate our tint color by using Lerp to generate
                // a color in between Red and White.
                tintColor = new Color(Vector4.Lerp(
                    Color.Red.ToVector4(), Color.White.ToVector4(), t));
            }

            // calculate how wide the bar should be, and then draw it.
            int width = (int)(maxWidth * barWidthNormalized);
            Rectangle rectangle = new Rectangle(x, y, width, barHeight);
            spriteBatch.Draw(onePixelWhite, rectangle, tintColor);

            // finally, draw the label to the left of the bar.
            Vector2 labelSize = hudFont.MeasureString(label);
            Vector2 labelPosition = new Vector2(x - 5 - labelSize.X, y);
            spriteBatch.DrawString(hudFont, label, labelPosition, tintColor);
        }

        #endregion

        #region Methods
        /// <summary>
        /// Create the bird flock
        /// </summary>
        /// <param name="theNum"></param>
        protected void SpawnFlock()
        {
            if (flock == null)
            {
                flock = new Flock(birdTex, screenWidth, screenHeight, flockParams);
            }
        }

        /// <summary>
        /// Reset flock AI parameters
        /// </summary>
        private void ResetAIParams()
        {
            flockParams.detectionDist = detectionDefault;
            flockParams.separationDist = separationDefault;
            flockParams.moveInOldDirInfluence = moveInOldDirInfluenceDefault;
            flockParams.moveInFlockDirInfluence = moveInFlockDirInfluenceDefault;
            flockParams.moveInRandomDirInfluence = moveInRandomDirInfluenceDefault;
            flockParams.maxTurnRadians = maxTurnRadiansDefault;
            flockParams.perMemberWeight = perMemberWeightDefault;
            flockParams.perDangerWeight = perDangerWeightDefault;
        }

        /// <summary>
        /// Create or remove the cat
        /// </summary>
        protected void ToggleCat()
        {
            if (cat == null)
            {
                cat = new Cat(catTex, screenWidth, screenHeight);
            }
            else
            {
                cat = null;
            }
        }
        #endregion
    }

    #region Entry Point
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        static void Main()
        {
            using (FlockingSample game = new FlockingSample())
            {
                game.Run();
            }
        }
    }
    #endregion
}