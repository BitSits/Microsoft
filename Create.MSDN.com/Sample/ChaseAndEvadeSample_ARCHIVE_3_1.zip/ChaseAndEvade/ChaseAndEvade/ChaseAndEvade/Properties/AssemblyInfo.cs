﻿#region File Description
//-----------------------------------------------------------------------------
// AssemblyInfo.cs
//
// Copyright (C) Microsoft Corporation. All rights reserved.
//-----------------------------------------------------------------------------
#endregion

#region Using Statements
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
#endregion

//Descriptive Assembly attributes
[assembly: AssemblyTitle("Chase and Evade")]
[assembly: AssemblyProduct("Chase and Evade")]
[assembly: AssemblyDescription("Featuring a cat, a mouse, and a tank, this sample demonstrates how to implement several simple behaviors for AI, including chasing, evading, and wandering.")]
[assembly: AssemblyCompany("Microsoft Corporation")]
[assembly: AssemblyCopyright("Copyright © Microsoft 2008")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: AssemblyVersion("1.0.0.0")]

//ComVisible is false for this component.
[assembly: ComVisible(false)]
[assembly: Guid("05ab6b2b-6f7b-4b6f-8126-777b5dd4b543")]

