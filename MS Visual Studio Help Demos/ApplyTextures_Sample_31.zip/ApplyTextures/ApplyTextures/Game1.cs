﻿#region File Description
//-----------------------------------------------------------------------------
// Game1.cs
//
// Microsoft XNA Community Game Platform
// Copyright (C) Microsoft Corporation. All rights reserved.
//-----------------------------------------------------------------------------
#endregion

using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Net;
using Microsoft.Xna.Framework.Storage;

namespace ApplyTextures
{
    /// <summary>
    /// This is the main type for your game
    /// </summary>
    public class Game1 : Microsoft.Xna.Framework.Game
    {
        Matrix worldViewProjection;
        Effect effect;
        VertexDeclaration cubeVertexDeclaration;
        VertexPositionTexture[] cubeVertices;
        VertexBuffer vertexBuffer;
        IndexBuffer indexBuffer;
        short[] cubeIndices;

        GraphicsDeviceManager graphics;
        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
        }

        protected override void Initialize()
        {
            // TODO: Add your initialization logic here

            base.Initialize();
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            InitializeTransform();
            InitializeEffect();
            InitializeCube();
        }

        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }

        /// <summary>
        /// Initializes the transforms used for the 3D model.
        /// </summary>
        private void InitializeTransform()
        {
            float tilt = (float)Math.PI / 8.0f;
            // Use the world matrix to tilt the cube along x and y axes.
            Matrix world = Matrix.CreateRotationX(tilt) *
                Matrix.CreateRotationY(tilt);

            Matrix view = Matrix.CreateLookAt(new Vector3(0, 0, 10), 
                Vector3.Zero, Vector3.Up);

            Matrix projection = Matrix.CreatePerspectiveFieldOfView(
                (float)Math.PI / 4.0f,  // 2 PI Radians is 360 degrees, 
                                        // so this is 45 degrees.
                (float)GraphicsDevice.Viewport.Width /
                (float)GraphicsDevice.Viewport.Height,
                1.0f, 100.0f);

            worldViewProjection = world * view * projection;
        }

        /// <summary>
        /// Initializes the effect (loading, parameter setting, 
        /// and technique selection) used for the 3D model.
        /// </summary>
        private void InitializeEffect()
        {
            effect = Content.Load<Effect>("ReallySimpleTexture");

            Texture2D texture = Content.Load<Texture2D>("xna");

            effect.Parameters["WorldViewProj"].SetValue(worldViewProjection);
            effect.Parameters["UserTexture"].SetValue(texture);

            effect.CurrentTechnique = effect.Techniques["TransformAndTexture"];
        }

        /// <summary>
        /// Initializes the vertices and indices of the 3D model.
        /// </summary>
        public VertexPositionTexture[] InitializeCube()
        {
            // Create a vertex declaration for the VertexPositionTexture type.
            cubeVertexDeclaration = new VertexDeclaration(
                GraphicsDevice, VertexPositionTexture.VertexElements);

            // Initialize the points to be used to draw each side of the cube.
            Vector3 topLeftFront = new Vector3(-1.0f, 1.0f, 1.0f);
            Vector3 bottomLeftFront = new Vector3(-1.0f, -1.0f, 1.0f);
            Vector3 topRightFront = new Vector3(1.0f, 1.0f, 1.0f);
            Vector3 bottomRightFront = new Vector3(1.0f, -1.0f, 1.0f);
            Vector3 topLeftBack = new Vector3(-1.0f, 1.0f, -1.0f);
            Vector3 topRightBack = new Vector3(1.0f, 1.0f, -1.0f);
            Vector3 bottomLeftBack = new Vector3(-1.0f, -1.0f, -1.0f);
            Vector3 bottomRightBack = new Vector3(1.0f, -1.0f, -1.0f);

            // Initialize the texture coordinates.
            Vector2 textureTopLeft = new Vector2(0.0f, 0.0f);
            Vector2 textureTopRight = new Vector2(1.0f, 0.0f);
            Vector2 textureBottomLeft = new Vector2(0.0f, 1.0f);
            Vector2 textureBottomRight = new Vector2(1.0f, 1.0f);

            // Create an array to hold the list of vertices.  
            // This array will be used to assign data to the vertex buffer.
            cubeVertices = new VertexPositionTexture[36];

            // Vertices for the front of the cube.
            cubeVertices[0] =
                new VertexPositionTexture(
                topLeftFront, textureTopLeft); // 0
            cubeVertices[1] =
                new VertexPositionTexture(
                bottomLeftFront, textureBottomLeft); // 1
            cubeVertices[2] =
                new VertexPositionTexture(
                topRightFront, textureTopRight); // 2
            cubeVertices[3] =
                new VertexPositionTexture(
                bottomRightFront, textureBottomRight); // 3

            // Vertices for the back of the cube.
            cubeVertices[4] =
                new VertexPositionTexture(
                topLeftBack, textureTopRight); // 4
            cubeVertices[5] =
                new VertexPositionTexture(
                topRightBack, textureTopLeft); // 5
            cubeVertices[6] =
                new VertexPositionTexture(
                bottomLeftBack, textureBottomRight); //6
            cubeVertices[7] =
                new VertexPositionTexture(
                bottomRightBack, textureBottomLeft); // 7

            // Vertices for the top of the cube.
            cubeVertices[8] =
                new VertexPositionTexture(
                topLeftFront, textureBottomLeft); // 8
            cubeVertices[9] =
                new VertexPositionTexture(
                topRightBack, textureTopRight); // 9
            cubeVertices[10] =
                new VertexPositionTexture(
                topLeftBack, textureTopLeft); // 10
            cubeVertices[11] =
                new VertexPositionTexture(
                topRightFront, textureBottomRight); // 11

            // Vertices for the bottom of the cube.
            cubeVertices[12] =
                new VertexPositionTexture(
                bottomLeftFront, textureTopLeft); // 12
            cubeVertices[13] =
                new VertexPositionTexture(
                bottomLeftBack, textureBottomLeft); // 13
            cubeVertices[14] =
                new VertexPositionTexture(
                bottomRightBack, textureBottomRight); // 14
            cubeVertices[15] =
                new VertexPositionTexture(
                bottomRightFront, textureTopRight); // 15

            // Vertices for the left side of the cube.
            cubeVertices[16] =
                new VertexPositionTexture(
                topLeftFront, textureTopRight); // 16
            cubeVertices[17] =
                new VertexPositionTexture(
                bottomLeftFront, textureBottomRight); // 17
            cubeVertices[18] =
                new VertexPositionTexture(
                topRightFront, textureTopLeft); // 18
            cubeVertices[19] =
                new VertexPositionTexture(
                bottomRightFront, textureBottomLeft); // 19

            // Create a vertex buffer to hold the vertex data.
            vertexBuffer = new VertexBuffer(GraphicsDevice,
                VertexPositionTexture.SizeInBytes * cubeVertices.Length,
                BufferUsage.None
                );

            // Add the data to the vertex buffer.
            vertexBuffer.SetData<VertexPositionTexture>(cubeVertices);

            // Create indices to index into the cubeVertices array.
            cubeIndices = new short[] {
                                     0,  1,  2,  // front face 
                                     1,  3,  2,
                                     4,  5,  6,  // back face
                                     6,  5,  7,
                                     8,  9, 10,  // top face
                                     8, 11,  9,
                                    12, 13, 14,  // bottom face
                                    12, 14, 15,
                                    16, 13, 17,  // left face
                                    10, 13, 16,
                                    18, 19, 14,  // right face
                                     9, 18, 14 };

            // Create an index buffer to hold the index data.
            indexBuffer = new IndexBuffer(GraphicsDevice,
                sizeof(short) * cubeIndices.Length,
                BufferUsage.None,
                IndexElementSize.SixteenBits
                );

            // Add the data to the index buffer.
            indexBuffer.SetData<short>(cubeIndices);

            return cubeVertices;
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            // Allows the game to exit
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == 
                ButtonState.Pressed)
                this.Exit();

            // TODO: Add your update logic here

            base.Update(gameTime);
        }

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);
            GraphicsDevice.RenderState.CullMode =
                CullMode.CullClockwiseFace;

            GraphicsDevice.VertexDeclaration = cubeVertexDeclaration;
            GraphicsDevice.Indices = indexBuffer;
            GraphicsDevice.Vertices[0].SetSource(
                vertexBuffer,
                0,
                VertexPositionTexture.SizeInBytes);
            // This code would go between a device BeginScene-EndScene block.
            effect.Begin();
            foreach (EffectPass pass in effect.CurrentTechnique.Passes)
            {
                pass.Begin();

                GraphicsDevice.DrawIndexedPrimitives(
                    PrimitiveType.TriangleList,
                    0,
                    0,
                    cubeVertices.Length,
                    0,
                    12
                );

                pass.End();
            }
            effect.End();

            base.Draw(gameTime);
        }
    }
}
