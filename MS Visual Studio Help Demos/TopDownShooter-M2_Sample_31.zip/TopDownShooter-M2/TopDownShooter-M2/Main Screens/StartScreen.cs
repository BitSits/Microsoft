﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Net;
using Microsoft.Xna.Framework.Storage;
using GameStateManagement;
using System.IO;
using System.Xml.Serialization;

namespace TopDownShooterM2
{
    public class StartScreen : BackgroundScreen
    {
        Game1 Game;
        public StartScreen(Game1 game)
        {
            this.Game = game;
        }
        Rectangle uiBounds;
        Rectangle titleBounds;
        Vector2 startPos;
        Vector2 startOrigin;
        public override void Initialize()
        {
            base.Initialize();

            Viewport view = this.ScreenManager.GraphicsDevice.Viewport;
            int borderheight = (int)(view.Height * .05);
            // Deflate 10% to provide for title safe area on CRT TVs
            uiBounds = GetTitleSafeArea();

            titleBounds = new Rectangle(uiBounds.X, uiBounds.Y, uiBounds.Width,
                (int)view.Height / 2 - borderheight);

            startPos = new Vector2(uiBounds.X + uiBounds.Width / 2, 
                uiBounds.Height * .75f);

            // Play music for the title screen
            Game.audio.PlayMusic();
        }

        Texture2D title;
        SpriteFont font;
        public override void LoadContent()
        {
            title = this.ScreenManager.Game.Content.Load<Texture2D>("title");
            font = this.ScreenManager.Game.Content.Load<SpriteFont>("LargeArcade");

            startOrigin = font.MeasureString("Press Start") / 2;
            base.LoadContent();
        }
        PlayerIndex playerOne;
        bool Exiting = false;
        public override void Update(GameTime gameTime, bool otherScreenHasFocus, 
            bool coveredByOtherScreen)
        {
            if (!Exiting && InputManager.CheckPlayerOneStart(out playerOne))
            {
                Exiting = true;
                Game.TrySignIn(FinishStart);
            }
            base.Update(gameTime, otherScreenHasFocus, coveredByOtherScreen);
        }

        void FinishStart(Object sender, EventArgs e)
        {
            // Add the player as the Main player
            Game.InitializeMain(playerOne);
            // Load the main menu and exit
            this.ScreenManager.AddScreen(new MenuScreen());
            ExitScreen();
        }

        public override void Draw(GameTime gameTime)
        {
            // Draw the background first
            base.Draw(gameTime);

            // Draw the title
            SpriteBatch batch = this.ScreenManager.SpriteBatch;
            batch.Begin();
            batch.Draw(title, titleBounds, Color.LightBlue);

            float interval = 2.0f; // Two second interval
            float value = (float)Math.Cos(gameTime.TotalGameTime.TotalSeconds
                * interval);
            value = (value + 1) / 2;  // Shift the sine wave into positive 
                                      // territory, then back to 0-1 range
            Color color = new Color(value, value, value, value);

            batch.DrawString(font, "Press Start", startPos, color, 0, startOrigin, 
                2.0f, SpriteEffects.None, 0.1f);
            batch.End();

        }
    }

}
