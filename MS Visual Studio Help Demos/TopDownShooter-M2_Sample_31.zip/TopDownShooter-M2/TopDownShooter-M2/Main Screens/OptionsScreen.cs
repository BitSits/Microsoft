﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Net;
using Microsoft.Xna.Framework.Storage;
using GameStateManagement;

namespace TopDownShooterM2
{

    public class SliderComponent : DrawableGameComponent
    {
        public int SliderUnits = 10;
        public Rectangle SliderArea = new Rectangle(0, 0, 80, 28);

        private int setting = 5;
        public int SliderSetting
        {
            get { return setting; }
            set
            {
                if (value > SliderUnits)
                    setting = SliderUnits;
                else if (value < 0)
                    setting = 0;
                else
                    setting = value;
            }
        }
        public Color UnsetColor = Color.DodgerBlue;
        public Color SetColor = Color.Cyan;


        SpriteBatch batch;

        public SliderComponent(Game game, SpriteBatch batch)
            : base(game)
        {
            this.batch = batch;
        }

        public override void Initialize()
        {
            base.Initialize();
        }

        Texture2D blank;        
        Vector2 origin;
        public new void LoadContent()
        {
            blank = Game.Content.Load<Texture2D>("whitepixel");
            origin = new Vector2(0, blank.Height);
            if (batch == null)
                batch = new SpriteBatch(Game.GraphicsDevice);
            base.LoadContent();
        }

        public override void Draw(GameTime gameTime)
        {            
            batch.Begin(SpriteBlendMode.AlphaBlend);
            for (int i = 1; i <= SliderUnits; i++)
            {
                float percent = (float)i / SliderUnits;
                int height = (int)(percent * SliderArea.Height);

                int gaps = SliderUnits - 1;
                int width = (int)(SliderArea.Width / (gaps + SliderUnits));

                int x= ((i - 1) * 2 * width);

                Rectangle displayArea = new Rectangle(SliderArea.Left + x, 
                    SliderArea.Bottom, width, height);

                if (i <= setting)
                    batch.Draw(blank, displayArea, null, SetColor, 0, origin, 
                        SpriteEffects.None, 1.0f);
                else
                    batch.Draw(blank, displayArea, null, UnsetColor, 0, origin, 
                        SpriteEffects.None, 1.0f);
                
            }

            batch.End();
            base.Draw(gameTime);
        }
    }

    public enum InputMode
    {
        Normal,
        Southpaw,
    }
    public struct OptionsState
    {
        public InputMode PlayerOne;
        public InputMode PlayerTwo;
        public float FXLevel;
        public float MusicLevel;        
    }

    public delegate void OptionsSet(OptionsState state);

    public class OptionsScreen : BackgroundScreen
    {
        MenuComponent menu;
        SliderComponent volumeSlider;
        SliderComponent musicSlider;
        Vector2 playerOneStringLoc;
        Vector2 playerTwoStringLoc;
        
        OptionsState state;
        Game1 Game;

        public OptionsScreen(Game1 game, OptionsState state)
        {
            this.state = state;
            this.Game = game;
        }

        Rectangle uiBounds;
        public override void Initialize()
        {

            Viewport view = this.ScreenManager.GraphicsDevice.Viewport;
            uiBounds = GetTitleSafeArea();

            menu = new MenuComponent(this.ScreenManager.Game, 
                this.ScreenManager.Font);
            menu.Initialize();
            menu.AddText("Player One Control Scheme");
            menu.AddText("Player Two Control Scheme");
            menu.AddText("      Sound Effect Volume");
            menu.AddText("             Music Volume");
            menu.AddText("\n\r            Save and Exit");

            menu.MenuOptionSelected += new EventHandler<MenuSelection>(menu_MenuOptionSelected);
            menu.MenuCanceled += new EventHandler<MenuSelection>(menu_MenuCancelled);

            // The menu should be situated in the bottom half of the screen, centered
            menu.uiBounds = menu.Extents;
            menu.uiBounds.Offset(
                uiBounds.X + uiBounds.Width / 2 - menu.uiBounds.Width - 5,
                uiBounds.Height / 2 + (menu.uiBounds.Height / 2));
            
            

            menu.SelectedColor = Color.DodgerBlue;
            menu.UnselectedColor = Color.LightBlue;

            volumeSlider = new SliderComponent(this.ScreenManager.Game, 
                this.ScreenManager.SpriteBatch);
            volumeSlider.Initialize();
            Rectangle tempExtent = menu.GetExtent(2);  // volume menu item
            volumeSlider.SliderArea = new Rectangle(menu.uiBounds.Right + 20, 
                tempExtent.Top+4, 120, tempExtent.Height-10);
            volumeSlider.SliderUnits = 10;
            volumeSlider.SliderSetting = 
                (int) (state.FXLevel*volumeSlider.SliderUnits);
            volumeSlider.SetColor = Color.Cyan;
            volumeSlider.UnsetColor = Color.DodgerBlue;

            musicSlider = new SliderComponent(this.ScreenManager.Game, 
                this.ScreenManager.SpriteBatch);
            musicSlider.Initialize();
            tempExtent = menu.GetExtent(3);
            musicSlider.SliderArea = new Rectangle(menu.uiBounds.Right + 20, 
                tempExtent.Top + 4, 120, tempExtent.Height - 10);
            musicSlider.SliderUnits = 10;
            musicSlider.SliderSetting = 
                (int)(state.MusicLevel*musicSlider.SliderUnits);
            musicSlider.SetColor = Color.Cyan;
            musicSlider.UnsetColor = Color.DodgerBlue;

            tempExtent = menu.GetExtent(0);
            playerOneStringLoc = new Vector2(menu.uiBounds.Right + 20, 
                tempExtent.Top);

            tempExtent = menu.GetExtent(1);
            playerTwoStringLoc = new Vector2(menu.uiBounds.Right + 20, 
                tempExtent.Top);

            this.PresenceMode = GamerPresenceMode.ConfiguringSettings;

            base.Initialize();
        }

        void menu_MenuCancelled(Object sender, MenuSelection selection)
        {
            ExitScreen();
        }

        void menu_MenuOptionSelected(Object sender, MenuSelection selection)
        {
            if (menu.Selection == 4)  // Save and Exit
            {
                ExitScreen();
                Game.SetOptions(state);
            }
        }
        
        Texture2D controller;
        Texture2D inputNormal;
        Texture2D inputSouthpaw;
        public override void LoadContent()
        {
            ContentManager content = this.ScreenManager.Game.Content;
            controller = content.Load<Texture2D>("controller");
            inputNormal = content.Load<Texture2D>("InputText");
            inputSouthpaw = content.Load<Texture2D>("InputText2");

            volumeSlider.LoadContent();
            musicSlider.LoadContent();
            base.LoadContent();
        }

        InputMode displayMode;

        public override void HandleInput(InputState input)
        {
            // If they press Back or B, exit
            if (input.IsNewButtonPress(Buttons.Back) ||
                input.IsNewButtonPress(Buttons.B))
                ExitScreen();

            musicSlider.UnsetColor = menu.UnselectedColor;
            volumeSlider.UnsetColor = menu.UnselectedColor;
            switch (menu.Selection)
            {
                case 0:
                    HandlePlayerOne(input, Game.Main.Controller);
                    break;
                case 1:
                    HandlePlayerTwo(input, Game.Main.Controller);
                    break;
                case 2:
                    HandleFXAudio(input, Game.Main.Controller);
                    volumeSlider.UnsetColor = menu.SelectedColor;
                    break;
                case 3:
                    HandleMusic(input, Game.Main.Controller);
                    musicSlider.UnsetColor = menu.SelectedColor;
                    break;
                default:
                    break;
            }

            // Let the menu handle input regarding selection change
            // and the A/B/Back buttons:
            menu.HandleInput(input);

            base.HandleInput(input);
        }
        private void HandlePlayerOne(InputState input, PlayerIndex index)
        {
            if (input.IsNewButtonPress(Buttons.LeftThumbstickRight, index) ||
                input.IsNewButtonPress(Buttons.DPadRight, index))
            {
                state.PlayerOne++;
                if (state.PlayerOne > InputMode.Southpaw)
                    state.PlayerOne = InputMode.Normal;                
            }
            else if (input.IsNewButtonPress(Buttons.LeftThumbstickLeft, index) ||
                input.IsNewButtonPress(Buttons.DPadLeft, index))
            {
                state.PlayerOne--;
                if (state.PlayerOne < InputMode.Normal)
                    state.PlayerOne = InputMode.Southpaw;                    
            }
            displayMode = state.PlayerOne;
        }
        private void HandlePlayerTwo(InputState input, PlayerIndex index)
        {
            if (input.IsNewButtonPress(Buttons.LeftThumbstickRight, index) ||
                input.IsNewButtonPress(Buttons.DPadRight, index))
            {
                state.PlayerTwo++;
                if (state.PlayerTwo > InputMode.Southpaw)
                    state.PlayerTwo = InputMode.Normal;
            }
            else if (input.IsNewButtonPress(Buttons.LeftThumbstickLeft, index) ||
                input.IsNewButtonPress(Buttons.DPadLeft, index))
            {
                state.PlayerTwo--;
                if (state.PlayerTwo < InputMode.Normal)
                    state.PlayerTwo = InputMode.Southpaw;
            } 
            displayMode = state.PlayerTwo;
        }
        private void HandleFXAudio(InputState input, PlayerIndex index)
        {
            if (input.IsNewButtonPress(Buttons.LeftThumbstickRight, index) ||
                input.IsNewButtonPress(Buttons.DPadRight, index))
            {
                volumeSlider.SliderSetting++;
            }
            else if (input.IsNewButtonPress(Buttons.LeftThumbstickLeft, index) ||
                input.IsNewButtonPress(Buttons.DPadLeft, index))
            {
                volumeSlider.SliderSetting--;
            }


        }
        private void HandleMusic(InputState input, PlayerIndex index)
        {
            if (input.IsNewButtonPress(Buttons.LeftThumbstickRight, index) ||
                input.IsNewButtonPress(Buttons.DPadRight, index))
            {
                musicSlider.SliderSetting++;
            }
            else if (input.IsNewButtonPress(Buttons.LeftThumbstickLeft, index) ||
                input.IsNewButtonPress(Buttons.DPadLeft, index))
            {
                musicSlider.SliderSetting--;
            }
        }

        public override void Update(GameTime gameTime, bool otherScreenHasFocus, 
            bool coveredByOtherScreen)
        {
            state.FXLevel = volumeSlider.SliderSetting / 
                (float)musicSlider.SliderUnits;
            state.MusicLevel = musicSlider.SliderSetting / 
                (float)musicSlider.SliderUnits;
            base.Update(gameTime, otherScreenHasFocus, coveredByOtherScreen);
        }

        public override void Draw(GameTime gameTime)
        {
            base.Draw(gameTime);
            
            SpriteBatch batch = this.ScreenManager.SpriteBatch;

            batch.Begin(SpriteBlendMode.AlphaBlend);

            DrawControllerString(batch, playerOneStringLoc, state.PlayerOne, 
                menu.Selection == 0);
            DrawControllerString(batch, playerTwoStringLoc, state.PlayerTwo, 
                menu.Selection == 1);
            DrawController(batch, uiBounds);
            DrawBorder(batch, uiBounds, Color.DodgerBlue);
            batch.End();

            menu.Draw(gameTime);
            volumeSlider.Draw(gameTime);
            musicSlider.Draw(gameTime);
        }

        private void DrawControllerString(SpriteBatch batch, Vector2 pos, 
            InputMode inputMode, bool highlight)
        {
            string text = "<  Normal  >";
            if (inputMode == InputMode.Southpaw)
                text = "< Southpaw >";

            Color color = menu.UnselectedColor;
            if (highlight)
                color = menu.SelectedColor;

            batch.DrawString(this.ScreenManager.Font, text, pos, color);
        }

        private Vector2 DrawController(SpriteBatch batch, Rectangle UIbounds)
        {
            Vector2 CenterTop = new Vector2(UIbounds.Width / 2 + UIbounds.Left, 
                UIbounds.Height / 4 + UIbounds.Top);
            Vector2 origin = new Vector2(controller.Width / 2, controller.Height / 2);
            batch.Draw(controller, CenterTop, null, Color.White, 0, 
                origin, 1.0f, SpriteEffects.None, 1.0f);
            if (displayMode == InputMode.Normal)
                batch.Draw(inputNormal, CenterTop, null, Color.DodgerBlue, 0, 
                    origin, 1.0f, SpriteEffects.None, 1.0f);
            else
                batch.Draw(inputSouthpaw, CenterTop, null, Color.DodgerBlue, 0, 
                    origin, 1.0f, SpriteEffects.None, 1.0f);

            return CenterTop;
        }

       
    }
}
