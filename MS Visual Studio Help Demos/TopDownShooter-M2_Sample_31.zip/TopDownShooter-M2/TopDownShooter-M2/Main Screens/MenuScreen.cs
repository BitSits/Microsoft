﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Net;
using Microsoft.Xna.Framework.Storage;
using GameStateManagement;

namespace TopDownShooterM2
{
    // Used by the Menu event handlers to get the menu selection.
    public class MenuSelection : EventArgs
    {
        private int m_selection;

        public MenuSelection(int s)
        {
            m_selection = s;
        }

        public int Selection
        {
            get { return m_selection; }
            set { m_selection = value; }
        }
    }

    public class MenuComponent : DrawableGameComponent
    {
        private SpriteBatch batch;
        public MenuComponent(Game game)
            : base(game)
        {
            this.MenuItems = new List<string>();
            this.HelpText = new List<string>();
            this.ItemHeights = new List<int>();
            this.ItemWidths = new List<int>();
        }
        public MenuComponent(Game game, SpriteFont font)
            : this(game)
        {
            this.Font = font;
        }
        public MenuComponent(Game game, SpriteFont font, SpriteBatch batch)
            : this(game, font)
        {
            this.batch = batch;
        }
        public MenuComponent(Game game, SpriteFont font, SpriteBatch batch, 
            Rectangle bounds)
            : this(game, font, batch)
        {
            this.uiBounds = bounds;
        }

        private List<string> MenuItems;
        private List<string> HelpText;
        private List<int> ItemHeights;
        private List<int> ItemWidths;

        //public Vector2 TopLeft;
        public Rectangle uiBounds;
        public SpriteFont Font;
        public Color SelectedColor = Color.White;
        public Color UnselectedColor = Color.LightGray;
        public int Selection = 0;
        public PlayerIndex Controller;

        public int Count
        {
            get { return MenuItems.Count; }
        }
        public void Clear()
        {
            MenuItems.Clear();
            HelpText.Clear();
            ItemHeights.Clear();
            ItemWidths.Clear();

            Selection = 0;
        }
        public void AddText(string menu, string help)
        {
            MenuItems.Add(menu);
            HelpText.Add(help);
            Vector2 result = Font.MeasureString(menu + help);
            ItemHeights.Add(RoundUp(result.Y));
            ItemWidths.Add(RoundUp(result.X));
        }
        public void AddText(string menu)
        {
            AddText(menu, "");
        }
        public void RemoveAt(int index)
        {
            MenuItems.RemoveAt(index);
            HelpText.RemoveAt(index);
            ItemHeights.RemoveAt(index);
            ItemWidths.RemoveAt(index);
        }

        public event EventHandler<MenuSelection> MenuOptionSelected;
        public event EventHandler<MenuSelection> MenuCanceled; 

        protected override void LoadContent()
        {
            if (batch == null)
                batch = new SpriteBatch(GraphicsDevice);

            base.LoadContent();            
        }

        public void HandleInput(InputState input)
        {
            // If back or B are pressed, cancel menu
            if (input.IsNewButtonPress(Buttons.B) ||
                input.IsNewButtonPress(Buttons.Back))
            {
                MenuCanceled.Invoke(this, new MenuSelection(-1));
                return;
            }

            if (input.IsNewButtonPress(Buttons.A))
            {
                if (MenuOptionSelected != null)
                    MenuOptionSelected(this, new MenuSelection(Selection));

                return;
            }

            if (input.IsNewButtonPress(Buttons.DPadDown) ||
                input.IsNewButtonPress(Buttons.LeftThumbstickDown))
            {
                Selection++;
            }
            if (input.IsNewButtonPress(Buttons.DPadUp) ||
                input.IsNewButtonPress(Buttons.LeftThumbstickUp))
            {
                Selection--;
            }

            if (Selection >= MenuItems.Count)
                Selection -= MenuItems.Count;
            if (Selection < 0)
                Selection += MenuItems.Count;
        }

        private static int RoundUp(float value)
        {
            int retval = (int)value;
            if (value > retval)
                retval++;
            return retval;
        }



        // Get the menu size, in pixels
        public Rectangle Extents
        {
            get
            {
                int width = 0;
                int height = 0;
                for (int i = 0; i < MenuItems.Count; i++)
                {
                    // Take the width of the widest string
                    width = Math.Max(width, ItemWidths[i]);
                    // Combined with the height of all the strings
                    height += ItemHeights[i];
                }
                return new Rectangle(uiBounds.X, uiBounds.Y, width, height);
            }
        }
        public Rectangle GetExtent(int index)
        {
            int totalheight = 0;
            for (int i = 0; i < index; i++)
            {
                totalheight += ItemHeights[i];
            }
            return new Rectangle(uiBounds.X, uiBounds.Y + totalheight, 
                ItemWidths[index], ItemHeights[index]);
        }
        private Viewport CreateViewport()
        {
            Viewport view = new Viewport(); // create a new viewport
            view.X = uiBounds.X;       // using our UIBounds
            view.Y = uiBounds.Y;
            view.Width = uiBounds.Width;
            view.Height = uiBounds.Height;
            return view;
        }
        /// <summary>
        /// Center the menu in a given viewport
        /// </summary>
        /// <param name="view">The viewport to center inside</param>
        public void CenterMenu(Viewport view)
        {
            Vector2 centerView = new Vector2(view.X + (view.Width / 2),
                view.Y + (view.Height / 2));
            Rectangle bounds = Extents;
            bounds.X = 0;
            bounds.Y = 0;
            bounds.Offset((int)(centerView.X - (bounds.Width / 2)),
                (int)(centerView.Y - (bounds.Height / 2)));
            this.uiBounds = bounds;            
        }

        private Vector2 GetTopLeft()
        {
            int selectheight = ItemHeights[Selection];
            int aboveheight = 0;
            int belowheight = 0;
            for (int i = 0; i < Selection; i++)
            {
                aboveheight += ItemHeights[i];
            }
            for (int i = Selection + 1; i < ItemHeights.Count; i++)
            {
                belowheight += ItemHeights[i];
            }
            int totalheight = selectheight + aboveheight + belowheight;

            // If there aren't enough items above to be worth scrolling down
            if (aboveheight + (selectheight / 2) <= uiBounds.Height / 2)
            {
                // Display the menu with no scrolling
                return new Vector2(0, 0);
            }
            // or if there aren't enough items below to be worth scrolling up
            else if (belowheight + (selectheight / 2) < uiBounds.Height / 2)
            {
                // Display the menu scrolled to the bottom
                return new Vector2(0, uiBounds.Height - totalheight);
            }
            else
            {
                // scroll the display to put the selection near the center   
                int temp = aboveheight + (selectheight / 2);
                return new Vector2(0, uiBounds.Height / 2 - temp);
            }


        }

        public override void Draw(GameTime gameTime)
        {
            if (Count == 0)
                return;

            Vector2 current = GetTopLeft();

            /* Setup a viewport so that we don't draw past
             * the UIBounds set for us
             */

            Viewport oldv = Game.GraphicsDevice.Viewport;  // cache the current viewport
            Game.GraphicsDevice.Viewport = CreateViewport();  // set viewport to our UIBounds

            batch.Begin(SpriteBlendMode.AlphaBlend);

            for (int i = 0; i < MenuItems.Count; i++)
            {
                if (Selection == i)
                {
                    batch.DrawString(Font, MenuItems[i] + HelpText[i], 
                        current, SelectedColor);
                }
                else
                {
                    batch.DrawString(Font, MenuItems[i], 
                        current, UnselectedColor);
                }

                current.Y += ItemHeights[i];
            }

            batch.End();


            GraphicsDevice.Viewport = oldv;  // return to the old viewport
            base.Draw(gameTime);
        }
    }

    public class MenuScreen : BackgroundScreen
    {
        Rectangle uiBounds;
        Rectangle titleBounds;
        Vector2 selectPos;

        Texture2D title;
        Texture2D btnA;

        public MenuScreen()
        {
        }

        private MenuComponent menu;
        public override void Initialize()
        {
            Viewport view = this.ScreenManager.GraphicsDevice.Viewport;
            int borderheight = (int)(view.Height * .05);

            // Deflate 10% to provide for title safe area on CRT TVs
            uiBounds = GetTitleSafeArea();

            titleBounds = new Rectangle(uiBounds.X, uiBounds.Y, uiBounds.Width,
                (int)view.Height / 2 - borderheight);
            //titleBounds.Inflate(0, (int)(-view.Height * .4));

            selectPos = new Vector2(uiBounds.X + uiBounds.Width / 2 - 50, 
                uiBounds.Bottom - 30);

            menu = new MenuComponent(this.ScreenManager.Game, 
                this.ScreenManager.Font);

            //Initialize Main Menu
            menu.Initialize();

            menu.AddText("  Local Game", 
                " - Up to two players on this console");
            menu.AddText("     Options", 
                " - Change volume levels or controller configuration");
            menu.AddText("        Help", 
                " - How to play");
            menu.AddText("        Quit", 
                " - Return to Arcade");
            menu.uiBounds = menu.Extents;
            menu.uiBounds.Offset(uiBounds.X, titleBounds.Bottom + 60);
            menu.SelectedColor = Color.LightBlue;
            menu.MenuOptionSelected += new EventHandler<MenuSelection>(menu_MenuOptionSelected);
            menu.MenuCanceled += new EventHandler<MenuSelection>(menu_MenuCanceled);

            this.PresenceMode = GamerPresenceMode.AtMenu;

            base.Initialize();
        }

        void menu_MenuCanceled(Object sender, MenuSelection selection)
        {
            // If they hit B or Back, go back to Start Screen
            ExitScreen();
            ScreenManager.AddScreen(new StartScreen((Game1)ScreenManager.Game));
        }
        void menu_MenuOptionSelected(Object sender, MenuSelection selection)
        {
            switch (selection.Selection)
            {
                case 0: // Local Game
                    ExitScreen();
                    ((Game1)this.ScreenManager.Game).BeginSinglePlayer();
                    break;
                case 1: // Options       
                    ((Game1)this.ScreenManager.Game).DisplayOptions();
                    break;
                case 2: // Help
                    ScreenManager.AddScreen(new HelpScreen());
                    break;
                case 3: // Quit
                    this.ScreenManager.Game.Exit();
                    break;
                default:
                    break;
            }
        }
        
        public override void LoadContent()
        {
            title = this.ScreenManager.Game.Content.Load<Texture2D>("title");
            btnA = this.ScreenManager.Game.Content.Load<Texture2D>(
                "xboxControllerButtonA");

            base.LoadContent();
        }

        public override void HandleInput(InputState input)
        {
            menu.HandleInput(input);
            base.HandleInput(input);
        }

        public override void Update(GameTime gameTime, bool otherScreenHasFocus, 
            bool coveredByOtherScreen)
        {
            if (!coveredByOtherScreen && !Guide.IsVisible)
            {
                menu.Update(gameTime);
            }
            base.Update(gameTime, otherScreenHasFocus, coveredByOtherScreen);
        }

        public override void Draw(GameTime gameTime)
        {
            base.Draw(gameTime);

            this.ScreenManager.SpriteBatch.Begin();
            this.ScreenManager.SpriteBatch.Draw(title, titleBounds, Color.LightBlue);
            this.ScreenManager.SpriteBatch.End();

            menu.Draw(gameTime);

            DrawSelect(selectPos, this.ScreenManager.SpriteBatch);
        }

        private void DrawSelect(Vector2 pos, SpriteBatch batch)
        {
            batch.Begin(SpriteBlendMode.AlphaBlend);
            batch.DrawString(this.ScreenManager.Font, "Select", pos, Color.White);
            pos.X += 76;
            pos.Y -= 3;
            batch.Draw(btnA, pos, null, Color.White, 0, Vector2.Zero, 0.33f, 
                SpriteEffects.None, 1.0f);
            batch.End();
        }
    }

}
