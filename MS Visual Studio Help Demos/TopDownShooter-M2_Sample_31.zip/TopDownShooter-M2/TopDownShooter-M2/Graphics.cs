﻿#region File Description
//-----------------------------------------------------------------------------
// Game1.cs
//
// Microsoft XNA Community Game Platform
// Copyright (C) Microsoft Corporation. All rights reserved.
//-----------------------------------------------------------------------------
#endregion

using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using GameStateManagement;

namespace TopDownShooterM2
{
    public sealed class Explosion
    {
        private static Texture2D texture;
        public static Texture2D Texture
        {
            get { return texture; }
            set { texture = value; }
        }
        private Explosion() { }
        public static void Draw(SpriteBatch batch, Vector2 pos, float rotation, double totalSeconds, double startSeconds, double endSeconds)
        {
            // If the explosion is finished, or hasn't started yet, return
            if ((totalSeconds > endSeconds) || (startSeconds > totalSeconds))
                return;

            double duration = endSeconds - startSeconds;
            double time = totalSeconds - startSeconds;
            
            // The explosion gets bigger as time goes on
            float scale = (float) ((time / duration)*.5f) + .6f;

            Vector2 origin = new Vector2(texture.Height / 2);
            
            // The explosion gets brighter as time goes on
            float intensity = (float)(time / duration) * .5f;
            Vector4 colorval = new Vector4(0.75f + intensity);

            // The explosion also fades in and out
            colorval.W = (float)Math.Sin((time / duration) * MathHelper.Pi)+.2f;

            // The intensity and fade determines our tint color
            Color color = new Color(colorval);

            // Draw the texture with the appropriate scale and tint
            batch.Draw(texture, pos, null, color, rotation, origin, scale, SpriteEffects.None, 0.5f);            
        }
    }

    public class ScrollingBackground
    {
        private Vector2 screenpos, origin, texturesize;
        private Texture2D mytexture;
        private int screenheight;
        public void Load(GraphicsDevice device, Texture2D backgroundTexture)
        {
            mytexture = backgroundTexture;
            screenheight = device.Viewport.Height;
            int screenwidth = device.Viewport.Width;
            // Set the origin so that we're drawing from the 
            // center of the top edge.
            origin = new Vector2(mytexture.Width / 2, 0);
            // Set the screen position to the center of the screen.
            screenpos = new Vector2(screenwidth / 2, screenheight / 2);
            // Offset to draw the second texture, when necessary.
            texturesize = new Vector2(0, mytexture.Height);
        }
        public void Update(float deltaY)
        {
            screenpos.Y += deltaY;
            screenpos.Y = screenpos.Y % mytexture.Height;
        }
        public void Draw(SpriteBatch batch, Color color)
        {
            // Draw the texture, if it is still onscreen.
            if (screenpos.Y < screenheight)
            {
                batch.Draw(mytexture, screenpos, null,
                     color, 0, origin, 1, SpriteEffects.None, 0f);
            }
            // Draw the texture a second time, behind the first,
            // to create the scrolling illusion.
            batch.Draw(mytexture, screenpos - texturesize, null,
                 color, 0, origin, 1, SpriteEffects.None, 0f);
        }
    }

    public class BackgroundScreen : GameScreen
    {
        ScrollingBackground stars;
        ScrollingBackground dust;
        Texture2D corner;
        Texture2D border;
        bool isBackgroundOn;

        public BackgroundScreen()
        {
            stars = new ScrollingBackground();
            dust = new ScrollingBackground();
        }

        public override void Initialize()
        {
            isBackgroundOn = true;
            base.Initialize();
        }

        public override void LoadContent()
        {
            corner = this.ScreenManager.Game.Content.Load<Texture2D>("corner");
            border = this.ScreenManager.Game.Content.Load<Texture2D>("border");
            stars.Load(this.ScreenManager.GraphicsDevice, 
                this.ScreenManager.Game.Content.Load<Texture2D>("starfield"));
            dust.Load(this.ScreenManager.GraphicsDevice, 
                this.ScreenManager.Game.Content.Load<Texture2D>("clouds3"));
            base.LoadContent();
        }

        public float BackgroundDriftRatePerSec = 64.0f;

        public Rectangle GetTitleSafeArea()
        {
            PresentationParameters pp = 
                this.ScreenManager.GraphicsDevice.PresentationParameters;
            Rectangle retval = 
                new Rectangle(0, 0, pp.BackBufferWidth, pp.BackBufferHeight);
#if XBOX          
            int offsetx = (pp.BackBufferWidth + 9) / 10;
            int offsety = (pp.BackBufferHeight + 9) / 10;
#else
            int offsetx = 10;
            int offsety = 10;
#endif
            retval.Inflate(-offsetx, -offsety);  // Deflate the rectangle
            //retval.Offset(offsetx, offsety);  // Recenter the rectangle
            return retval;
        }

        public Rectangle GetTitleSafeRect(Rectangle view)
        {
            // Return the part of the incoming rectangle that is within
            // the title safe area
            return Rectangle.Intersect(view, GetTitleSafeArea());
        }

        public void DrawBorder(SpriteBatch batch, Rectangle uiBounds, Color color)
        {
            Vector2 TopLeft = new Vector2(uiBounds.Left, uiBounds.Top);
            Vector2 BottomRight = new Vector2(uiBounds.Right, uiBounds.Bottom);
            Vector2 BottomLeft = new Vector2(uiBounds.Left, uiBounds.Bottom);
            Vector2 TopRight = new Vector2(uiBounds.Right, uiBounds.Top);

            int cornerSize = 20;
            Rectangle LeftBorder = new Rectangle(uiBounds.Left - 1, 
                uiBounds.Top + cornerSize, 3, uiBounds.Height - cornerSize * 2);
            Rectangle UpperBorder = new Rectangle(uiBounds.Left + cornerSize, 
                uiBounds.Top + 2, 3, uiBounds.Width - cornerSize * 2);
            // Draw corners
            batch.Draw(corner, TopLeft, color);
            batch.Draw(corner, TopRight, null, color, MathHelper.PiOver2, 
                Vector2.Zero, 1.0f, SpriteEffects.None, 1.0f);
            batch.Draw(corner, BottomRight, null, color, MathHelper.Pi, 
                Vector2.Zero, 1.0f, SpriteEffects.None, 1.0f);
            batch.Draw(corner, BottomLeft, null, color, MathHelper.PiOver2 * 3, 
                Vector2.Zero, 1.0f, SpriteEffects.None, 1.0f);

            // Draw connective border
            batch.Draw(border, LeftBorder, null, color, 0, Vector2.Zero, 
                SpriteEffects.None, 1.0f);
            LeftBorder.X = uiBounds.Right - 2;
            batch.Draw(border, LeftBorder, null, color, 0, Vector2.Zero, 
                SpriteEffects.None, 1.0f);
            batch.Draw(border, UpperBorder, null, color, -MathHelper.PiOver2, 
                Vector2.Zero, SpriteEffects.None, 1.0f);
            UpperBorder.Y = uiBounds.Bottom + 1;
            batch.Draw(border, UpperBorder, null, color, -MathHelper.PiOver2, 
                Vector2.Zero, SpriteEffects.None, 1.0f);
        }
        public override void Update(GameTime gameTime, bool otherScreenHasFocus, 
            bool coveredByOtherScreen)
        {
            stars.Update(BackgroundDriftRatePerSec * 
                (float)gameTime.ElapsedGameTime.TotalSeconds * 0.25f);
            dust.Update(BackgroundDriftRatePerSec * 
                (float)gameTime.ElapsedGameTime.TotalSeconds * 2);

            base.Update(gameTime, otherScreenHasFocus, coveredByOtherScreen);
        }

        public override void Draw(GameTime gameTime)
        {
            if (isBackgroundOn)
            {
                this.ScreenManager.SpriteBatch.Begin();

                stars.Draw(this.ScreenManager.SpriteBatch, Color.White);
                dust.Draw(this.ScreenManager.SpriteBatch, Color.Purple);

                this.ScreenManager.SpriteBatch.End();
            }

            base.Draw(gameTime);
        }

    }
}
