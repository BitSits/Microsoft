﻿#region File Description
//-----------------------------------------------------------------------------
// Game1.cs
//
// Microsoft XNA Community Game Platform
// Copyright (C) Microsoft Corporation. All rights reserved.
//-----------------------------------------------------------------------------
#endregion

using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Net;
using Microsoft.Xna.Framework.Storage;
using GameStateManagement;
using System.IO;
using System.Xml.Serialization;

namespace TopDownShooterM2
{
   
    public struct NeutralInput
    {
        public Vector2 StickMovement;
        public bool Fire;
    }

    /// <summary>
    /// This is the main type for your game
    /// </summary>
    public class Game1 : Microsoft.Xna.Framework.Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;

        // Game data
        public Enemies enemies;
        public Avatar[] ships;
        public float TotalGameSeconds;

        /// <summary>
        /// Player who controls the interface.  This is the lowest connected 
        /// numbered controller at startup time.
        /// </summary>
        public Player Main;  

        /// <summary>
        /// Player who joins the game.  This is a second controller.        
        /// </summary>
        public Player Guest;
        private const int PlayerMax = 2;

        public ScreenManager screenManager;
        GamePlayScreen playScreen;
        public static float BackgroundDriftRatePerSec = 64.0f;

        /// <summary>
        /// This is the class that handles our gameplay calculations,
        /// such as collision, death, spawning new enemies, etc.
        /// </summary>
        public GamePlayHost host;

        private bool bPaused = false;
        private bool bStateReady = false;

        /// <summary>
        /// This is our set of player options (music level, etc).
        /// </summary>
        private OptionsState options;
        public OptionsState Options
        {
            get { return options; }
        }
        /// <summary>
        /// This component manages our sounds, and updates the
        /// audio stack once per frame.
        /// </summary>
        public AudioManager audio;
        
        /// <summary>
        /// This component manages our raw input from the
        /// controllers.
        /// </summary>
        public InputManager input;
                
        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            graphics.PreferredBackBufferHeight = 576;
            graphics.PreferredBackBufferWidth = 1024;

            Content.RootDirectory = "Content";

            options = new OptionsState();

            // Create the screen manager component.
            screenManager = new ScreenManager(this);
            Components.Add(screenManager);
            screenManager.TraceEnabled = true;

            // This object handles game logic
            host = new GamePlayHost(this);

            // This gives us access to the guide
            Components.Add(new GamerServicesComponent(this));

            // This component handles audio playback
            audio = new AudioManager(this);
            Components.Add(audio);

            // This component keeps track of controllers for us
            input = new InputManager(this);
            Components.Add(input);

            Main = new Player();
            Guest = new Player();

        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {            
            ships = new Avatar[PlayerMax];
            for (int i = 0; i < PlayerMax; i++)
            {                
                ships[i] = new Avatar();
                ships[i].Initialize(GraphicsDevice.Viewport);
            }
            enemies = new Enemies();
            Enemies.Initialize(GraphicsDevice.Viewport, Content);

            try
            {
                base.Initialize();
            }
            catch (GamerServicesNotAvailableException e)
            {
                System.Console.Error.WriteLine(e.Message);
                // TODO: add event-handling code here.
                this.Exit();
                return;
            }
            
            // Load any options settings stored in the title location
            LoadOptions();

            // Bring up the Start screen
            screenManager.AddScreen(new StartScreen(this));
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);
        }

        /// <summary>
        /// This property allows us to play an audio trick;
        /// playing the seeker sound no matter how many are
        /// onscreen - until they all die or the game is reset.
        /// </summary>
        private int activeSeekers;
        private int ActiveSeekers
        {
            get { return activeSeekers; }
            set
            {
                activeSeekers = value;
                if (activeSeekers < 1)
                    audio.StopSeeker();
            }
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {

            if (!bPaused && bStateReady)
            {
                TotalGameSeconds += (float)gameTime.ElapsedGameTime.TotalSeconds;

                ships[0].Update(TotalGameSeconds);
                ships[1].Update(TotalGameSeconds);

                enemies.Update(TotalGameSeconds);

                host.Update(gameTime);

                // Which type of screen is on top?
                GamerPresenceMode mode = 
                    this.screenManager.GetScreens()[0].PresenceMode;
                Main.SetPresence(mode);
                Guest.SetPresence(mode);
            }

            // This will update our current screen, plus audio, 
            // network, and input components
            base.Update(gameTime);
        }

        #region Start Games

        public void InitializeMain(PlayerIndex index)
        {
            if (!Main.IsPlaying)
            {
                SignedInGamer gamer = NetworkManager.FindGamer(index);
                if (gamer == null)  // No signed in gamer on this controller
                    Main.InitLocal(index, "Player One", InputMode.Normal);
                else
                {
                    Main.InitFromGamer(gamer);
                    LoadOptions();
                }
            }
        }

        public void InitializeGuest(PlayerIndex index)
        {
            if (!Guest.IsPlaying)
            {
                SignedInGamer gamer = NetworkManager.FindGamer(index);
                if (gamer == null)
                    Guest.InitLocal(index, "Player Two", InputMode.Normal);
                else
                    Guest.InitFromGamer(gamer);

                ships[1].Activate(Guest);
            }
        }

        public void BeginSinglePlayer()
        {            
            Reset();

            // Get our players and ships setup properly
            ships[0].Activate(Main);
            ships[1].Player = Guest;
            bStateReady = true;

            host.StartGame();
            playScreen = new GamePlayScreen(this);                       
            screenManager.AddScreen(playScreen);
        }

        /// <summary>
        /// This method is called to reset game stats so a new game starts
        /// cleanly.
        /// </summary>
        public void Reset()
        {
            TotalGameSeconds = 0;
            ships[0].Reset(Color.Red);
            ships[1].Reset(Color.Green);
            enemies.Reset();
            host.Reset();
        }

        /// <summary>
        /// This method is called to restart an existing game.
        /// Player information remains the same
        /// </summary>
        public void Restart()
        {
            ships[0].Restart();
            ships[0].Activate(Main);
            ships[1].Restart();
            if (Guest.IsPlaying)
                ships[1].Activate(Guest);

            TotalGameSeconds = 0;
            playScreen.bGameOver = false;
            enemies.Reset();
            host.Reset();
        }


        #endregion

        #region Host and Screen events

        public void SeekerMoved(byte seeker, Vector2 pos, float angle)
        {
            enemies.seekers[seeker].position = pos;
            enemies.seekers[seeker].angle = angle;
        }

        public void GameOver(byte player)
        {
            PlayerDestroyed(player);
            playScreen.bGameOver = true;
        }

        public void EnemyKilled(byte index, byte player)
        {
            enemies.DestroyEnemy(TotalGameSeconds, index);
            ships[player].score += 10;
            audio.PlayExplosion();
        }

        public void SpawnNextSeeker()
        {
            enemies.SpawnSeeker();
            audio.PlaySeeker();
            ActiveSeekers++;
        }

        public void SeekerCrashed(byte index)
        {
            enemies.CrashSeeker(TotalGameSeconds, index);
            ActiveSeekers--;
        }

        public void IncreaseLife(byte player)
        {
            ships[player].lives++;
        }

        public void SeekerDestroyed(byte index)
        {
            enemies.DestroySeeker(TotalGameSeconds, index);
            ActiveSeekers--;
            audio.PlayExplosion();
        }

        public void PlayerDestroyed(byte player)
        {
            ships[player].DestroyShip(TotalGameSeconds);
            ships[player].lives--;
            audio.PlayExplosion();
        }

        public void IncreaseScore(byte player, short amount)
        {
            ships[player].score += amount;

        }
        public void SpawnNextWave(float totalGameSeconds)
        {
            enemies.SpawnNextWave(totalGameSeconds);
        }

        public void ShipMove(byte player, Vector2 pos)
        {
            ships[player].position = pos;
        }

        public void ShipFire(byte player, float totalGameSeconds)
        {
            ships[player].bullets.Add(new Vector3(ships[player].position,
                totalGameSeconds));
            audio.PlayShot();

            input.PlayShot(player);
        }
        #endregion


        public void TrySignIn(EventHandler handler)
        {
            // Prompt for sign in if nobody is signed in
            if (SignedInGamer.SignedInGamers.Count == 0)
            {
                SignInScreen screen = new SignInScreen(1, true);
                screen.ScreenFinished += new EventHandler(handler);
                screenManager.AddScreen(screen);
            }
            else
            {
                handler.Invoke(this, null);
            }
        }

        /// <summary>
        /// This method is called when there's a catastrophic network
        /// error.  It removes any running screens, tries to cleanup
        /// state, and goes back to the main menu.
        /// </summary>
        public void FailToMenu()
        {
            // Remove any screens
            foreach (GameScreen item in screenManager.GetScreens())
            {
                screenManager.RemoveScreen(item);
            }
            QuitGame();
        }

        /// <summary>
        /// This method is called to end a network or single player
        /// game underway and go back to the main screen.
        /// </summary>
        public void QuitGame()
        {
            Reset();
            host.EndGame();
            playScreen = null;
            screenManager.AddScreen(new MenuScreen());
        }

        #region Setting Options
        public void DisplayOptions()
        {
            screenManager.AddScreen(new OptionsScreen(this, options));
        }

        public void SetOptions(OptionsState state)
        {
            this.options = state;

            // Reassign gamer preferences
            Main.Options = state.PlayerOne;
            Guest.Options = state.PlayerTwo;            
            
            // Change audio levels
            audio.SetOptions(state.FXLevel, state.MusicLevel);

            // If we know what the player One storage device is, we call 
            // FinishSetOptions directly.  If not, we need to prompt for it, 
            // after which it will call FinishSetOptions for us.
            if ((Main.Device == null) || (!Main.Device.IsConnected))
                Guide.BeginShowStorageDeviceSelector(Main.Controller, 
                    FinishSetOptions, null);
            else
                FinishSetOptions(null);
        }
        private void FinishSetOptions(IAsyncResult ar)
        {
            // If ar is null, assume we have a device already
            if (ar != null)
                Main.Device = Guide.EndShowStorageDeviceSelector(ar);

            // In case the user prompted did not supply a valid storage device, save
            // options to title storage.
            string path = Path.Combine(StorageContainer.TitleLocation, "options.xml");
            StorageContainer container = null;
            // If they did supply a valid storage device, save options in a container
            if (Main.Device != null)
            {
                container = Main.Device.OpenContainer("TopdownShooter");
                path = Path.Combine(container.Path, "options.xml");
            }

            XmlSerializer serializer = new XmlSerializer(typeof(OptionsState));

            FileStream file = File.Open(path, FileMode.Create);
            serializer.Serialize(file, this.options);
            file.Close();
            if (container != null)
                container.Dispose();
        }
        public void LoadOptions()
        {
            // If we know what the player One storage device is, we call 
            // FinishLoadOptions directly.  If not, we need to prompt for it, 
            // after which the Guide will call FinishLoadOptions for us.
            if ((Main.Device == null) || (!Main.Device.IsConnected))
                Guide.BeginShowStorageDeviceSelector(Main.Controller, 
                    FinishLoadOptions, null);
            else
                FinishLoadOptions(null);
        }       
        public void FinishLoadOptions(IAsyncResult ar)
        {
            // If ar is null, assume we have a device already
            if (ar != null)
                Main.Device = Guide.EndShowStorageDeviceSelector(ar);

            // In case the user didn't supply a valid storage device, check
            // the title location
            string path = Path.Combine(StorageContainer.TitleLocation, 
                "options.xml");

            // If they did, open a container
            StorageContainer container = null;
            if (Main.Device != null)
            {
                container = Main.Device.OpenContainer("TopdownShooter");
                path = Path.Combine(container.Path, "options.xml");
            }

            if (File.Exists(path))
            {
                XmlSerializer serializer = new XmlSerializer(typeof(OptionsState));
                FileStream file = File.OpenRead(path);
                options = (OptionsState)serializer.Deserialize(file);
                file.Close();                
            }
            else // If there's no options to find, set sensible defaults
            {
                options = new OptionsState();                
                options.FXLevel = 0.7f;
                options.MusicLevel = 0.6f;
                options.PlayerOne = InputMode.Normal;
                options.PlayerTwo = InputMode.Normal;
            }

            // Dispose the container if we opened one:
            if (container != null)
                container.Dispose();

            // Set the audio manager with the options we just loaded
            audio.SetOptions(options.FXLevel, options.MusicLevel);
        }
        #endregion

        #region Pausing
        public bool IsPaused
        {
            get { return bPaused; }
        }

        /// <summary>
        /// Request a pause in the game.  Some things cannot be
        /// paused in multiplayer.
        /// </summary>
        public bool BeginPause()
        {
            if (!bPaused)
            {
                bPaused = true;
                // Audio off                
                audio.PauseAll();
                // Controller vibration off
                input.BeginPause();
                // Switch presence
                Main.BeginPause();
            }
            return IsPaused;
        }

        /// <summary>
        /// Resume the game.
        /// </summary>
        public bool EndPause()
        {
            if (bPaused)
            {
                // Audio on
                audio.ResumeAll();
                // Controller vibration on
                input.EndPause();
                // Switch presence
                Main.EndPause();

                bPaused = false;
            }
            return IsPaused;
        }
        #endregion


        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {            
            graphics.GraphicsDevice.Clear(Color.Black);

            // TODO: Add your drawing code here

            base.Draw(gameTime);
        }
    }
}
