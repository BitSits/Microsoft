﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Media;

namespace TopDownShooterM2
{
    
    public class AudioManager : DrawableGameComponent
    {
        private float FXVolume;
        private float MusicVolume;
        public AudioManager(Game game)
            : base(game)
        {
            FXVolume = 1.0f;
            MusicVolume = 1.0f;
            Sounds = new Queue<SoundEffectInstance>(14);
        }
        private SoundEffect Shot;
        private SoundEffect Explosion;

        private Song Music;
        private SoundEffect Seeker; // Looped
        private SoundEffectInstance SeekerInstance;

        protected override void LoadContent()
        {
            Music = Game.Content.Load<Song>("Menu_Loop");
            MediaPlayer.Volume = MusicVolume;
            MediaPlayer.IsRepeating = true;

            Seeker = Game.Content.Load<SoundEffect>("engine_2");

            // We call CreateInstance to get a permanent handle
            // on the seeker sound, and set it's pitch, volume,
            // and looping accordingly.
            SeekerInstance = Seeker.CreateInstance();
            SeekerInstance.Volume = FXVolume;
            SeekerInstance.Pitch = 0.75f;
            SeekerInstance.IsLooped = true;

            Shot = Game.Content.Load<SoundEffect>("tx0_fire1");
            Explosion = Game.Content.Load<SoundEffect>("explosion1");

            base.LoadContent();
        }

        public override void Update(GameTime gameTime)
        {
            // This will help keep the size of the Queue to a minimum.            
            for (int i = 0; i < Sounds.Count; i++)
            {
                if (Sounds.Peek().State == SoundState.Stopped)
                    Sounds.Dequeue();
                else
                    break;
            }

            base.Update(gameTime);
        }

        private Queue<SoundEffectInstance> Sounds;
        private void AddSound(SoundEffect sound, float volume, float pitch)
        {
            SoundEffectInstance handle = sound.CreateInstance();
            handle.Volume = volume;
            handle.Pitch = pitch;
            handle.Play();
            Sounds.Enqueue(handle);
        }
        public void PlayShot()
        {
            if (!bPaused)
                AddSound(Shot, 1.0f, 0.5f);
        }
        public void PlayExplosion()
        {
            if (!bPaused)
                AddSound(Explosion, 1.0f, 0);
        }
        public void PlaySeeker()
        {
            if ((!bPaused) && (SeekerInstance.State != SoundState.Playing))
                SeekerInstance.Play();
        }
        public void StopSeeker()
        {
            SeekerInstance.Stop();
        }
        public void PlayMusic()
        {
            if (Music != null)
            {
                MediaPlayer.Play(Music);
            }
        }
        private bool bPaused = false;
        public bool IsPaused { get { return bPaused; } }
        public void PauseSounds()
        {
            bPaused = true;
            SeekerInstance.Pause();
            foreach (SoundEffectInstance item in Sounds)
            {
                if (item.State == SoundState.Playing)
                    item.Pause();
            }
        }
        public void PauseAll()
        {
            PauseSounds();
            MediaPlayer.Pause();
        }               
        public void ResumeAll()
        {
            if (bPaused)
            {
                MediaPlayer.Resume();

                if (SeekerInstance.State == SoundState.Paused)
                    SeekerInstance.Resume();
                
                foreach (SoundEffectInstance item in Sounds)
                {
                    if (item.State == SoundState.Paused)
                        item.Resume();
                }
                bPaused = false;
            }
        }
        public void SetOptions(float fxVolume, float musicVolume)
        {
            this.FXVolume = fxVolume;
            this.MusicVolume = musicVolume;
            if (SeekerInstance != null)
            {
                SeekerInstance.Volume = this.FXVolume;
            }
            MediaPlayer.Volume = this.MusicVolume;
            foreach (SoundEffectInstance item in Sounds)
            {
                item.Volume = this.FXVolume;
            }
        }
    }
}
