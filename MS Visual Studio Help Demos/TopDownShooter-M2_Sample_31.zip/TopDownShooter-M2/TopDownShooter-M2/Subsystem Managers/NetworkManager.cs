﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Net;
using Microsoft.Xna.Framework.Storage;
using GameStateManagement;
using System.Xml.Serialization;
using System.Xml;
using System.IO;

namespace TopDownShooterM2
{
    /// <summary>
    /// This GameScreen prompts for signin remains active until signin is complete.
    /// </summary>
    public class SignInScreen : BackgroundScreen
    {
        public SignInScreen()
        {
        }
        public SignInScreen(int paneCount, bool onlineOnly)
        {
            this.paneCount = paneCount;
            this.onlineOnly = onlineOnly;
        }
        public event EventHandler ScreenFinished;
        public int paneCount = 1;
        public bool onlineOnly = true;
        public override void Initialize()
        {            
            this.IsPopup = false;
            base.Initialize();
        }
        bool GuideShown = false;
        public override void Update(GameTime gameTime, bool otherScreenHasFocus,
            bool coveredByOtherScreen)
        {
            // If we haven't activated the guide yet, 
            // and it's not up for another purpose, activate it now
            if ((!GuideShown) && (!Guide.IsVisible))
            {
                Guide.ShowSignIn(paneCount, onlineOnly);
                GuideShown = true;
            }
            else if ((GuideShown) && (Guide.IsVisible))
            {
                // If the guide is up, do nothing
            }
            // Screen must have been shown and closed
            else if (!Guide.IsVisible)
            {
                // Activate our callback function and exit
                if (ScreenFinished != null)
                {
                    ScreenFinished.Invoke(this, null);
                }
                ExitScreen();  
            }
            base.Update(gameTime, otherScreenHasFocus, coveredByOtherScreen);
        }
    }

    public class NetworkErrorScreen : ErrorScreen
    {
        public NetworkErrorScreen(Exception e) 
            : base(e.Message)
        {
            this.error = "Network Error: " + error + "\n\nPress A to exit";
        }
        public override void HandleInput(InputState input)
        {
            if (input.IsNewButtonPress(Buttons.A))
            {
                ((Game1)this.ScreenManager.Game).FailToMenu();
            }
            base.HandleInput(input);
        }
    }

    public class NetworkManager : DrawableGameComponent
    {
        public NetworkManager(Game game ) : base(game)
        {
            this.Visible = false;
        }

        /// <summary>
        /// Finds a SignedInGamer associated with a controller.
        /// </summary>
        /// <param name="index">The controller to query.</param>
        /// <returns>The SignedInGamer for the controller, or null if none is found.</returns>
        public static SignedInGamer FindGamer(PlayerIndex index)
        {
            foreach (SignedInGamer gamer in SignedInGamer.SignedInGamers)
            {
                if (gamer.PlayerIndex == index)
                    return gamer;
            }
            return null;
        }

    }


}
