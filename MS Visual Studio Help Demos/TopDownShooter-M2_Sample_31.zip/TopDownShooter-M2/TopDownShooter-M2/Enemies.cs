﻿#region File Description
//-----------------------------------------------------------------------------
// Game1.cs
//
// Microsoft XNA Community Game Platform
// Copyright (C) Microsoft Corporation. All rights reserved.
//-----------------------------------------------------------------------------
#endregion

using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Net;
using Microsoft.Xna.Framework.Storage;

namespace TopDownShooterM2
{
    public enum EnemyType
    {
        Basic,
        Looper,
        Seeker
    }

    public struct EnemyInfo
    {
        public float TimeToDie;
        public Curve XCurve;
        public Curve YCurve;
        public Rectangle ScreenBounds;
        public float CrashRadius;
    }

    public struct EnemyState
    {
        public EnemyState(float totalGameSeconds, EnemyType type)
        {
            this.status = ObjectStatus.Active;
            this.startTimeTotalSeconds = totalGameSeconds;
            this.type = type;
            this.invert = true;
            this.deathTimeTotalSeconds = 0;
            this.TimeOnScreen = 4.5f;
        }
        public ObjectStatus status;
        public float startTimeTotalSeconds;
        public float deathTimeTotalSeconds;
        public float TimeOnScreen;
        public bool invert;
        public EnemyType type;
    }

    public struct SeekerState
    {
        public float angle;
        public ObjectStatus status;
        public Vector2 position;
        public float deathTimeTotalSeconds;
        public float speed;

    }


    public class Enemies
    {
        public EnemyState[] waves;
        public SeekerState[] seekers;
        public static EnemyInfo BasicInfo;
        public static EnemyInfo LooperInfo;
        public static EnemyInfo SeekerInfo;
        public Random random;

        public float RadiansPerSecond = MathHelper.Pi * 4;
        public int ActiveEnemies;

        public Enemies()
        {
            waves = new EnemyState[20];
            seekers = new SeekerState[4];
            random = new Random();
        }

        public static void Initialize(Viewport view, ContentManager content)
        {            
            BasicInfo.ScreenBounds = new Rectangle(view.X, view.Y, view.Width, 
                view.Height);
            BasicInfo.TimeToDie = 1.5f;   // 1 1/2 secs
            BasicInfo.CrashRadius = 20f;

            LooperInfo = BasicInfo;

            SeekerInfo = BasicInfo;
            SeekerInfo.TimeToDie = 10.0f;

            BasicInfo.XCurve = content.Load<Curve>("XCurve1");
            BasicInfo.YCurve = content.Load<Curve>("YCurve1");

            LooperInfo.XCurve = content.Load<Curve>("XCurve2");
            LooperInfo.YCurve = content.Load<Curve>("YCurve2");

        }

        public void Reset()
        {
            for (int i = 0; i < waves.Length; i++)
            {
                waves[i].startTimeTotalSeconds = 0;
                waves[i].deathTimeTotalSeconds = 0;
                waves[i].status = ObjectStatus.Inactive;
                waves[i].TimeOnScreen = 0;
                waves[i].type = EnemyType.Looper;                
            }
            for (int j = 0; j < seekers.Length; j++)
            {
                seekers[j].deathTimeTotalSeconds = 0;
                seekers[j].position = Vector2.One * -40;
                seekers[j].speed = 0;
                seekers[j].status = ObjectStatus.Inactive;
            }
        }

        private void SpawnBasicWave(float totalGameSeconds)
        {
            EnemyState spawn;

            spawn.status = ObjectStatus.Active;
            spawn.startTimeTotalSeconds = totalGameSeconds;
            spawn.deathTimeTotalSeconds = 0;
            spawn.type = EnemyType.Basic;
            spawn.invert = false;


            float BasicBaseTime = 4.5f; // 4 1/2 secs
            float MinimumTimeOnScreen = 1.0f;
            // every minute, we speed up the wave
            spawn.TimeOnScreen = BasicBaseTime - (totalGameSeconds / 60) * 0.6f;
            if (spawn.TimeOnScreen < MinimumTimeOnScreen)
                spawn.TimeOnScreen = MinimumTimeOnScreen;

            for (int i = 0; i < waves.Length; i++)
            {
                waves[i] = spawn;
                spawn.invert = !spawn.invert;
                spawn.startTimeTotalSeconds += 0.1f; // one-tenth of a second
            }
        }

        public void SpawnNextWave(float totalGameSeconds)
        {
            if (waves[0].type == EnemyType.Basic)
                SpawnLooperWave(totalGameSeconds);
            else
                SpawnBasicWave(totalGameSeconds);
        }

        private void SpawnLooperWave(float totalGameSeconds)
        {
            EnemyState spawn;

            spawn.status = ObjectStatus.Active;
            spawn.startTimeTotalSeconds = totalGameSeconds;
            spawn.deathTimeTotalSeconds = 0;
            spawn.type = EnemyType.Looper;
            spawn.invert = false;

            float LooperBaseTime = 6.0f; // 6 secs
            float MinimumTimeOnScreen = 1.0f;
            // every minute, we speed up the wave
            spawn.TimeOnScreen = LooperBaseTime - (totalGameSeconds / 60) * 0.6f;
            if (spawn.TimeOnScreen < MinimumTimeOnScreen)
                spawn.TimeOnScreen = MinimumTimeOnScreen;

            for (int i = 0; i < waves.Length; i++)
            {
                waves[i] = spawn;
                spawn.invert = !spawn.invert;
                spawn.startTimeTotalSeconds += 0.07f; // 7 one-hundreths of a second
            }
        }

        public void SpawnSeeker()
        {
            SeekerState spawn;
            spawn.position = Vector2.One * 100;
            spawn.status = ObjectStatus.Active;
            spawn.speed = 75.0f;
            spawn.angle = MathHelper.PiOver2;
            spawn.deathTimeTotalSeconds = 0;

            for (int i = 0; i < seekers.Length; i++)
            {
                if (seekers[i].status == ObjectStatus.Inactive)
                {
                    seekers[i] = spawn;
                    break;
                }
            }        
        }     

        public void Update(float totalGameSeconds)
        {
            ActiveEnemies = 0;
            for (int i = 0; i < waves.Length; i++)
            {
                UpdateBasic(totalGameSeconds, ref waves[i]);
                //if (waves[i].status == ObjectStatus.Active)
                if (waves[i].status != ObjectStatus.Inactive)
                    ActiveEnemies++;
            }            
        }



        private static void UpdateBasic(float totalGameSeconds, ref EnemyState enemy)
        {
            switch (enemy.status)
            {
                case ObjectStatus.Inactive:
                    break;
                case ObjectStatus.Active:
                    // Reset enemies that went offscreen
                    if ((enemy.startTimeTotalSeconds + enemy.TimeOnScreen) <
                        totalGameSeconds)
                    {
                        enemy.startTimeTotalSeconds = totalGameSeconds;
                    }
                    break;
                case ObjectStatus.Dying:
                    if ((enemy.deathTimeTotalSeconds + BasicInfo.TimeToDie) <
                        totalGameSeconds)
                    {
                        enemy.status = ObjectStatus.Inactive;
                    }
                    break;
                default:
                    break;
            }

        }

        public void DestroyEnemy(float totalGameSeconds, byte index)
        {
            waves[index].deathTimeTotalSeconds = totalGameSeconds;
            waves[index].status = ObjectStatus.Dying;
        }

        public void DestroySeeker(float totalGameSeconds, byte index)
        {
            seekers[index].deathTimeTotalSeconds = totalGameSeconds;
            seekers[index].status = ObjectStatus.Dying;
        }

        // Destroy the seeker without leaving a powerup
        public void CrashSeeker(float totalGameSeconds, byte index)
        {
            seekers[index].deathTimeTotalSeconds = totalGameSeconds;
            seekers[index].status = ObjectStatus.Inactive;
        }

        public static EnemyInfo GetInfoForType(EnemyType type)
        {
            switch (type)
            {
                case EnemyType.Basic:
                    return BasicInfo;
                case EnemyType.Looper:
                    return LooperInfo;
                case EnemyType.Seeker:
                    return SeekerInfo;
            }
            return BasicInfo;
        }

        public static Vector2 GetPosition(float totalGameSeconds, EnemyState enemy)
        {
            float elapsed;
            if (enemy.deathTimeTotalSeconds == 0)
                elapsed = (totalGameSeconds - enemy.startTimeTotalSeconds);
            else
                elapsed = (enemy.deathTimeTotalSeconds - enemy.startTimeTotalSeconds);

            Vector2 pos;

            switch (enemy.type)
            {
                case EnemyType.Basic:
                    pos = GetPosition(elapsed / enemy.TimeOnScreen, BasicInfo);
                    if (enemy.invert)
                    {

                        pos.X = BasicInfo.ScreenBounds.Width - pos.X;
                    }
                    return pos;
                case EnemyType.Looper:
                    pos = GetPosition(elapsed / enemy.TimeOnScreen, LooperInfo);
                    if (enemy.invert)
                    {
                        pos.X = LooperInfo.ScreenBounds.Width - pos.X;
                    }
                    return pos;
                case EnemyType.Seeker:
                    break;
                default:
                    break;
            }
            return Vector2.Zero;
        }
        public static Vector2 GetPosition(float position, EnemyInfo info)
        {
            Vector2 pos = Vector2.Zero;
            pos.Y = info.YCurve.Evaluate(position) * info.ScreenBounds.Height;
            pos.X = info.XCurve.Evaluate(position) * info.ScreenBounds.Width;
            return pos;
        }



    }
}
