﻿#region File Description
//-----------------------------------------------------------------------------
// Game1.cs
//
// Microsoft XNA Community Game Platform
// Copyright (C) Microsoft Corporation. All rights reserved.
//-----------------------------------------------------------------------------
#endregion

using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Net;
using Microsoft.Xna.Framework.Storage;
using GameStateManagement;


namespace TopDownShooterM2
{

    public struct ShipState
    {
        public Vector2 position;
        public List<Vector3> bullets;
        public ObjectStatus status;
        public int score;
        public int lives;
        public float deathTimeTotalSeconds;
        public Color color;
        //public bool FiredGun;
    }



    public class Avatar
    {
        // Network/Draw state information
        public Vector2 position;
        public List<Vector3> bullets;
        public ObjectStatus status;
        public int score;
        public int lives;
        public float deathTimeTotalSeconds;
        public Color color;

        public Player Player;
        public bool IsPlaying
        {
            get { return status != ObjectStatus.Inactive; }
        }



        public static float CrashRadius = 20f;
        public static float RespawnTime = 5.0f;
        public static float PixelsPerSecond = 200;
        public static int bulletmax = 20;
        
        public Rectangle ScreenBounds;
        
        // Variables to control bullet behavior
        public static int RateOfFire = 4; // per second
        private float LastShot;

        public Avatar()             
        {
            bullets = new List<Vector3>(bulletmax);
        }
      
               
        public void Initialize(Viewport view)
        {
            ScreenBounds = new Rectangle(view.X + 50, view.Height / 2, view.Width - 100, (view.Height / 2) - 50);
            position = new Vector2(ScreenBounds.Left + (ScreenBounds.Width / 2), ScreenBounds.Bottom - 60);
        }


        /// <summary>
        /// Resets ship state, sets a color, and deactivates ship.
        /// </summary>
        /// <param name="color"></param>
        public void Reset(Color color)
        {
            this.color = color;
            Reset();
        }        

        /// <summary>
        /// Resets ship state and deactivates ship.
        /// </summary>
        public void Reset()
        {            
            Restart();
            Deactivate();
        }

        /// <summary>
        /// Resets ship state without deactivating the ship.
        /// </summary>
        public void Restart()
        {
            position.X = ScreenBounds.X + (ScreenBounds.Width / 2);
            position.Y = ScreenBounds.Y + (ScreenBounds.Height - 60);
            deathTimeTotalSeconds = 0;
            lives = 3;
            score = 0;
            bullets.Clear();
            LastShot = 0;
        }

        /// <summary>
        /// Activates ship and assigns it to a player.
        /// </summary>
        /// <param name="player"></param>
        public void Activate(Player player)
        {
            player.IsPlaying = true;
            this.Player = player;
            this.status = ObjectStatus.Active;
        }

        /// <summary>
        /// Deactivates ship.
        /// </summary>
        public void Deactivate()
        {
            this.status = ObjectStatus.Inactive;
        }

        public Vector2 VerifyMove(Vector2 offset)
        {
            if ((status != ObjectStatus.Dying) &&
                (status != ObjectStatus.Inactive))
            {
                Vector2 pos = position + offset;
                pos.X = MathHelper.Clamp(pos.X, ScreenBounds.X, 
                    ScreenBounds.X + ScreenBounds.Width);
                pos.Y = MathHelper.Clamp(pos.Y, ScreenBounds.Y, 
                    ScreenBounds.Y + ScreenBounds.Height);
                return pos - position;  // Return the distance allowed to travel
            }
            else
                return position;

        }


        public bool VerifyFire(float currentSec)
        {
            if (VerifyFire(currentSec, LastShot))
            {
                LastShot = currentSec;
                return true;
            }
            return false;
        }

        private static bool VerifyFire(float currentSec, float lastShot)
        {
            if ((currentSec - lastShot) > (1f / Avatar.RateOfFire))
                return true;
            return false;
        }


        public void DestroyShip(float totalGameSeconds)
        {
            deathTimeTotalSeconds = totalGameSeconds;
            status = ObjectStatus.Dying;
        }

        public void Update(float totalGameSeconds)
        {
            if (status == ObjectStatus.Dying)
            {
                if ((totalGameSeconds > deathTimeTotalSeconds + Avatar.RespawnTime))
                {
                    if (lives > 0)
                    {
                        //state.lives--;
                        status = ObjectStatus.Immune;
                    }
                    else
                    {
                        status = ObjectStatus.Inactive;
                    }
                }
            }
            else if (status == ObjectStatus.Immune)
            {
                //Ship.ClampPlayer(ref state, ScreenBounds);

                if (totalGameSeconds > deathTimeTotalSeconds + 
                    (Avatar.RespawnTime * 2))
                {
                    status = ObjectStatus.Active;
                }
            }

            // Set presence info for Player
            Player.SetPresenceValue(score);
        }

        public ShipState State
        {
            get
            {
                ShipState state;

                state.bullets = this.bullets;
                state.color = this.color;
                state.deathTimeTotalSeconds = this.deathTimeTotalSeconds;
                state.lives = this.lives;
                state.position = this.position;
                state.score = this.score;
                state.status = this.status;

                return state;
            }
            set
            {
                this.bullets = value.bullets;
                this.color = value.color;
                this.deathTimeTotalSeconds = value.deathTimeTotalSeconds;
                this.lives = value.lives;
                this.position = value.position;
                this.score = value.score;
                this.status = value.status;
            }
        }
    }
}
