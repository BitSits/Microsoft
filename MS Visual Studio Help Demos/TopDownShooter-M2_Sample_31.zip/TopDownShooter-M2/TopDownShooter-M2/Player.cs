﻿#region File Description
//-----------------------------------------------------------------------------
// Game1.cs
//
// Microsoft XNA Community Game Platform
// Copyright (C) Microsoft Corporation. All rights reserved.
//-----------------------------------------------------------------------------
#endregion

using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Storage;
using Microsoft.Xna.Framework.Net;

namespace TopDownShooterM2
{
    /// <summary>
    /// This structure is used as a central clearinghouse
    /// for some data related to each player.  A lot of this
    /// data is garnered from the SignedInGamer, if there is
    /// one.  However, that's not guaranteed, at least on PC.
    /// </summary>
    public class Player
    {
        public bool IsPlaying;  // Are they playing?
        public PlayerIndex Controller; // Which controller?

        /// <summary>
        /// This is true if this player is not local.
        /// </summary>
        public bool IsRemote;        // Or maybe networked instead?
        public InputMode Options;      // Which control options, if local?
        public StorageDevice Device;    // Cache their storage device
        public SignedInGamer SignedInGamer;

        private string name;
        public string Name             // What name?
        {
            get
            {
                if (SignedInGamer != null)
                    return SignedInGamer.Gamertag;
                else
                    return name;
            }
            set
            {
                name = value;
            }
        }


        public void InitFromGamer(SignedInGamer gamer)
        {
            this.SignedInGamer = gamer;
            this.Controller = gamer.PlayerIndex;
            if (gamer.GameDefaults.MoveWithRightThumbStick)
                this.Options = InputMode.Normal;
            else
                this.Options = InputMode.Southpaw;
        }
        public void InitLocal(PlayerIndex controller, string name, 
            InputMode options)
        {
            this.Controller = controller;
            this.Name = name;
            this.Options = options;
        }
        public void GamerSignedOut(SignedInGamer gamer)
        {
            if (this.SignedInGamer == gamer)
            {
                this.SignedInGamer = null;
                this.Device = null;
                this.IsPlaying = false;
            }
        }

        #region Managing Gamer Presence
        GamerPresenceMode previousMode;
        public void BeginPause()
        {
            if (SignedInGamer != null)
            {
                previousMode = this.SignedInGamer.Presence.PresenceMode;
                this.SignedInGamer.Presence.PresenceMode = GamerPresenceMode.Paused;
            }
        }
        public void EndPause()
        {
            if (SignedInGamer != null)
                this.SignedInGamer.Presence.PresenceMode = previousMode;
        }
        public GamerPresenceMode SetPresence(GamerPresenceMode mode)
        {
            if (SignedInGamer != null)
            {
                GamerPresenceMode retval = this.SignedInGamer.Presence.PresenceMode;
                this.SignedInGamer.Presence.PresenceMode = mode;
                return retval;
            }
            return GamerPresenceMode.None;
        }
        public int SetPresenceValue(int value)
        {
            if (SignedInGamer != null)
            {
                int retval = this.SignedInGamer.Presence.PresenceValue;
                this.SignedInGamer.Presence.PresenceValue = value;
                return retval;
            }
            return 0;
        }
        #endregion
    }

}
