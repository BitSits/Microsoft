﻿#region File Description
//-----------------------------------------------------------------------------
// Game1.cs
//
// Microsoft XNA Community Game Platform
// Copyright (C) Microsoft Corporation. All rights reserved.
//-----------------------------------------------------------------------------
#endregion

using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Net;
using Microsoft.Xna.Framework.Storage;
using GameStateManagement;

namespace TopDownShooterM1
{
    public class HelpScreen : BackroundScreen
    {
        public HelpScreen()
        {
        }
        string[] helptext;
        Vector2[] positions;
        public override void Initialize()
        {
            helptext = new string[5];
            helptext[0] = "Use trigger to fire at the enemy ships";
            helptext[1] = "Use the thumbstick to move your ship";
            helptext[2] = "Shoot the enemies to accumulate points";
            helptext[3] = "Shoot the green enemies to get a powerup";
            helptext[4] = "Catch the powerup to gain a free life";

            positions = new Vector2[6];
            int width = this.ScreenManager.GraphicsDevice.Viewport.Width;
            Vector2 stringsize = Vector2.Zero;
            for (int i = 0; i < 5; i++)
            {
                stringsize = this.ScreenManager.Font.MeasureString(helptext[i]);
                positions[i] = new Vector2(
                    (width - stringsize.X) / 2,
                    stringsize.Y * ((2 * i) + 6)
                    );
            }
            positions[5] = new Vector2(positions[4].X, positions[4].Y + stringsize.Y * 2);
            base.Initialize();
        }
        Texture2D btnA;
        public override void LoadContent()
        {
            btnA = this.ScreenManager.Game.Content.Load<Texture2D>("xboxControllerButtonA");
            base.LoadContent();
        }

        public override void HandleInput(InputState input)
        {
            if (input.IsNewButtonPress(Buttons.A))
            {
                ExitScreen();
            }
            base.HandleInput(input);
        }
        public override void Draw(GameTime gameTime)
        {
            // Draw the background first
            base.Draw(gameTime);

            // Now draw the text
            SpriteBatch batch = this.ScreenManager.SpriteBatch;
            SpriteFont font = this.ScreenManager.Font;

            batch.Begin();
            for (int i = 0; i < 5; i++)
            {
                batch.DrawString(font, helptext[i], positions[i], Color.Pink);
            }
            batch.End();
            DrawFinished(positions[5], batch);
        }

        private void DrawFinished(Vector2 pos, SpriteBatch batch)
        {
            pos.X += 140;
            batch.Begin();
            batch.DrawString(this.ScreenManager.Font, "Finished", pos, Color.White);
            pos.X += 95;
            pos.Y -= 3;            
            batch.Draw(btnA, pos, null, Color.White, 0, Vector2.Zero, 0.33f, SpriteEffects.None, 1.0f);
            batch.End();
        }
    }
}
