﻿#region File Description
//-----------------------------------------------------------------------------
// Game1.cs
//
// Microsoft XNA Community Game Platform
// Copyright (C) Microsoft Corporation. All rights reserved.
//-----------------------------------------------------------------------------
#endregion

using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Net;
using Microsoft.Xna.Framework.Storage;
using GameStateManagement;
using System.IO;

namespace TopDownShooterM1
{
    public struct NeutralInput
    {
        public Vector2 StickMovement;
        public bool Fire;
    }


    // This structure is used as a central clearinghouse
    // for some data related to each player. 
    public class Player
    {
        public bool IsPlaying;  // Are they playing?
        public PlayerIndex Controller; // Which controller?

        private string name;
        public string Name             // What name?
        {
            get { return name; }
            set { name = value; }
        }
   
        public void InitLocal(PlayerIndex controller, string name)
        {
            this.Controller = controller;
            this.Name = name;
        }
    }
        


    /// <summary>
    /// This is the main type for your game
    /// </summary>
    public class Game1 : Microsoft.Xna.Framework.Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;

        // Game data
        public Enemies enemies;
        public Avatar[] ships;
        public float TotalGameSeconds;

        /// <summary>
        /// Player who controls the interface.  This is the lowest connected 
        /// numbered controller at startup time.
        /// </summary>
        public Player Main;  

        /// <summary>
        /// Player who joins the game.  This is a second controller.        
        /// </summary>
        public Player Guest;
        private const int PlayerMax = 2;

        public ScreenManager screenManager;
        GamePlayScreen playScreen;
        public static float BackgroundDriftRatePerSec = 64.0f;

        /// <summary>
        /// This is the class that handles our gameplay calculations,
        /// such as collision, death, spawning new enemies, etc.
        /// </summary>
        public GamePlayHost host;

        private bool bPaused = false;
        private bool bStateReady = false;
                
        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            graphics.PreferredBackBufferHeight = 576;
            graphics.PreferredBackBufferWidth = 1024;

            Content.RootDirectory = "Content";

            // Create the screen manager component.
            screenManager = new ScreenManager(this);

            Components.Add(screenManager);
            screenManager.TraceEnabled = true;

            host = new GamePlayHost(this);

            Main = new Player();
            Guest = new Player();

        }   

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {            
            ships = new Avatar[PlayerMax];
            for (int i = 0; i < PlayerMax; i++)
            {                
                ships[i] = new Avatar();
                ships[i].Initialize(GraphicsDevice.Viewport);
            }
            enemies = new Enemies();
            Enemies.Initialize(GraphicsDevice.Viewport, Content);

            base.Initialize();
  
            // Setup the main player on that controller
            Main.InitLocal(PlayerIndex.One, "Player One");

            BeginGame();
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);
        }


        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            if (!bPaused && bStateReady)
            {
                // Check for Player Two pressing Start, and initialize them.
                if (GamePad.GetState(PlayerIndex.Two).IsButtonDown(
                    Buttons.Start) && !Guest.IsPlaying)
                {
                    InitializeGuest(PlayerIndex.Two);
                }

                TotalGameSeconds += 
                    (float)gameTime.ElapsedGameTime.TotalSeconds;

                ships[0].Update(TotalGameSeconds);
                ships[1].Update(TotalGameSeconds);

                enemies.Update(TotalGameSeconds);

                host.Update(gameTime);

            }

            // This will update our current screen, 
            // plus audio, network, and input components
            base.Update(gameTime);
        }

        #region Start Games

        public void InitializeGuest(PlayerIndex index)
        {
            if (!Guest.IsPlaying)
            {
                Guest.InitLocal(index, "Player Two");              
                ships[1].Activate(Guest);
            }
        }

        public void BeginGame()
        {            
            Reset();

            // Get our players and ships setup properly
            ships[0].Activate(Main);
            ships[1].Player = Guest;
            bStateReady = true;

            host.StartGame();
            playScreen = new GamePlayScreen(this);                       
            screenManager.AddScreen(playScreen);
        }

        /// <summary>
        /// This method is called to reset game stats so a new game starts
        /// cleanly.
        /// </summary>
        public void Reset()
        {
            TotalGameSeconds = 0;
            ships[0].Reset(Color.Red);
            ships[1].Reset(Color.Green);
            enemies.Reset();
            host.Reset();
        }

        /// <summary>
        /// This method is called to restart an existing game.
        /// Player information remains the same
        /// </summary>
        public void Restart()
        {
            ships[0].Restart();
            ships[0].Activate(Main);
            ships[1].Restart();
            if (Guest.IsPlaying)
                ships[1].Activate(Guest);

            TotalGameSeconds = 0;
            playScreen.bGameOver = false;
            enemies.Reset();
            host.Reset();
        }
        #endregion

        #region Host and Screen events
        public void SeekerMoved(byte seeker, Vector2 pos, float angle)
        {
            enemies.seekers[seeker].position = pos;
            enemies.seekers[seeker].angle = angle;
        }

        public void GameOver(byte player)
        {
            PlayerDestroyed(player);
            playScreen.bGameOver = true;
        }

        public void EnemyKilled(byte index, byte player)
        {
            enemies.DestroyEnemy(TotalGameSeconds, index);
            ships[player].score += 10;
        }

        public void SpawnNextSeeker()
        {
            enemies.SpawnSeeker();
        }

        public void SeekerCrashed(byte index)
        {
            enemies.CrashSeeker(TotalGameSeconds, index);
        }

        public void IncreaseLife(byte player)
        {
            ships[player].lives++;
        }

        public void SeekerDestroyed(byte index)
        {
            enemies.DestroySeeker(TotalGameSeconds, index);
        }

        public void PlayerDestroyed(byte player)
        {
            ships[player].DestroyShip(TotalGameSeconds);
            ships[player].lives--;
        }

        public void IncreaseScore(byte player, short amount)
        {
            ships[player].score += amount;
        }
        public void SpawnNextWave(float totalGameSeconds)
        {
            enemies.SpawnNextWave(totalGameSeconds);
        }

        public void ShipMove(byte player, Vector2 pos)
        {
            ships[player].position = pos;
        }

        public void ShipFire(byte player, float totalGameSeconds)
        {
            ships[player].bullets.Add(new Vector3(ships[player].position, 
                totalGameSeconds));
        }
        #endregion

        #region Pausing
        public bool IsPaused
        {
            get { return bPaused; }
        }

        /// <summary>
        /// Request a pause in the game.  Some things cannot be
        /// paused in multiplayer.
        /// </summary>
        public bool BeginPause()
        {
            if (!bPaused)
            {
                bPaused = true;
            }
            return bPaused;
        }

        /// <summary>
        /// Resume the game.
        /// </summary>
        public bool EndPause()
        {
            if (bPaused)
            {
                bPaused = false;
            }
            return bPaused;
        }
        #endregion

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {            
            graphics.GraphicsDevice.Clear(Color.Black);
            // TODO: Add your drawing code here
            base.Draw(gameTime);
        }
    }
}
