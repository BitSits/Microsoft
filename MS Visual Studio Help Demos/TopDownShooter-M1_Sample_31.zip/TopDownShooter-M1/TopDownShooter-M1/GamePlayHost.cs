﻿#region File Description
//-----------------------------------------------------------------------------
// Game1.cs
//
// Microsoft XNA Community Game Platform
// Copyright (C) Microsoft Corporation. All rights reserved.
//-----------------------------------------------------------------------------
#endregion

using System;
using Microsoft.Xna.Framework;

namespace TopDownShooterM1
{
    public class GamePlayHost
    {
        private float NextWaveEarliestSeconds = 0;
        private int NextSeekerScore = 200;
        private bool bLastWaveBasic = false;
        private bool bKillAllInOnePass = false;
        private bool bActive = false;

        public Game1 Game;

        public GamePlayHost(Game1 game)
        {
            this.Game = game;
        }




        public void Reset()
        {
            NextWaveEarliestSeconds = 0;
            NextSeekerScore = 200;
           
            bLastWaveBasic = false;
            bKillAllInOnePass = false;
        }
        public void StartGame()
        {
            Reset();
            bActive = true;
        }
        public void EndGame()
        {
            bActive = false;
        }

        public void Update(GameTime gameTime)
        {
            if (!bActive)
                return;

            SpawnWaves(Game.TotalGameSeconds);

            HandleCollisions(Game.ships[0], 0, 
                Game.enemies, Game.TotalGameSeconds);
            HandleCollisions(Game.ships[1], 1, 
                Game.enemies, Game.TotalGameSeconds);

            SpawnSeekers();

            for (int j = 0; j < Game.enemies.seekers.Length; j++)
            {
                UpdateSeeker(Game.TotalGameSeconds, 
                    (float)gameTime.ElapsedGameTime.TotalSeconds, 
                    Game.enemies.seekers[j], (byte)j, Game.ships);
            }           
        }

        private void SpawnSeekers()
        {
            if ((Game.ships[0].score >= NextSeekerScore) ||
                (Game.ships[1].score >= NextSeekerScore))
            {
                Game.SpawnNextSeeker();
                NextSeekerScore += NextSeekerScore;
            }

        }       
        private void SpawnWaves(double TotalGameSeconds)
        {
            // If it's time for a new wave and no enemies are 
            // left from the last wave
            if ((Game.enemies.ActiveEnemies == 0) &&
                (TotalGameSeconds >= NextWaveEarliestSeconds))
            {
                // If the wave was killed in one pass, both players get a bonus
                if (bKillAllInOnePass)
                {
                    //Game.state.Players[0].score += 1000;
                    Game.IncreaseScore(0, 1000);

                    // PlayerTwo doesn't get a bonus if they're not playing
                    if (Game.ships[1].status != ObjectStatus.Inactive)
                        Game.IncreaseScore(1, 1000);
                }
                
                // Spawn the next wave
                Game.SpawnNextWave((float) TotalGameSeconds);

                // Reset our booleans
                bLastWaveBasic = !bLastWaveBasic;
                bKillAllInOnePass = true;

                // Reset the wave timer
                NextWaveEarliestSeconds = (float)TotalGameSeconds + 2.0f;
            }
            else if (TotalGameSeconds >= NextWaveEarliestSeconds)
            {
                NextWaveEarliestSeconds = (float)TotalGameSeconds + 2.0f;
                bKillAllInOnePass = false;
            }
        }

        private void DestroyPlayer(byte Player)
        {
            if ((Player == 0) && (Game.ships[0].lives == 1))
            {
                if ((Game.ships[1].status == ObjectStatus.Inactive) ||
                    (Game.ships[1].lives == 0))
                    Game.GameOver(0);
                else
                    Game.PlayerDestroyed(0);
            }
            else if ((Player == 1) && (Game.ships[1].lives == 1))
            {
                if ((Game.ships[0].status == ObjectStatus.Inactive) ||
                    (Game.ships[0].lives == 0))
                    Game.GameOver(1);
                else
                    Game.PlayerDestroyed(1);
            }
            else
                Game.PlayerDestroyed(Player);
        }

        private void UpdateSeeker(float TotalGameSeconds, 
            float ElapsedGameSeconds, SeekerState seeker, 
            byte index, Avatar[] players)
        {
            float seekerTurnRate = MathHelper.PiOver2;
            switch (seeker.status)
            {
                case ObjectStatus.Inactive:
                    break;
                case ObjectStatus.Active:
                    float distance = seeker.speed * (float)ElapsedGameSeconds;
                    float currentangle = seeker.angle;

                    // move forward
                    Vector2 forward = VectorFromAngle(currentangle);
                    forward.Normalize();
                    seeker.position += forward * distance;

                    // find player with highest score
                    int leader = (players[0].score > players[1].score) ? 0 : 1;

                    // turn toward player                                        
                    float desiredangle = AngleFromAxis(forward, 
                        players[leader].position - seeker.position);
                    float maxTurnRate = seekerTurnRate * ElapsedGameSeconds;

                    // get the closest to the desired angle I can 
                    // given my turn rate
                    seeker.angle = MathHelper.Clamp(currentangle + desiredangle,
                        currentangle - maxTurnRate, currentangle + maxTurnRate);

                    Game.SeekerMoved(index, seeker.position, seeker.angle);
                    break;
                case ObjectStatus.Dying:
                    // Move the powerup toward the bottom of the screen
                    seeker.position.Y += 
                        ElapsedGameSeconds * Game1.BackgroundDriftRatePerSec;

                    // Check to see if the powerup is expired yet.
                    if (TotalGameSeconds > seeker.deathTimeTotalSeconds + 
                        Enemies.SeekerInfo.TimeToDie)
                    {
                        //seeker.status = ObjectStatus.Inactive;
                        Game.SeekerCrashed(index);
                    }
                    Game.SeekerMoved(index, seeker.position, seeker.angle);
                    break;
                default:
                    break;
            }
        }
        private static float AngleFromAxis(Vector2 axis, Vector2 vector)
        {
            float retval = AbsoluteAngle(vector) - AbsoluteAngle(axis);
            if (retval > MathHelper.Pi)
                return retval - MathHelper.TwoPi;
            if (retval < -MathHelper.Pi)
                return retval + MathHelper.TwoPi;

            return retval;
        }
        private static float AbsoluteAngle(Vector2 a)
        {
            return (float)Math.Atan2(a.Y, a.X);
        }
        private static Vector2 VectorFromAngle(float a)
        {
            return new Vector2((float)Math.Sin(a), (float)-Math.Cos(a));
        }

        public void HandleCollisions(Avatar player, byte playerId, 
            Enemies enemies, float totalGameSeconds)
        {
            // Skip a lot of processing if the player isn't playing
            if (player.status == ObjectStatus.Inactive)
                return;

            for (int j = 0; j < enemies.waves.Length; j++)
            {
                if (enemies.waves[j].status == ObjectStatus.Active)
                {
                    Vector2 enemyPos = Enemies.GetPosition(totalGameSeconds, 
                        enemies.waves[j]);
                    for (int i = 0; i < player.bullets.Count; i++)
                    {
                        {
                            // Did player kill the enemy?
                            if (DetectCollision(player.bullets[i],
                            enemyPos, totalGameSeconds))
                            {
                                player.bullets.RemoveAt(i);
                                Game.EnemyKilled((byte)j, (byte)playerId);
                            }
                        }
                    }
                    // Did the player crash into the enemy?
                    if (DetectCrash(player, enemyPos,
                        Enemies.GetInfoForType(enemies.waves[j].type)))
                    {
                        Game.EnemyKilled((byte)j, (byte)playerId);
                        DestroyPlayer((byte)playerId);
                    }
                }
            }
            for (int k = 0; k < enemies.seekers.Length; k++)
            {
                if (enemies.seekers[k].status == ObjectStatus.Active)
                {
                    for (int l = 0; l < player.bullets.Count; l++)
                    {
                        // Did player kill seeker?
                        if (DetectCollision(player.bullets[l],
                            enemies.seekers[k].position, totalGameSeconds))
                        {
                            Game.SeekerDestroyed((byte)k);                            
                            player.bullets.RemoveAt(l);
                        }
                    }

                }
                // Did the player crash into the seeker?
                if (DetectCrash(player, enemies.seekers[k].position,
                    Enemies.GetInfoForType(EnemyType.Seeker)))
                {
                    // The seeker is live, crash the player
                    if (enemies.seekers[k].status == ObjectStatus.Active)
                    {
                        Game.SeekerCrashed((byte)k);
                        DestroyPlayer((byte)playerId);

                    }
                    // The seeker is a popup, reward the player
                    else if (enemies.seekers[k].status == ObjectStatus.Dying)
                    {
                        Game.IncreaseLife(playerId);
                        Game.SeekerCrashed((byte)k);
                    }
                }
            }
        }

        /// <summary>
        /// Call this method to determine if a bullet hit an enemy
        /// </summary>
        /// <param name="bullet"></param>
        /// <param name="enemy"></param>
        /// <param name="gameTime"></param>
        /// <returns></returns>
        public static bool DetectCollision(Vector3 bullet, Vector2 enemy, 
            double totalGameSeconds)
        {
            Vector2 pos =
                GamePlayHost.FindBulletPosition(bullet, totalGameSeconds);
            if (Vector2.Distance(pos, enemy) < 30)
                return true;

            return false;
        }
        /// <summary>
        /// Call this method to determine if the enemy crashed into the player
        /// </summary>
        /// <param name="enemy"></param>
        /// <param name="gameTime"></param>
        /// <returns></returns>
        public static bool DetectCrash(Avatar player, Vector2 enemy, 
            EnemyInfo enemyType)
        {
            if (player.status == ObjectStatus.Active)
            {
                float distance = Vector2.Distance(player.position, enemy);
                return (distance < Avatar.CrashRadius + enemyType.CrashRadius);
            }
            return false;
        }
        public static float bulletspeed = 300;
        public static Vector2 FindBulletPosition(Vector3 bullet, 
            double totalGameSeconds)
        {
            Vector2 pos = Vector2.Zero;
            pos.X = bullet.X;
            pos.Y = 
                bullet.Y - (bulletspeed * ((float)totalGameSeconds - bullet.Z));
            return pos;
        }        
    }

}
