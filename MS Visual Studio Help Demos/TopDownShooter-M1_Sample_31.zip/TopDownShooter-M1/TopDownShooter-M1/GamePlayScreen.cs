﻿#region File Description
//-----------------------------------------------------------------------------
// Game1.cs
//
// Microsoft XNA Community Game Platform
// Copyright (C) Microsoft Corporation. All rights reserved.
//-----------------------------------------------------------------------------
#endregion

using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Net;
using Microsoft.Xna.Framework.Storage;
using GameStateManagement;

namespace TopDownShooterM1
{
    public class GamePlayMenu : GameScreen
    {
        MenuComponent menu;
        public GamePlayMenu()
        {
            this.IsPopup = true;
        }
        public override void Initialize()
        {
            menu = new MenuComponent(
				this.ScreenManager.Game, this.ScreenManager.Font,
				this.ScreenManager.SpriteBatch);
            menu.AddText("Resume");
            menu.AddText(" Help");
            menu.AddText("Restart");
            menu.AddText(" Quit");
            menu.MenuOptionSelected +=
                new EventHandler<MenuSelection>(menu_MenuOptionSelected);
            menu.MenuCanceled +=
				new EventHandler<MenuSelection>(menu_MenuCanceled);
            menu.Initialize();
            Viewport view = this.ScreenManager.GraphicsDevice.Viewport;
            menu.CenterMenu(view);

            TransitionPosition = 0.5f;
            base.Initialize();
        }

        public override void LoadContent()
        {            
            base.LoadContent();
        }

        public event EventHandler<MenuSelection> MenuOptionSelected;
        void menu_MenuOptionSelected(Object sender, MenuSelection selection)
        {
            MenuOptionSelected.Invoke(this, selection);
            ExitScreen();
        }

        public event EventHandler<MenuSelection> MenuCanceled;
        void menu_MenuCanceled(object sender, EventArgs selection)
        {
            MenuCanceled.Invoke(this, new MenuSelection(-1));
            ExitScreen();
        }

        public override void HandleInput(InputState input)
        {
            menu.HandleInput(input);
            base.HandleInput(input);
        }

        public override void Update(GameTime gameTime, 
            bool otherScreenHasFocus, bool coveredByOtherScreen)
        {            
            menu.Update(gameTime);
            base.Update(gameTime, otherScreenHasFocus, coveredByOtherScreen);
        }

        public override void Draw(GameTime gameTime)
        {
            this.ScreenManager.FadeBackBufferToBlack(127);
            menu.Draw(gameTime);
            base.Draw(gameTime);
        }
    }

    public enum ObjectStatus
    {
        Inactive, Active, Dying, Immune
    }

    public class GamePlayScreen : BackroundScreen
    {
        Game1 game;     

        // Variables to control display and position bounds
        Rectangle uiBounds;

        NeutralInput playerOneInput;
        NeutralInput playerTwoInput;

        private GamePlayMenu menu = null;
        private bool bPaused = false;
        public bool bGameOver = false;
        public Vector2 accumMove;  // Accumulated movement

        public GamePlayScreen(Game1 game)
            : base()
        {
            this.game = game;

            // Only the host can choose to quit to lobby.
            menu = new GamePlayMenu();
            menu.MenuOptionSelected +=
                new EventHandler<MenuSelection>(menu_MenuOptionSelected);
            menu.MenuCanceled +=
                new EventHandler<MenuSelection>(menu_MenuCanceled);
        }

        void menu_MenuCanceled(object sender, System.EventArgs e)
        {
            // Do nothing, game will resume on its own
        }

        void menu_MenuOptionSelected(object sender, MenuSelection e)
        {
            switch (e.Selection)
            {
                case 0: // Resume                    
                    break;
                case 1:
                    ScreenManager.AddScreen(new HelpScreen());
                    break;
                case 2: // Restart
                    game.Restart();                   
                    break;
                case 3: // Quit
                    game.Exit();
                    break;
                default:
                    break;
            }           
        }

        public override void Initialize()
        {
            uiBounds = this.TitleSafeArea;
            base.Initialize();
        }

        Texture2D bullet;
        Texture2D ship;
        Vector2 bulletorigin;
        Vector2 shiporigin;
        Texture2D villain;
        Vector2 villainOrigin;
        Texture2D gameover;
        Vector2 gameoverOrigin;
        SpriteFont arcade;

        public override void LoadContent()
        {

            bullet = game.Content.Load<Texture2D>("Photon");
            ship = game.Content.Load<Texture2D>("Playership");
            shiporigin = new Vector2(ship.Width / 2, ship.Height / 2);
            bulletorigin = new Vector2(bullet.Width / 2, bullet.Height / 2);

            villain = game.Content.Load<Texture2D>("Villain");
			villainOrigin = new Vector2(villain.Width / 2, villain.Height / 2);

            gameover = game.Content.Load<Texture2D>("gameover");
            gameoverOrigin = new Vector2(
					gameover.Width / 2, gameover.Height / 2);

            arcade = game.Content.Load<SpriteFont>("Arcade");
            Explosion.Texture = game.Content.Load<Texture2D>("Explosion");

            base.LoadContent();
        }

        #region Input Processing
        public override void HandleInput(InputState input)
        {
            playerOneInput = ProcessPlayer(game.Main, input);

            if (game.Guest.IsPlaying)
			{
                playerTwoInput = ProcessPlayer(game.Guest, input);
			}

            base.HandleInput(input);
        }
        
        private static NeutralInput ProcessPlayer(Player player, 
            InputState input)
        {
            NeutralInput state;
            state.Fire = false;
            Vector2 stick = Vector2.Zero;
            GamePadState gpState = 
                input.GetCurrentGamePadStates()[(int)player.Controller];

            // Get gamepad state
            stick = gpState.ThumbSticks.Left;
            state.Fire = (gpState.Triggers.Right > 0);

            state.StickMovement = stick;
            return state;
        }
        #endregion

        public override void Update(GameTime gameTime, 
            bool otherScreenHasFocus, bool coveredByOtherScreen)
        {            
            // If the user activates the menu...
            if ((GamePad.GetState(game.Main.Controller).Buttons.Start == 
                ButtonState.Pressed) && !bPaused)
            {
                this.ScreenManager.AddScreen(menu);
				// Use this to keep from adding more than one menu to the stack
                bPaused = game.BeginPause();    
                return;
            }
            bool hidden = coveredByOtherScreen || otherScreenHasFocus;

            // If the user covers this screen, pause.
            if (hidden && !game.IsPaused)
            {                
                bPaused = game.BeginPause();
            }

            // If we're active again, unpause the game.
            if (!hidden && (game.IsPaused))
            {
                bPaused = game.EndPause();         
            }

            if (!game.IsPaused)
            {
                if (game.ships[0].IsPlaying)
				{
                    UpdateShip(
						0, game.TotalGameSeconds,
						(float)gameTime.ElapsedGameTime.TotalSeconds,
						playerOneInput);
				}

                if (game.ships[1].IsPlaying)
                {
                    UpdateShip(
						1, game.TotalGameSeconds,
						(float)gameTime.ElapsedGameTime.TotalSeconds,
						playerTwoInput);
                }
            }

            base.Update(gameTime, otherScreenHasFocus, coveredByOtherScreen);
        }

        #region Ship-centric code
        public void UpdateShip(int player, float totalGameSeconds, 
            float elapsedGameSeconds, NeutralInput input)
        {
            if ((game.ships[player].status == ObjectStatus.Active) ||
                (game.ships[player].status == ObjectStatus.Immune))
            {
				ProcessInput(
					player, totalGameSeconds, elapsedGameSeconds, input);
            }            
        }
        /// <summary>
		/// This function takes a NeutralInput structure for a player and turns
		/// that data into ship commands
        /// </summary>
        /// <param name="Player">The player giving the input.</param>
        /// <param name="TotalGameSeconds">The current game time.</param>
        /// <param name="ElapsedGameSeconds">The game time elapsed since the last Update.</param>
        /// <param name="input">The input structure for the player.</param>
        public void ProcessInput(int player, float totalGameSeconds, 
            float elapsedGameSeconds, NeutralInput input)
        {
            if (input.StickMovement.X > 0)
			{
                accumMove.X += Move(input.StickMovement.X, elapsedGameSeconds);
			}
			else if (input.StickMovement.X < 0)
			{
                accumMove.X -= Move(-input.StickMovement.X, elapsedGameSeconds);
			}

            if (input.StickMovement.Y > 0)
			{
                accumMove.Y -= Move(input.StickMovement.Y, elapsedGameSeconds);
			}
			else if (input.StickMovement.Y < 0)
			{
                accumMove.Y += Move(-input.StickMovement.Y, elapsedGameSeconds);
			}

            TryMove(player);

            if (input.Fire == true)
            {
                TryFire((byte)player, totalGameSeconds);
            }
        }

        private static float Move(float input, float elapsedGameSeconds)
        {
            return input * elapsedGameSeconds * Avatar.PixelsPerSecond;
        }             

        private void TryMove(int player)
        {
            if (accumMove.Length() > .5)
            {                
                // Find out how far we are allowed to move
                Vector2 move = game.ships[player].VerifyMove(accumMove);

                // Send our movement event to Game1
                Vector2 pos = game.ships[player].position + move;                
                game.ShipMove((byte)player, pos);
                
                // Zero out accumulated input
                accumMove = Vector2.Zero;
            }
        }

        private void TryFire(byte player, float totalGameSeconds)
        {
            if (game.ships[player].status != ObjectStatus.Active)
			{
                return;
			}

			// if the time between the last shot and the current 
            // time is less than 1/ROF, don't fire                        
            if (game.ships[player].VerifyFire(totalGameSeconds))
            {
                game.ShipFire(player, totalGameSeconds);
            }
        }

#endregion

        public override void Draw(GameTime gameTime)
        {
            base.Draw(gameTime);

            // Draw each player
            DrawPlayer(game.ships[0], game.TotalGameSeconds);
            DrawPlayer(game.ships[1], game.TotalGameSeconds);

            // Draw the enemies
            DrawEnemies(game.TotalGameSeconds);

            // Draw each player's bullets
            DrawBullets(game.ships[0].bullets, game.TotalGameSeconds);
            DrawBullets(game.ships[1].bullets, game.TotalGameSeconds);

            // Draw the score
            DrawUI();

            // If the game is over, draw a special graphic
            DrawGameOver();
        }

        #region Drawing Code

        private void DrawGameOver()
        {
            if (bGameOver)
            {
                this.ScreenManager.FadeBackBufferToBlack(64);

                this.ScreenManager.SpriteBatch.Begin(
                    SpriteBlendMode.AlphaBlend);

                Vector2 UICenter = new Vector2(
                    uiBounds.X + uiBounds.Width / 2, 
                    uiBounds.Y + uiBounds.Height / 2);

				this.ScreenManager.SpriteBatch.Draw(
					gameover, UICenter, null, Color.Red, 0, gameoverOrigin,
					1.0f, SpriteEffects.None, 1.0f);

                this.ScreenManager.SpriteBatch.End();
            }

        }

        private void DrawPlayer(Avatar state, double totalGameSeconds)
        {
			// Initialize our own SpriteBatch.  We want default Alpha blending,
			// and the render states set by SpriteBatch to be reset when End()
			// is called.
            SpriteBatch batch = this.ScreenManager.SpriteBatch;

            batch.Begin(
				SpriteBlendMode.AlphaBlend, SpriteSortMode.Deferred,
				SaveStateMode.SaveState);

            switch (state.status)
            {
			case ObjectStatus.Inactive:  
				break; // Draw nothing
			case ObjectStatus.Active:
				// Draws our avatar at the current position with no tinting
				batch.Draw(
					ship, state.position, null, state.color, 0, shiporigin,
					1.0f, SpriteEffects.None, 0.5f);
				break;
			case ObjectStatus.Dying:
				Explosion.Draw(
					batch, state.position, 0, totalGameSeconds,
					state.deathTimeTotalSeconds, state.deathTimeTotalSeconds +
					Avatar.RespawnTime);
				break;
			case ObjectStatus.Immune://blink 5 times per second
				if (((int)(totalGameSeconds * 10) % 2) == 0) 
				{
					batch.Draw(
						ship, state.position, null, Color.Silver, 0, shiporigin,
						1.0f, SpriteEffects.None, 0.5f);
				}
				break;
			default:
				break;
            }

            batch.End();
        }       

        private void DrawBullets(List<Vector3> bullets, double TotalGameSeconds)
        {
            SpriteBatch batch = this.ScreenManager.SpriteBatch;
            batch.Begin();
            Vector2 pos;
            for (int i = 0; i < bullets.Count; i++)
            {
                pos = GamePlayHost.FindBulletPosition(bullets[i], 
                    TotalGameSeconds);
                if (pos.Y > -10) // bullet is far off the top of the screen
                {
                    batch.Draw(
						bullet, pos, null, Color.White, 0, bulletorigin, 1.0f,
						SpriteEffects.None, 0.6f);
                }
                else
                {
                    // Since we are iterating each bullet anyway, now is a 
                    // good time to remove bullets that go offscreen.
                    bullets.RemoveAt(i);
                }
            }
            batch.End();
        }

        private void DrawEnemies(float TotalGameSeconds)
        {
            SpriteBatch batch = this.ScreenManager.SpriteBatch;
            batch.Begin();
            // Draw first enemy type
            foreach (EnemyState enemy in game.enemies.waves)
            {
                Vector2 pos = Enemies.GetPosition(TotalGameSeconds, enemy);
                if (enemy.status == ObjectStatus.Active)
                {
                    batch.Draw(
						villain, pos, null, Color.White, 0, villainOrigin, 1.0f,
						SpriteEffects.None, .6f);
                }
                else if (enemy.status == ObjectStatus.Dying)
                {
                    // I'm exploding!
                    Explosion.Draw(
						batch, pos, enemy.deathTimeTotalSeconds,
						TotalGameSeconds, enemy.deathTimeTotalSeconds,
						enemy.deathTimeTotalSeconds + 1.5);
                }
            }
            // Draw seekers, if any
            foreach (SeekerState seeker in game.enemies.seekers)
            {
                if (seeker.status == ObjectStatus.Active)
                {
                    batch.Draw(
						villain, seeker.position, null, Color.LightGreen,
						seeker.angle, villainOrigin, 1.0f, SpriteEffects.None,
						0.6f);

                }
                else if (seeker.status == ObjectStatus.Dying)
                {
                    // Draw the powerup
                    batch.Draw(
						villain, seeker.position, null, Color.White,
						seeker.angle, villainOrigin, 0.5f, SpriteEffects.None,
						0.6f);

                    // Draw the explosion
                    Explosion.Draw(
						batch, seeker.position, seeker.deathTimeTotalSeconds,
						TotalGameSeconds, seeker.deathTimeTotalSeconds,
						seeker.deathTimeTotalSeconds + 0.5);
                }
            }
            batch.End();
        }

        private void DrawUI()
        {
            string P2Text = (game.ships[1].Player.IsPlaying) ? "2P " + 
                game.ships[1].score.ToString("000000") :
                "2P Press Start";
            P2Text += "\n\r" + game.ships[1].Player.Name;
            P2Text += "\n\r" + game.ships[1].lives.ToString() + " lives";

            string P1Text = "1P " + game.ships[0].score.ToString("000000");

            P1Text += "\n\r" + game.ships[0].Player.Name;
            P1Text += "\n\r" + game.ships[0].lives.ToString() + " lives";            
            
            Vector2 Pos = new Vector2(uiBounds.X, uiBounds.Y+10);

            SpriteBatch batch = this.ScreenManager.SpriteBatch;
            batch.Begin(
				SpriteBlendMode.AlphaBlend, SpriteSortMode.Deferred,
				SaveStateMode.SaveState);
            batch.DrawString(arcade, P1Text, Pos, Color.Pink);
            
            // Gamertags can be 15 characters            
            int gamertagwidth = 
                (int)(arcade.MeasureString("123456789012345").X);
            Pos.X = uiBounds.Right - gamertagwidth;

            batch.DrawString(arcade, P2Text, Pos, Color.Pink);
            batch.End();
        }
        #endregion
    }
}
