﻿#region File Description
//-----------------------------------------------------------------------------
// Game1.cs
//
// Microsoft XNA Community Game Platform
// Copyright (C) Microsoft Corporation. All rights reserved.
//-----------------------------------------------------------------------------
#endregion

using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace ScriptedCamera
{
    /// <summary>
    /// This is the main type for your game
    /// </summary>
    public class Game1 : Microsoft.Xna.Framework.Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;
        Model sphere;
        Texture2D sphereTexture;

        Matrix view;
        Matrix proj;

        double time;

        // Set information about the game window.
        static int screenWidth = 800;
        static int screenHeight = 600;
        static float aspectRatio = (float)screenWidth / (float)screenHeight;

        // Set field of view of the camera in radians (pi/4 is 45 degrees).
        static float FOV = MathHelper.PiOver4;

        // Set z-values of the near and far clipping planes.
        static float nearClip = 5.0f;
        static float farClip = 1000.0f;


        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
        }

        protected override void Initialize()
        {
            InitCurve();

            base.Initialize();
        }


        Curve3D cameraCurvePosition = new Curve3D();
        Curve3D cameraCurveLookat = new Curve3D();
        // Specify the points the camera will pass through
        // and the points that the camera is looking at.
        // The number of points on the position and look-at curves
        // don't need to match, but the first and last points on the
        // curves should have the same time values if the curves oscillate.
        void InitCurve()
        {
            float time = 0;
            cameraCurvePosition.AddPoint(new Vector3(7.5f, 0, -45), time);
            cameraCurveLookat.AddPoint(new Vector3(9, 0, 9), time);
            time += 2000;
            cameraCurvePosition.AddPoint(new Vector3(3f, 0, -36), time);
            time += 2000;
            cameraCurvePosition.AddPoint(new Vector3(12f, 0, -30), time);
            time += 2000;
            cameraCurvePosition.AddPoint(new Vector3(3f, 0, -24), time);
            time += 2000;
            cameraCurvePosition.AddPoint(new Vector3(12f, 0, -18), time);
            time += 2000;
            cameraCurvePosition.AddPoint(new Vector3(7.5f, 0, -12), time);
            time += 2000;
            cameraCurvePosition.AddPoint(new Vector3(-6, 0, -6), time);
            cameraCurveLookat.AddPoint(new Vector3(0, 0, 15), time);
            time += 3000;
            cameraCurvePosition.AddPoint(new Vector3(-27, 0, 6f), time);
            time += 3000;
            cameraCurvePosition.AddPoint(new Vector3(-6, 0, 21), time);
            time += 2000;
            cameraCurvePosition.AddPoint(new Vector3(7.5f, 0, 27), time);
            time += 2000;
            cameraCurvePosition.AddPoint(new Vector3(21, 0, 21), time);
            time += 3000;
            cameraCurvePosition.AddPoint(new Vector3(42, 0, 6f), time);
            time += 3000;
            cameraCurvePosition.AddPoint(new Vector3(21, 0, -6), time);
            cameraCurveLookat.AddPoint(new Vector3(15, 0, 15), time);

            cameraCurvePosition.SetTangents();
            cameraCurveLookat.SetTangents();
        }
        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);

            sphere = Content.Load<Model>("sphere");
            sphereTexture = Content.Load<Texture2D>("spheretexture");
        }


        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            // Allows the game to exit
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == 
                ButtonState.Pressed)
                this.Exit();

            UpdateCameraCurve(gameTime);

            base.Update(gameTime);
        }
        void UpdateCameraCurve(GameTime gameTime)
        {
            // Calculate the camera's current position.
            Vector3 cameraPosition = 
                cameraCurvePosition.GetPointOnCurve((float)time);
            Vector3 cameraLookat = 
                cameraCurveLookat.GetPointOnCurve((float)time);

            // Set up the view matrix and projection matrix.
            view = Matrix.CreateLookAt(cameraPosition, cameraLookat, 
                new Vector3(0.0f, 1.0f, 0.0f));

            proj = Matrix.CreatePerspectiveFieldOfView(FOV, aspectRatio, 
                nearClip, farClip);

            time += gameTime.ElapsedGameTime.TotalMilliseconds;
        }

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(ClearOptions.Target | ClearOptions.DepthBuffer,
                new Vector4(0, 0, 0, 255), 1.0f, 0);

            for (int z = 0; z < 5; z++)
            {
                for (int x = 0; x < 5; x++)
                {
                    DrawModel(sphere, Matrix.CreateTranslation(
                        new Vector3(x * 3, 0, z * 3)), sphereTexture);
                }
            }


            base.Draw(gameTime);
        }
        void DrawModel(Model model, Matrix world, Texture2D texture)
        {
            foreach (ModelMesh mesh in model.Meshes)
            {
                foreach (BasicEffect be in mesh.Effects)
                {
                    be.Projection = proj;
                    be.View = view;
                    be.World = world;
                    be.Texture = texture;
                    be.TextureEnabled = true;
                }
                mesh.Draw();
            }
        }
    }
}
