﻿#region File Description
//-----------------------------------------------------------------------------
// Game1.cs
//
// Microsoft XNA Community Game Platform
// Copyright (C) Microsoft Corporation. All rights reserved.
//-----------------------------------------------------------------------------
#endregion

using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Net;
using Microsoft.Xna.Framework.Storage;

namespace ApplyAnEffect
{
    /// <summary>
    /// This is the main type for your game
    /// </summary>
    public class Game1 : Microsoft.Xna.Framework.Game
    {
        GraphicsDeviceManager graphics;

        Matrix worldViewProjection;
        Effect effect;
        VertexDeclaration cubeVertexDeclaration;
        VertexPositionColor[] cubeVertices;
        VertexBuffer vertexBuffer;
        short[] cubeIndices;
        IndexBuffer indexBuffer;

        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
        }

        protected override void Initialize()
        {
            // TODO: Add your initialization logic here

            base.Initialize();
        }

        /// <summary>
        /// Initializes the transforms used for the 3D model.
        /// </summary>
        private void InitializeTransform()
        {
            float tilt = (float)Math.PI / 8.0f;
            // Use the world matrix to tilt the cube along x and y axes.
            Matrix world = Matrix.CreateRotationX(tilt) *
                Matrix.CreateRotationY(tilt);

            Matrix view = Matrix.CreateLookAt(new Vector3(0, 0, 5), 
                Vector3.Zero, Vector3.Up);

            Matrix projection = Matrix.CreatePerspectiveFieldOfView(
                (float)Math.PI / 4.0f,  // 2 PI Radians is 360 degrees,
                                        // so this is 45 degrees.
                (float)GraphicsDevice.Viewport.Width /
                (float)GraphicsDevice.Viewport.Height,
                1.0f, 100.0f);

            worldViewProjection = world * view * projection;
        }

        private void InitializeEffect()
        {
            effect = Content.Load<Effect>("ReallySimpleEffect");

            effect.Parameters["WorldViewProj"].SetValue(worldViewProjection);

            effect.CurrentTechnique = effect.Techniques["TransformTechnique"];
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            InitializeTransform();
            InitializeEffect();
            InitializeCube();
        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// all content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }

        /// <summary>
        /// Initializes the vertices and indices of the 3D model.
        /// </summary>
        private void InitializeCube()
        {
            cubeVertexDeclaration = new VertexDeclaration(
                GraphicsDevice, VertexPositionColor.VertexElements);

            cubeVertices = new VertexPositionColor[24];

            Vector3 topLeftFront = new Vector3(-1.0f, 1.0f, 1.0f);
            Vector3 bottomLeftFront = new Vector3(-1.0f, -1.0f, 1.0f);
            Vector3 topRightFront = new Vector3(1.0f, 1.0f, 1.0f);
            Vector3 bottomRightFront = new Vector3(1.0f, -1.0f, 1.0f);
            Vector3 topLeftBack = new Vector3(-1.0f, 1.0f, -1.0f);
            Vector3 topRightBack = new Vector3(1.0f, 1.0f, -1.0f);
            Vector3 bottomLeftBack = new Vector3(-1.0f, -1.0f, -1.0f);
            Vector3 bottomRightBack = new Vector3(1.0f, -1.0f, -1.0f);

            cubeVertices[0] = new VertexPositionColor(topLeftFront, Color.Red);
            cubeVertices[1] = new VertexPositionColor(bottomLeftFront, Color.Red);
            cubeVertices[2] = new VertexPositionColor(topRightFront, Color.Red);
            cubeVertices[3] = new VertexPositionColor(bottomRightFront, Color.Red);

            cubeVertices[4] = new VertexPositionColor(topLeftBack, Color.Orange);
            cubeVertices[5] = new VertexPositionColor(topRightBack, Color.Orange);
            cubeVertices[6] = new VertexPositionColor(bottomLeftBack, Color.Orange);
            cubeVertices[7] = new VertexPositionColor(bottomRightBack, Color.Orange);

            cubeVertices[8] = new VertexPositionColor(topLeftFront, Color.Yellow);
            cubeVertices[9] = new VertexPositionColor(topRightBack, Color.Yellow);
            cubeVertices[10] = new VertexPositionColor(topLeftBack, Color.Yellow);
            cubeVertices[11] = new VertexPositionColor(topRightFront, Color.Yellow);

            cubeVertices[12] = new VertexPositionColor(bottomLeftFront, Color.Purple);
            cubeVertices[13] = new VertexPositionColor(bottomLeftBack, Color.Purple);
            cubeVertices[14] = new VertexPositionColor(bottomRightBack, Color.Purple);
            cubeVertices[15] = new VertexPositionColor(bottomRightFront, Color.Purple);

            cubeVertices[16] = new VertexPositionColor(topLeftFront, Color.Blue);
            cubeVertices[17] = new VertexPositionColor(bottomLeftBack, Color.Blue);
            cubeVertices[18] = new VertexPositionColor(bottomLeftFront, Color.Blue);
            cubeVertices[19] = new VertexPositionColor(topLeftBack, Color.Blue);

            cubeVertices[20] = new VertexPositionColor(topRightFront, Color.Green);
            cubeVertices[21] = new VertexPositionColor(bottomRightFront, Color.Green);
            cubeVertices[22] = new VertexPositionColor(bottomRightBack, Color.Green);
            cubeVertices[23] = new VertexPositionColor(topRightBack, Color.Green);

            cubeIndices = new short[] {  0,  1,  2,  // red front face
                                     1,  3,  2,
                                     4,  5,  6,  // orange back face
                                     6,  5,  7,
                                     8,  9, 10,  // yellow top face
                                     8, 11,  9,
                                    12, 13, 14,  // purple bottom face
                                    12, 14, 15,
                                    16, 17, 18,  // blue left face
                                    19, 17, 16,
                                    20, 21, 22,  // green right face
                                    23, 20, 22  };

            vertexBuffer = new VertexBuffer(
                GraphicsDevice,
                cubeVertices.Length * VertexPositionColor.SizeInBytes,
                BufferUsage.None);

            vertexBuffer.SetData<VertexPositionColor>(cubeVertices);

            indexBuffer = new IndexBuffer(GraphicsDevice,
                sizeof(short) * cubeIndices.Length,
                BufferUsage.None,
                IndexElementSize.SixteenBits);

            indexBuffer.SetData<short>(cubeIndices);

        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            // Allows the game to exit
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == 
                ButtonState.Pressed)
                this.Exit();

            // TODO: Add your update logic here

            base.Update(gameTime);
        }

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);
            GraphicsDevice.RenderState.CullMode =
                CullMode.CullClockwiseFace;

            GraphicsDevice.VertexDeclaration =
                    cubeVertexDeclaration;
            GraphicsDevice.Indices = indexBuffer;
            GraphicsDevice.Vertices[0].SetSource(vertexBuffer, 0, 
                VertexPositionColor.SizeInBytes);

            // The effect is a compiled effect created and compiled elsewhere
            // in the application.

            effect.Begin();
            foreach (EffectPass pass in effect.CurrentTechnique.Passes)
            {
                pass.Begin();

                GraphicsDevice.DrawIndexedPrimitives(
                    PrimitiveType.TriangleList,
                    0,
                    0,
                    cubeVertices.Length,
                    0,
                    12);

                pass.End();
            }
            effect.End();

            base.Draw(gameTime);
        }
    }
}
