//-----------------------------------------------------------------------------
// xDemo : imagine cup 2004
// basic directx 9 tutorial
//
// shailesh saini
// michigan state university
// created:   11.11.03
// last edit: 12.10.03
//
// uses code from microsoft dx9 sdk tutorials
// copyright (c) microsoft corporation. all rights reserved.
//-----------------------------------------------------------------------------
#include <windows.h>
#include <mmsystem.h>
#include <d3dx9.h>
#include <string>

using namespace std;

//-----------------------------------------------------------------------------
// global variables
//-----------------------------------------------------------------------------
LPDIRECT3D9             g_pD3D       = NULL; // used to create the D3DDevice
LPDIRECT3DDEVICE9       g_pd3dDevice = NULL; // our rendering device
LPDIRECT3DVERTEXBUFFER9 g_pVB        = NULL; // buffers to hold vertices
LPDIRECT3DTEXTURE9      g_pTexture   = NULL; // textures

// a structure for our custom vertex type. We added a normal, and omitted the
// color (which is provided by the material)
struct CUSTOMVERTEX
{
    D3DXVECTOR3 position; // the 3D position for the vertex
    D3DXVECTOR3 normal;   // the surface normal for the vertex
	D3DCOLOR    color;    // the color
	FLOAT       tu, tv;   // the texture coordinates
};

// Our custom FVF, which describes our custom vertex structure
#define D3DFVF_CUSTOMVERTEX (D3DFVF_XYZ|D3DFVF_NORMAL|D3DFVF_DIFFUSE|D3DFVF_TEX1)

//-----------------------------------------------------------------------------
// name: InitD3D()
// desc: initializes Direct3D
//-----------------------------------------------------------------------------
HRESULT InitD3D( HWND hWnd )
{
    // create the D3D object
    if( NULL == ( g_pD3D = Direct3DCreate9( D3D_SDK_VERSION ) ) )
        return E_FAIL;

    // set up the structure used to create the D3DDevice. a zBuffer will
	// be created to hold the geometry object
    D3DPRESENT_PARAMETERS d3dpp;
    ZeroMemory( &d3dpp, sizeof(d3dpp) );
    d3dpp.Windowed = TRUE;
    d3dpp.SwapEffect = D3DSWAPEFFECT_DISCARD;
    d3dpp.BackBufferFormat = D3DFMT_UNKNOWN;
    d3dpp.EnableAutoDepthStencil = TRUE;
    d3dpp.AutoDepthStencilFormat = D3DFMT_D16;

    // create the D3DDevice
    if( FAILED( g_pD3D->CreateDevice( D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, hWnd,
                                      D3DCREATE_SOFTWARE_VERTEXPROCESSING,
                                      &d3dpp, &g_pd3dDevice ) ) )
    {
        return E_FAIL;
    }

    // turn off culling
    g_pd3dDevice->SetRenderState( D3DRS_CULLMODE, D3DCULL_NONE );

    // turn on the zbuffer
    g_pd3dDevice->SetRenderState( D3DRS_ZENABLE, TRUE );

    return S_OK;
}

//-----------------------------------------------------------------------------
// name: CreatePlane()
// desc: creates a plane with the specified parameters
//-----------------------------------------------------------------------------
HRESULT CreatePlane(string tex)
{
	// use D3DX to create a texture from a file based image
	if( FAILED( D3DXCreateTextureFromFile( g_pd3dDevice, tex.c_str(), &g_pTexture ) ) )
    {
		MessageBox(NULL, "A texture failed to load", "xDemo : Error", MB_OK);
		return E_FAIL;
	}

	// create a vertex buffer.
    if( FAILED( g_pd3dDevice->CreateVertexBuffer( 4*sizeof(CUSTOMVERTEX),
                                                  0, D3DFVF_CUSTOMVERTEX,
                                                  D3DPOOL_DEFAULT, &g_pVB, NULL ) ) )
    {
        return E_FAIL;
    }

	// fill the vertex buffer. this process generates a plane
    CUSTOMVERTEX* pVertices;
    if( FAILED( g_pVB->Lock( 0, 0, (void**)&pVertices, 0 ) ) )
        return E_FAIL;
    
	pVertices[0].position = D3DXVECTOR3( -2.0f,0.0f,-2.0f );
	pVertices[0].normal   = D3DXVECTOR3( 0.0f,1.0f,0.0f );
	pVertices[0].color    = 0xffffffff;
	pVertices[0].tu       = 0.0f;
	pVertices[0].tv       = 0.0f;

	pVertices[1].position = D3DXVECTOR3( -2.0f,0.0f,2.0f );
	pVertices[1].normal   = D3DXVECTOR3( 0.0f,1.0f,0.0f );
	pVertices[1].color    = 0xffffffff;
	pVertices[1].tu       = 0.0f;
	pVertices[1].tv       = 1.0f;

	pVertices[2].position = D3DXVECTOR3( 2.0f,0.0f,-2.0f );
	pVertices[2].normal   = D3DXVECTOR3( 0.0f,1.0f,0.0f );
	pVertices[2].color    = 0xffffffff;
	pVertices[2].tu       = 1.0f;
	pVertices[2].tv       = 0.0f;

	pVertices[3].position = D3DXVECTOR3( 2.0f,0.0f,2.0f );
	pVertices[3].normal   = D3DXVECTOR3( 0.0f,1.0f,0.0f );
	pVertices[3].color    = 0xffffffff;
	pVertices[3].tu       = 1.0f;
	pVertices[3].tv       = 1.0f;

    g_pVB->Unlock();

	return S_OK;
}

//-----------------------------------------------------------------------------
// name: InitGeometry()
// desc: creates the scene geometry
//-----------------------------------------------------------------------------
HRESULT InitGeometry()
{
	if ( FAILED( CreatePlane("tex\\dx_logo.bmp" ) ) )
	{
		return E_FAIL;
	}

    return S_OK;
}

//-----------------------------------------------------------------------------
// name: Cleanup()
// desc: releases all previously initialized objects
//-----------------------------------------------------------------------------
VOID Cleanup()
{
	if( g_pTexture != NULL )
        g_pTexture->Release();

    if( g_pVB != NULL )
        g_pVB->Release();

    if( g_pd3dDevice != NULL )
        g_pd3dDevice->Release();

    if( g_pD3D != NULL )
        g_pD3D->Release();
}


//-----------------------------------------------------------------------------
// name: SetupMatrices()
// desc: sets up the world, view, and projection transform matrices.
//-----------------------------------------------------------------------------
VOID SetupMatrices()
{
    // for our world matrix, we will just leave it as the identity
    D3DXMATRIXA16 matWorld;
    D3DXMatrixIdentity( &matWorld );
    D3DXMatrixRotationX( &matWorld, 90.0f );
    g_pd3dDevice->SetTransform( D3DTS_WORLD, &matWorld );

    // set up our view matrix. a view matrix can be defined given an eye point,
    // a point to lookat, and a direction for which way is up. here, we set the
    // eye five units back along the z-axis and up three units, look at the
    // origin, and define "up" to be in the y-direction.
    D3DXVECTOR3 vEyePt( 0.0f, 3.0f,-5.0f );
    D3DXVECTOR3 vLookatPt( 0.0f, 0.0f, 0.0f );
    D3DXVECTOR3 vUpVec( 0.0f, 1.0f, 0.0f );
    D3DXMATRIXA16 matView;
    D3DXMatrixLookAtLH( &matView, &vEyePt, &vLookatPt, &vUpVec );
    g_pd3dDevice->SetTransform( D3DTS_VIEW, &matView );

    // for the projection matrix, we set up a perspective transform (which
    // transforms geometry from 3D view space to 2D viewport space, with
    // a perspective divide making objects smaller in the distance). to build
    // a perpsective transform, we need the field of view (1/4 pi is common),
    // the aspect ratio, and the near and far clipping planes (which define at
    // what distances geometry should be no longer be rendered).
    D3DXMATRIXA16 matProj;
    D3DXMatrixPerspectiveFovLH( &matProj, D3DX_PI/4, 1.0f, 1.0f, 100.0f );
    g_pd3dDevice->SetTransform( D3DTS_PROJECTION, &matProj );
}


//-----------------------------------------------------------------------------
// name: SetupLights()
// desc: sets up the lights and materials for the scene.
//-----------------------------------------------------------------------------
VOID SetupLights()
{
    // set up a material. the material here just has the diffuse and ambient
    // colors set to yellow. note that only one material can be used at a time.
    D3DMATERIAL9 mtrl;
    ZeroMemory( &mtrl, sizeof(D3DMATERIAL9) );
    mtrl.Diffuse.r = mtrl.Ambient.r = 1.0f;
    mtrl.Diffuse.g = mtrl.Ambient.g = 1.0f;
    mtrl.Diffuse.b = mtrl.Ambient.b = 0.0f;
    mtrl.Diffuse.a = mtrl.Ambient.a = 1.0f;
    g_pd3dDevice->SetMaterial( &mtrl );

    // set up a white, directional light, with an oscillating direction.
    // note that many lights may be active at a time (but each one slows down
    // the rendering of our scene). however, here we are just using one. Also,
    // we need to set the D3DRS_LIGHTING renderstate to enable lighting
    D3DXVECTOR3 vecDir;
    D3DLIGHT9 light;
    ZeroMemory( &light, sizeof(D3DLIGHT9) );
    light.Type       = D3DLIGHT_DIRECTIONAL;
    light.Diffuse.r  = 1.0f;
    light.Diffuse.g  = 1.0f;
    light.Diffuse.b  = 1.0f;
    vecDir = D3DXVECTOR3(cosf(timeGetTime()/350.0f),
                         1.0f,
                         sinf(timeGetTime()/350.0f) );
    D3DXVec3Normalize( (D3DXVECTOR3*)&light.Direction, &vecDir );
    light.Range       = 1000.0f;
    g_pd3dDevice->SetLight( 0, &light );
    g_pd3dDevice->LightEnable( 0, TRUE );
    g_pd3dDevice->SetRenderState( D3DRS_LIGHTING, TRUE );

    // finally, turn on some ambient light.
    g_pd3dDevice->SetRenderState( D3DRS_AMBIENT, 0x20202020 );
}


//-----------------------------------------------------------------------------
// name: Render()
// desc: draws the scene
//-----------------------------------------------------------------------------
VOID Render()
{
    // clear the backbuffer and the zbuffer
    g_pd3dDevice->Clear( 0, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER,
                         D3DCOLOR_XRGB(0,0,255), 1.0f, 0 );

    // begin the scene
    if( SUCCEEDED( g_pd3dDevice->BeginScene() ) )
    {
        // setup the lights and materials
        SetupLights();

        // setup the world, view, and projection matrices
        SetupMatrices();

		// setup our texture. using textures introduces the texture stage states,
        // which govern how textures get blended together (in the case of multiple
        // textures) and lighting information. in this case, we are modulating
        // (blending) our texture with the diffuse color of the vertices.
		g_pd3dDevice->SetTexture( 0, g_pTexture );

        // render the vertex buffer contents
        g_pd3dDevice->SetStreamSource( 0, g_pVB, 0, sizeof(CUSTOMVERTEX) );
        g_pd3dDevice->SetFVF( D3DFVF_CUSTOMVERTEX );
		g_pd3dDevice->DrawPrimitive( D3DPT_TRIANGLESTRIP, 0, 2 );

        // end the scene
        g_pd3dDevice->EndScene();
    }

    // present the backbuffer contents to the display
    g_pd3dDevice->Present( NULL, NULL, NULL, NULL );
}


//-----------------------------------------------------------------------------
// name: MsgProc()
// desc: the window's message handler
//-----------------------------------------------------------------------------
LRESULT WINAPI MsgProc( HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam )
{
    switch( msg )
    {
        case WM_DESTROY:
            Cleanup();
            PostQuitMessage( 0 );
            return 0;
    }

    return DefWindowProc( hWnd, msg, wParam, lParam );
}


//-----------------------------------------------------------------------------
// name: WinMain()
// desc: the application's entry point
//-----------------------------------------------------------------------------
INT WINAPI WinMain( HINSTANCE hInst, HINSTANCE, LPSTR, INT )
{
    // register the window class
    WNDCLASSEX wc = { sizeof(WNDCLASSEX), CS_CLASSDC, MsgProc, 0L, 0L,
                      GetModuleHandle(NULL), NULL, NULL, NULL, NULL,
                      "xDemo", NULL };
    RegisterClassEx( &wc );

    // create the application's window
	HWND hWnd = CreateWindow( "xDemo", "xDemo : Imagine Cup 2004",
                              WS_OVERLAPPEDWINDOW, 100, 100, 300, 300,
                              GetDesktopWindow(), NULL, wc.hInstance, NULL );

    // initialize Direct3D
    if( SUCCEEDED( InitD3D( hWnd ) ) )
    {
        // create the geometry
        if( SUCCEEDED( InitGeometry() ) )
        {
            // show the window
            ShowWindow( hWnd, SW_SHOWDEFAULT );
            UpdateWindow( hWnd );

            // enter the message loop
            MSG msg;
            ZeroMemory( &msg, sizeof(msg) );
            while( msg.message!=WM_QUIT )
            {
                if( PeekMessage( &msg, NULL, 0U, 0U, PM_REMOVE ) )
                {
                    TranslateMessage( &msg );
                    DispatchMessage( &msg );
                }
                else
                    Render();
            }
        }
    }

    UnregisterClass( "xDemo", wc.hInstance );
    return 0;
}