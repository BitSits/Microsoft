D3D Tutorial
Microsoft Imagine Cup 2004

1. D3D_Tutorial.doc contains the actual tutorial
2. The application folder has two subfolders, source and exe
3. The exe folder has the completed exe that is the result of the tutorial
4. The source folder has the source used to create the exe and is the end result of following the tutorial
5. The sample textures folder has a couple of textures for reference purposes

shailesh saini | shailesh@msu.edu