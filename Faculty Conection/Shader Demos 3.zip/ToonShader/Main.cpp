//--------------------------------------------------------------------------------------
//	Toon Shader - ITB747
//
//	Author: Michael Samiec - QUT
//	Version: 1.0
//	Date: 12/5/07
//
//	This program demonstrates toon shading. As the name implies, toon shading renders the
//	object in blocks of colours, with sharp edges, to give it a cartoon-like feel. The effect 
//	is created by calculating the usual diffuse and specular components for each pixel and 
//	using them as a lookup value for a 1 bit colour ramp. These returned values are then 
//	applied to the object's material colours to generate the final colour. An additional edge 
//	calculation is performed to check if the pixel's normal is close to perpendicular vector 
//	of the 'to-camera' vector, and if so, is shaded black.
//
//	This program is based upon the EmptyProject template provided by Microsoft Corporation 
//	through the DirectX Sample Browser. The program is also based upon DXUT (DirectX Utility
//	Toolkit) and the related files can be found in \common. 
//
//	Copyright (c) Microsoft Corporation. All rights reserved.
//--------------------------------------------------------------------------------------
#include "dxstdafx.h"

// Added function signatures

HRESULT RenderText();
void	InitApp();

// Global variables

LPD3DXEFFECT					g_pEffect = NULL;		// effect pointer that encapsulates the shader
LPD3DXFONT						g_pFont = NULL;			// font used for drawing text on screen

// meshes
LPD3DXMESH						g_pMeshTeapot = NULL;
LPD3DXMESH						g_pMeshSphere = NULL;
LPD3DXMESH						g_pMeshTorus = NULL;
LPD3DXMESH						g_pMeshCylinder = NULL;

// textures used for light component lookup tables
LPDIRECT3DTEXTURE9				g_pTexDiffuse = NULL;
LPDIRECT3DTEXTURE9				g_pTexSpecular = NULL;
LPDIRECT3DTEXTURE9				g_pTexEdge = NULL;

// handles to variables within effect
D3DXHANDLE						g_handleMatWVP = NULL;
D3DXHANDLE						g_handleMatWIT = NULL;
D3DXHANDLE						g_handleMatWorld = NULL;

D3DXHANDLE						g_handleLightDir = NULL;

// mesh colour settings
D3DXCOLOR						g_colMatDif = D3DXCOLOR(0.3f, 0.7f, 0.1f, 1.0f);
D3DXCOLOR						g_colMatSpe = D3DXCOLOR(1.0f, 1.0f, 1.0f, 1.0f);

// font colour
D3DCOLOR						g_colourFont = D3DCOLOR_XRGB(256, 256, 256);

// camera variables
D3DXVECTOR3						g_vecCamPos	(0.0f, 0.0f, 0.0f);
D3DXVECTOR3						g_vecCamLook(0.0f, 0.0f, 1.0f);
D3DXVECTOR3						g_vecCamUp	(0.0f, 1.0f, 0.0f);

D3DXVECTOR3						g_vecLightDir(0.35f, 0.65f, -0.65f);	// base light direction
FLOAT							g_fSpecPow = 2.0f;						// specular power component
D3DXMATRIX						g_matObjectWorld;						// object translation matrix
INT								g_nObjSwitch = 0;						// used to change object meshes

// used to handle object and light rotation
FLOAT							g_fObjectRotY = 0.0f;
FLOAT							g_fLightRotY = 0.0f;
FLOAT							g_fObjectRotX = 0.0f;
FLOAT							g_fLightRotX = 0.0f;

INT								g_nWindowWidth = 640;	// current window width
INT								g_nWindowHeight = 480;	// current window height

//--------------------------------------------------------------------------------------
// Rejects any devices that aren't acceptable by returning false
//--------------------------------------------------------------------------------------
bool CALLBACK IsDeviceAcceptable( D3DCAPS9* pCaps, D3DFORMAT AdapterFormat, 
                                  D3DFORMAT BackBufferFormat, bool bWindowed, void* pUserContext )
{
	// check support for pixel and vertex shader versions 2.0
	if (pCaps->PixelShaderVersion < D3DPS_VERSION(2, 0) || pCaps->VertexShaderVersion < D3DVS_VERSION(2, 0))
		return false;

    return true;
}


//--------------------------------------------------------------------------------------
// Before a device is created, modify the device settings as needed
//--------------------------------------------------------------------------------------
bool CALLBACK ModifyDeviceSettings( DXUTDeviceSettings* pDeviceSettings, const D3DCAPS9* pCaps, void* pUserContext )
{
	// if device isn't HAL inform of performance issues
	if (pCaps->DeviceType != D3DDEVTYPE_HAL)
		MessageBox(NULL, L"Full hardware support not avaliable. Performance will be affected.", L"Warning", MB_OK);

    return true;
}


//--------------------------------------------------------------------------------------
// Create any D3DPOOL_MANAGED resources here 
//--------------------------------------------------------------------------------------
HRESULT CALLBACK OnCreateDevice( IDirect3DDevice9* pd3dDevice, const D3DSURFACE_DESC* pBackBufferSurfaceDesc, void* pUserContext )
{

	HRESULT hr;

	// create meshes
	V_RETURN(D3DXCreateTeapot(pd3dDevice, &g_pMeshTeapot, NULL))
	V_RETURN(D3DXCreateSphere(pd3dDevice, 1.0f, 20, 20, &g_pMeshSphere, NULL))
	V_RETURN(D3DXCreateTorus(pd3dDevice, 0.3f, 1.0f, 20, 20, &g_pMeshTorus, NULL))
	V_RETURN(D3DXCreateCylinder(pd3dDevice, 0.0f, 0.75f, 1.5f, 20, 20, &g_pMeshCylinder, NULL))

	// create 1D texture ramps
	V_RETURN(D3DXCreateTextureFromFile(pd3dDevice, L"diffuseRamp.jpg", &g_pTexDiffuse))
	V_RETURN(D3DXCreateTextureFromFile(pd3dDevice, L"specularRamp.jpg", &g_pTexSpecular))
	V_RETURN(D3DXCreateTextureFromFile(pd3dDevice, L"edgeRamp.jpg", &g_pTexEdge))

    return S_OK;
}


//--------------------------------------------------------------------------------------
// Create any D3DPOOL_DEFAULT resources here 
//--------------------------------------------------------------------------------------
HRESULT CALLBACK OnResetDevice( IDirect3DDevice9* pd3dDevice, 
                                const D3DSURFACE_DESC* pBackBufferSurfaceDesc, void* pUserContext )
{
	HRESULT hr;
	D3DXMATRIX matProj, matCamera;

	// calculate and set projection matrix
	D3DXMatrixPerspectiveFovLH(&matProj, D3DX_PI * 0.5f, 4.0f/3.0f, 0.5f, 100.0f);
	pd3dDevice->SetTransform(D3DTS_PROJECTION, &matProj);

	// calculate and set view matrix
	D3DXMatrixLookAtLH(&matCamera,	&g_vecCamPos,
									&g_vecCamLook,
									&g_vecCamUp);
	pd3dDevice->SetTransform(D3DTS_VIEW, &matCamera);

	// create font used for rendering text to the screen
	V_RETURN(D3DXCreateFont(pd3dDevice, 16, 0, FW_BOLD, 0, false, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS,
							DEFAULT_QUALITY, DEFAULT_PITCH | FF_DONTCARE, L"Arial", &g_pFont))

	// create effect
	ID3DXBuffer* pBuffer = NULL;
	if (FAILED(D3DXCreateEffectFromFile(pd3dDevice, L"Effect.fx", 0, 0, D3DXSHADER_DEBUG,
										0, &g_pEffect, &pBuffer)))
	{
		// if creation fails, and buffer contains messages, output debug info
		if (pBuffer)
		{
			OutputDebugString(LPCWSTR(pBuffer->GetBufferPointer()));
			SAFE_RELEASE(pBuffer);
		}

		MessageBox(0, L"D3DXCreateEffectFromFile() - FAILED", L"ERROR", 0);
		return E_FAIL;
	}

	// get handles to matrices
	g_handleMatWVP = g_pEffect->GetParameterByName(0, "g_matWorldViewProjection");
	g_handleMatWIT = g_pEffect->GetParameterByName(0, "g_matWorldInverseTranspose");
	g_handleMatWorld = g_pEffect->GetParameterByName(0, "g_matWorld");

	// get handle to light direction
	g_handleLightDir = g_pEffect->GetParameterByName(0, "g_vecLightDirection");

	// set technique
	V_RETURN(g_pEffect->SetTechnique("ToonTech"))

	// set variables that only need to be set once in the effect's life
	V_RETURN(g_pEffect->SetValue("g_vecMaterialDiffuse", &g_colMatDif, sizeof(D3DXCOLOR)))
	V_RETURN(g_pEffect->SetValue("g_vecMaterialSpecular", &g_colMatSpe, sizeof(D3DXCOLOR)))

	V_RETURN(g_pEffect->SetValue("g_vecCameraPos", &g_vecCamPos, sizeof(D3DXVECTOR3)))
	V_RETURN(g_pEffect->SetFloat("g_fSpecPower", g_fSpecPow))

	V_RETURN(g_pEffect->SetTexture("g_texDiffuse", g_pTexDiffuse))
	V_RETURN(g_pEffect->SetTexture("g_texSpecular", g_pTexSpecular))
	V_RETURN(g_pEffect->SetTexture("g_texEdge", g_pTexEdge))

    return S_OK;
}

//--------------------------------------------------------------------------------------
// Performs all application specific initialization
//--------------------------------------------------------------------------------------
void InitApp()
{
	// calculate object world translation matrix
	D3DXMatrixTranslation(&g_matObjectWorld, 0.0f, 0.0f, 2.5f);
}

//--------------------------------------------------------------------------------------
// Renders all text required by scene
// NB: Must be called between LPDIRECT3DDEVICE9::BeginScene and LPDIRECT3DDEVICE9::EndScene
//--------------------------------------------------------------------------------------

HRESULT RenderText()
{
	HRESULT hr;
	RECT rectPos; // used to position text on screen coordinates
	
	// text rendered to screen
	LPCWSTR textInfo1(L"Press F1/F2 to change object mesh\nLMB controls object rotation\nRMB controls light rotation");

	// define rectangle extremities
	rectPos.top = 10; 
	rectPos.left = 10;
	rectPos.bottom = g_nWindowHeight - 10;

	// draw text
	V_RETURN(g_pFont->DrawText(0, textInfo1, -1, &rectPos, DT_LEFT | DT_BOTTOM | DT_NOCLIP, g_colourFont))

	return S_OK;
}

//--------------------------------------------------------------------------------------
// Handle updates to the scene
//--------------------------------------------------------------------------------------
void CALLBACK OnFrameMove( IDirect3DDevice9* pd3dDevice, double fTime, float fElapsedTime, void* pUserContext )
{
}

//--------------------------------------------------------------------------------------
// Render the scene 
//--------------------------------------------------------------------------------------
void CALLBACK OnFrameRender( IDirect3DDevice9* pd3dDevice, double fTime, float fElapsedTime, void* pUserContext )
{
	HRESULT hr;
	UINT unPasses;

	D3DXMATRIX matRotY, matRotX, matRot;
	D3DXMATRIX matView, matProj, matWorld;
	D3DXMATRIX matWorldViewProj, matWorldInverseTranspose;
	D3DXVECTOR3 vecLight;

    // Clear the render target and the zbuffer 
	V(pd3dDevice->Clear(0, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER, D3DCOLOR_ARGB(0, 45, 50, 170), 1.0f, 0))

	// get matrices
	V(pd3dDevice->GetTransform(D3DTS_VIEW, &matView))
	V(pd3dDevice->GetTransform(D3DTS_PROJECTION, &matProj))
	V(pd3dDevice->GetTransform(D3DTS_WORLD, &matWorld))

	// calculate world matrix for object
	D3DXMatrixRotationY(&matRotY, g_fObjectRotY);
	D3DXMatrixRotationX(&matRotX, g_fObjectRotX);
	D3DXMatrixMultiply(&matRot, &matRotX, &matRotY);
	D3DXMatrixMultiply(&matWorld, &matRot, &g_matObjectWorld);

	// calculate new light direction
	D3DXMatrixRotationY(&matRotY, g_fLightRotY);
	D3DXMatrixRotationX(&matRotX, g_fLightRotX);
	D3DXMatrixMultiply(&matRot, &matRotX, &matRotY);
	D3DXVec3TransformCoord(&vecLight, &g_vecLightDir, &matRot);
	D3DXVec3Normalize(&vecLight, &vecLight);

	// set light direction
	V(g_pEffect->SetValue(g_handleLightDir, &vecLight, sizeof(D3DXVECTOR3)))

	// calculate world-view-projection matrix
	D3DXMatrixMultiply(&matWorldViewProj, &matWorld, &matView);
	D3DXMatrixMultiply(&matWorldViewProj, &matWorldViewProj, &matProj);

	// calculate world-inverse-transpose matrix
	D3DXMatrixInverse(&matWorldInverseTranspose, NULL, &matWorld);
	D3DXMatrixTranspose(&matWorldInverseTranspose, &matWorldInverseTranspose);
	
	// set matrices in effect
	V(g_pEffect->SetMatrix(g_handleMatWorld, &matWorld))
	V(g_pEffect->SetMatrix(g_handleMatWVP, &matWorldViewProj))
	V(g_pEffect->SetMatrix(g_handleMatWIT, &matWorldInverseTranspose))

	// begin drawing
	V(pd3dDevice->BeginScene())

	// stores number of passes required for selected technique
	V(g_pEffect->Begin(&unPasses, 0))

	// iterate through each pass
	for(UINT unPass = 0; unPass < unPasses; ++unPass)
	{
		V(g_pEffect->BeginPass(unPass))
		
		// render mesh
		switch (g_nObjSwitch)
		{
		case 0:
			V(g_pMeshTeapot->DrawSubset(0))
			break;
		case 1:
			V(g_pMeshSphere->DrawSubset(0))
			break;
		case 2:
			V(g_pMeshTorus->DrawSubset(0))
			break;
		case 3:
			V(g_pMeshCylinder->DrawSubset(0))
			break;
		}

		V(g_pEffect->EndPass())
	}

	V(g_pEffect->End())

	V(RenderText())

	// end drawing
	V(pd3dDevice->EndScene())
}


//--------------------------------------------------------------------------------------
// Handle messages to the application 
//--------------------------------------------------------------------------------------
LRESULT CALLBACK MsgProc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam, 
                          bool* pbNoFurtherProcessing, void* pUserContext )
{
	static BOOL	bMoveObject = FALSE;
	static BOOL	bMoveLight = FALSE;
	static INT	nLastXPos = 0;
	static INT	nLastYPos = 0;

	switch(uMsg)
	{
		// store current window width and height
		case WM_SIZE:
			g_nWindowWidth = LOWORD(lParam);
			g_nWindowHeight = HIWORD(lParam);
			break;

		case WM_KEYUP:
		{
			switch(wParam)
			{
			case VK_F1:
				// step through different meshes
				if (++g_nObjSwitch > 3)
					g_nObjSwitch = 0;
				break;
			case VK_F2:
				// step through different meshes
				if (--g_nObjSwitch < 0)
					g_nObjSwitch = 3;
				break;
			}
			break;
		}
		case WM_MOUSEMOVE:
		{
			if (bMoveObject)
			{
				// calculate difference in x position
				INT nCurrXPos = LOWORD(lParam);
				INT nDiff = nCurrXPos - nLastXPos; 

				// increment object's rotation
				g_fObjectRotY -= (FLOAT)nDiff / 100.0f;
				nLastXPos = nCurrXPos;	

				// calculate difference in y position
				INT nCurrYPos = HIWORD(lParam);
				nDiff = nCurrYPos - nLastYPos;

				// increment obect's rotation
				g_fObjectRotX -= (FLOAT)nDiff / 50.0f;
				nLastYPos = nCurrYPos;
			}

			if (bMoveLight)
			{
				// calculate difference in x position
				INT nCurrXPos = LOWORD(lParam);
				INT nDiff = nCurrXPos - nLastXPos; 

				// increment light rotation
				g_fLightRotY -= (FLOAT)nDiff / 100.0f;
				nLastXPos = nCurrXPos;

				// calculate difference in y position
				INT nCurrYPos = HIWORD(lParam);
				nDiff = nCurrYPos - nLastYPos;

				// increment light rotation
				g_fLightRotX -= (FLOAT)nDiff / 50.0f;
				nLastYPos = nCurrYPos;
			}
			break;
		}

		case WM_LBUTTONDOWN:
		{
			bMoveObject = TRUE;
			nLastXPos = LOWORD(lParam);
			nLastYPos = HIWORD(lParam);
			break;
		}

		case WM_LBUTTONUP:
		{
			bMoveObject = FALSE;
			break;
		}

		case WM_RBUTTONDOWN:
		{
			bMoveLight = TRUE;
			nLastXPos = LOWORD(lParam);
			nLastYPos = HIWORD(lParam);
			break;
		}

		case WM_RBUTTONUP:
		{
			bMoveLight = FALSE;
			break;
		}
	}
	return 0;
}


//--------------------------------------------------------------------------------------
// Release resources created in the OnResetDevice callback here 
//--------------------------------------------------------------------------------------
void CALLBACK OnLostDevice( void* pUserContext )
{
	SAFE_RELEASE(g_pFont);
	SAFE_RELEASE(g_pEffect);
}


//--------------------------------------------------------------------------------------
// Release resources created in the OnCreateDevice callback here
//--------------------------------------------------------------------------------------
void CALLBACK OnDestroyDevice( void* pUserContext )
{
	SAFE_RELEASE(g_pMeshTeapot);
	SAFE_RELEASE(g_pMeshSphere);
	SAFE_RELEASE(g_pMeshTorus);
	SAFE_RELEASE(g_pMeshCylinder);

	SAFE_RELEASE(g_pTexDiffuse);
	SAFE_RELEASE(g_pTexSpecular);
	SAFE_RELEASE(g_pTexEdge);
}



//--------------------------------------------------------------------------------------
// Initialize everything and go into a render loop
//--------------------------------------------------------------------------------------
INT WINAPI WinMain( HINSTANCE, HINSTANCE, LPSTR, int )
{
    // Enable run-time memory check for debug builds.
#if defined(DEBUG) | defined(_DEBUG)
    _CrtSetDbgFlag( _CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF );
#endif

    // Set the callback functions
    DXUTSetCallbackDeviceCreated( OnCreateDevice );
    DXUTSetCallbackDeviceReset( OnResetDevice );
    DXUTSetCallbackDeviceLost( OnLostDevice );
    DXUTSetCallbackDeviceDestroyed( OnDestroyDevice );
    DXUTSetCallbackMsgProc( MsgProc );
    DXUTSetCallbackFrameRender( OnFrameRender );
    DXUTSetCallbackFrameMove( OnFrameMove );

    // Initialize DXUT and create the desired Win32 window and Direct3D device for the application
    DXUTInit( true, true, true ); // Parse the command line, handle the default hotkeys, and show msgboxes
    DXUTSetCursorSettings( true, true ); // Show the cursor and clip it when in full screen
    DXUTCreateWindow( L"Toon Shader" );
    DXUTCreateDevice( D3DADAPTER_DEFAULT, true, g_nWindowWidth, g_nWindowHeight, IsDeviceAcceptable, ModifyDeviceSettings );

	InitApp();

    // Start the render loop
    DXUTMainLoop();

    return DXUTGetExitCode();
}