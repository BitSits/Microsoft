//--------------------------------------------------------------------------------------
//    Texture Antialiasing - ITB747
//
//    Author: Michael Samiec - QUT
//    Version: 1.0
//    Date: 14/2/07
//
//    This program demonstrates different antialiasing techniques implemented through shader
//    sampler states. The antialiasing techniques implemented are nearest neighbour, bilinear,
//    trilinear and anisotropic.
//
//    This program is based upon the EmptyProject template provided by Microsoft Corporation
//    through the DirectX Sample Browser. The program is also based upon DXUT (DirectX Utility
//    Toolkit) and the related files can be found in \common.
//
//    Copyright (c) Microsoft Corporation. All rights reserved.
//--------------------------------------------------------------------------------------
#include "dxstdafx.h"

// Added function signatures
HRESULT RenderText();

// Global variables

LPD3DXEFFECT						g_pEffect = NULL;		// effect pointer that encapsulates the shader
LPD3DXFONT							g_pFont = NULL;			// font used for drawing text on screen
LPDIRECT3DVERTEXBUFFER9				g_pVB = NULL;			// vertex buffer used for the square
LPDIRECT3DVERTEXDECLARATION9		g_pVertexDec = NULL;    // vertex decleration of the square
LPDIRECT3DTEXTURE9					g_pTexture = NULL;      // texture used for square

D3DXVECTOR3							g_vecCamPos    (-1.0f, -1.0f, 4.0f);    // camera position
D3DXVECTOR3							g_vecCamLook(0.0f, 0.0f, 5.0f);			// camera look
D3DXVECTOR3							g_vecCamUp    ( 0.0f, 0.0f,-1.0f);		// camera up

D3DCOLOR							g_colourFont = D3DCOLOR_XRGB(0, 0, 0);  // colour used for text rendering

D3DXHANDLE							g_handleTexSwitch = NULL;	// handle to variable used to switch between different texturing techniques
D3DXHANDLE							g_handleMatWVP = NULL;      // handle to worldviewprojection matrix

INT									g_nTexSwitch = 0;           // switch used to switch between textures

INT									g_nWindowWidth = 640;			// current window width
INT									g_nWindowHeight = 480;			// current window height
LPCWSTR								g_strFileName(L"Effect.fx");	// effect file name

// vertex structure
struct Vertex_PosCol
{
    D3DXVECTOR3 pos;
    D3DXVECTOR2 tex;
};

// definition of square vertices
Vertex_PosCol vertSquare[] =
{
    {D3DXVECTOR3(-0.5f, 0.5f, 0.0f), D3DXVECTOR2(0.0f, 0.0f)},
    {D3DXVECTOR3( 0.5f, 0.5f, 0.0f), D3DXVECTOR2(1.0f, 0.0f)},
    {D3DXVECTOR3( 0.5f,-0.5f, 0.0f), D3DXVECTOR2(1.0f, 1.0f)},
    {D3DXVECTOR3(- 0.5f,-0.5f, 0.0f), D3DXVECTOR2(0.0f, 1.0f)}
};

//--------------------------------------------------------------------------------------
// Rejects any devices that aren't acceptable by returning false
//--------------------------------------------------------------------------------------
bool CALLBACK IsDeviceAcceptable( D3DCAPS9* pCaps, D3DFORMAT AdapterFormat,
                                  D3DFORMAT BackBufferFormat, bool bWindowed, void* pUserContext )
{
    // check support for pixel and vertex shader versions 2.0
    if (pCaps->PixelShaderVersion < D3DPS_VERSION(2, 0) || pCaps->VertexShaderVersion < D3DVS_VERSION(2, 0))
        return false;


    static DWORD dwTextureFilterCaps =  D3DPTFILTERCAPS_MINFPOINT |
                                        D3DPTFILTERCAPS_MINFLINEAR |
                                        D3DPTFILTERCAPS_MINFANISOTROPIC |
                                        D3DPTFILTERCAPS_MIPFPOINT |
                                        D3DPTFILTERCAPS_MIPFLINEAR |
                                        D3DPTFILTERCAPS_MAGFPOINT |
                                        D3DPTFILTERCAPS_MAGFLINEAR;// |
                                        //D3DPTFILTERCAPS_MAGFANISOTROPIC ;

    // check support for the each sampler state mode used in the shader
    if ((pCaps->TextureFilterCaps & dwTextureFilterCaps) != dwTextureFilterCaps)
        return false;

    // check max anisotropic avaliable
    if (pCaps->MaxAnisotropy < 4)
        return false;

    return true;
}


//--------------------------------------------------------------------------------------
// Before a device is created, modify the device settings as needed
//--------------------------------------------------------------------------------------
bool CALLBACK ModifyDeviceSettings( DXUTDeviceSettings* pDeviceSettings, const D3DCAPS9* pCaps, void* pUserContext )
{
    // if device isn't HAL inform of performance issues
    if (pCaps->DeviceType != D3DDEVTYPE_HAL)
        MessageBox(NULL, L"Full hardware support not avaliable. Performance will be affected.", L"Warning", MB_OK);

    return true;
}


//--------------------------------------------------------------------------------------
// Create any D3DPOOL_MANAGED resources here
//--------------------------------------------------------------------------------------
HRESULT CALLBACK OnCreateDevice( IDirect3DDevice9* pd3dDevice, const D3DSURFACE_DESC* pBackBufferSurfaceDesc, void* pUserContext )
{
    HRESULT hr;
    // create vertex buffer used to hold triangle vertices
    V_RETURN(pd3dDevice->CreateVertexBuffer(sizeof(vertSquare), D3DUSAGE_WRITEONLY, 0, D3DPOOL_MANAGED, &g_pVB, 0))
    
    // lock memory, copy data in, unlock memory
    void* pMem = NULL;
    V_RETURN(g_pVB->Lock(0, 0, &pMem, 0))
    memcpy(pMem, vertSquare, sizeof(vertSquare));
    V_RETURN(g_pVB->Unlock())

    // define vertex structure
    D3DVERTEXELEMENT9 VertexArray[] =
    {
        {0, 0, D3DDECLTYPE_FLOAT3, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_POSITION, 0},    // position
        {0, 12, D3DDECLTYPE_FLOAT2, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_TEXCOORD, 0},    // colour
        D3DDECL_END()
    };

    V_RETURN(pd3dDevice->CreateVertexDeclaration(VertexArray, &g_pVertexDec))

    // create texture
    V_RETURN(D3DXCreateTextureFromFile(pd3dDevice, L"checkered.bmp", &g_pTexture))

    return S_OK;
}


//--------------------------------------------------------------------------------------
// Create any D3DPOOL_DEFAULT resources here
//--------------------------------------------------------------------------------------
HRESULT CALLBACK OnResetDevice( IDirect3DDevice9* pd3dDevice,
                                const D3DSURFACE_DESC* pBackBufferSurfaceDesc, void* pUserContext )
{
    HRESULT hr;

    // calculate and set projection matrix
    D3DXMATRIX matProj;
    D3DXMatrixPerspectiveFovLH(&matProj, D3DX_PI * 0.45f, 4.0f/3.0f, 0.5f, 1000.0f);
    V_RETURN(pd3dDevice->SetTransform(D3DTS_PROJECTION, &matProj))

    // calculate and set view matrix
    D3DXMATRIX matCamera;
    D3DXMatrixLookAtLH(&matCamera,    &g_vecCamPos,
                                    &g_vecCamLook,
                                    &g_vecCamUp);
    V_RETURN(pd3dDevice->SetTransform(D3DTS_VIEW, &matCamera))

    // calculate and set world matrix
    D3DXMATRIX matTrans;
    D3DXMatrixTranslation(&matTrans, 0.0f, 0.0f, 5.0f);
    V_RETURN(pd3dDevice->SetTransform(D3DTS_WORLD, &matTrans))

    // create effect
    LPD3DXBUFFER pBuffer = NULL;
    if (FAILED(D3DXCreateEffectFromFile(pd3dDevice, g_strFileName, 0, 0, D3DXSHADER_DEBUG,
                                        0, &g_pEffect, &pBuffer)))
    {
        // if creation fails, and debug information has been returned, output debug info
        if (pBuffer)
        {
            OutputDebugStringA((char*)pBuffer->GetBufferPointer());
            SAFE_RELEASE(pBuffer);
        }

        MessageBox(0, L"D3DXCreateEffectFromFile() - FAILED", L"ERROR", 0);
        return E_FAIL;
    }

    // obtain handles to variables within effect
    g_handleMatWVP = g_pEffect->GetParameterByName(0, "g_matWorldViewProjection");
    g_handleTexSwitch = g_pEffect->GetParameterByName(0, "g_nTexSwitch");

    // initialize variable
    V_RETURN(g_pEffect->SetInt(g_handleTexSwitch, g_nTexSwitch))

    // set texture and technique as they remain the same throughout the life of the effect
    V_RETURN(g_pEffect->SetTexture("g_texture", g_pTexture))
    V_RETURN(g_pEffect->SetTechnique("TextureTechnique"))

    // create font used for rendering text
    V_RETURN(D3DXCreateFont(pd3dDevice, 16, 0, FW_BOLD, 0, false, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS,
                            DEFAULT_QUALITY, DEFAULT_PITCH | FF_DONTCARE, L"Arial", &g_pFont))

    return S_OK;
}


//--------------------------------------------------------------------------------------
// Handle updates to the scene
//--------------------------------------------------------------------------------------
void CALLBACK OnFrameMove( IDirect3DDevice9* pd3dDevice, double fTime, float fElapsedTime, void* pUserContext )
{
}

//--------------------------------------------------------------------------------------
// Renders all text required by scene
// NB: Must be called between LPDIRECT3DDEVICE9::BeginScene and LPDIRECT3DDEVICE9::EndScene
//--------------------------------------------------------------------------------------

HRESULT RenderText()
{
    HRESULT hr;
    RECT rectPos; // used to position text on screen coordinates
    
    // text rendered to screen
    LPCWSTR textInfo1 = NULL;
    LPCWSTR textInfo2(L"Press F1 to switch between antialising techniques\nUse mouse wheel to control camera height");
    
    switch (g_nTexSwitch)
    {
    case 0:
        textInfo1 = L"No texture sampling";
        break;
    case 1:
        textInfo1 = L"Nearest neighbout sampling";
        break;
    case 2:
        textInfo1 = L"Bilinear sampling";
        break;
    case 3:
        textInfo1 = L"Trilinear sampling";
        break;
    case 4:
        textInfo1 = L"Anistropic sampling";
        break;
    default:
        textInfo1 = L"This is not an option!";
        break;
    }


    // define rectangle extremities
    rectPos.top = 10;
    rectPos.left = 10;
    rectPos.bottom = g_nWindowHeight - 10;
    rectPos.right = g_nWindowWidth - 10;

    // draw text
    V_RETURN(g_pFont->DrawText(0, textInfo1, -1, &rectPos, DT_RIGHT | DT_BOTTOM | DT_NOCLIP, g_colourFont))
    V_RETURN(g_pFont->DrawText(0, textInfo2, -1, &rectPos, DT_LEFT | DT_BOTTOM | DT_NOCLIP, g_colourFont))

    return S_OK;
}


//--------------------------------------------------------------------------------------
// Render the scene
//--------------------------------------------------------------------------------------
void CALLBACK OnFrameRender( IDirect3DDevice9* pd3dDevice, double fTime, float fElapsedTime, void* pUserContext )
{
    HRESULT hr;

    D3DXMATRIX matView, matProj, matWorld, matFloor, matTrans;
    D3DXMATRIX matWorldViewProj;

    // Clear the render target and the zbuffer
    V(pd3dDevice->Clear(0, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER, D3DCOLOR_ARGB(0, 45, 50, 170), 1.0f, 0))

    // get matrices
    V(pd3dDevice->GetTransform(D3DTS_VIEW, &matView))
    V(pd3dDevice->GetTransform(D3DTS_PROJECTION, &matProj))
    V(pd3dDevice->GetTransform(D3DTS_WORLD, &matWorld))

    // begin drawing
    V(pd3dDevice->BeginScene())

    // tile the floor 25 x 25
    for (int x = 0; x < 25; ++x)
    {
        for (int y = 0; y < 25; ++y)
        {
            D3DXMatrixTranslation(&matTrans, (float)x, (float)y, 0.0f);
            D3DXMatrixMultiply(&matFloor, &matWorld, &matTrans);

            // calculate world-view-projection matrix
            D3DXMatrixMultiply(&matWorldViewProj, &matFloor, &matView);
            D3DXMatrixMultiply(&matWorldViewProj, &matWorldViewProj, &matProj);

            // get handle to worldviewprojection matrix in effect and set matrix
            V(g_pEffect->SetMatrix(g_handleMatWVP, &matWorldViewProj))

            // set up triangle to be rendered
            V(pd3dDevice->SetVertexDeclaration(g_pVertexDec))
            V(pd3dDevice->SetStreamSource(0, g_pVB, 0, sizeof(Vertex_PosCol)))

            UINT unPasses;    // stores number of passes required for selected technique
            V(g_pEffect->Begin(&unPasses, 0))

            // iterate through each pass
            for(UINT unPass = 0; unPass < unPasses; ++unPass)
            {
                V(g_pEffect->BeginPass(unPass))
                
                // render triangle
                V(pd3dDevice->DrawPrimitive(D3DPT_TRIANGLEFAN, 0, 2))

                V(g_pEffect->EndPass())
            }

            V(g_pEffect->End())
        }
    }

    V(RenderText())

    // end drawing
    V(pd3dDevice->EndScene())
}


//--------------------------------------------------------------------------------------
// Handle messages to the application
//--------------------------------------------------------------------------------------
LRESULT CALLBACK MsgProc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam,
                          bool* pbNoFurtherProcessing, void* pUserContext )
{
    switch(uMsg)
    {
        // store current window width and height
        case WM_SIZE:
            g_nWindowWidth = LOWORD(lParam);
            g_nWindowHeight = HIWORD(lParam);
            break;

        case WM_KEYUP:
        {
            switch(wParam)
            {
            // increment through texture sampler states
            case VK_F1:

                if (g_nTexSwitch < 4)
                    g_nTexSwitch++;
                else
                    g_nTexSwitch = 0;

                // set current sampler state
                if (g_pEffect && g_handleTexSwitch)
                    g_pEffect->SetInt(g_handleTexSwitch, g_nTexSwitch);

                break;
            }
            break;

        case WM_MOUSEWHEEL:
        {
            HRESULT hr;

            // get mouse offset
            int nDelta = GET_WHEEL_DELTA_WPARAM(wParam);

            // calculate camera offset
            float fOffset = nDelta * 0.0005f;

            // adjust camera vectors
            g_vecCamPos += g_vecCamUp * fOffset;
            g_vecCamLook += D3DXVECTOR3(0.6f, 0.6f, 0.0f) * fOffset;

            // clamp camera position - these variables obtained through trial and error
            if (g_vecCamPos.z >= 4.75f || g_vecCamLook.x >= 3.0f)
            {
                g_vecCamPos -= g_vecCamUp * fOffset;
                g_vecCamLook -= D3DXVECTOR3(0.6f, 0.6f, 0.0f) * fOffset;
            }

            // calculate and set view matrix
            D3DXMATRIX matCamera;
            D3DXMatrixLookAtLH(&matCamera,  &g_vecCamPos,
                                            &g_vecCamLook,
                                            &g_vecCamUp);
            V_RETURN(DXUTGetD3DDevice()->SetTransform(D3DTS_VIEW, &matCamera))

            break;
        }
        }
    }
    return 0;
}


//--------------------------------------------------------------------------------------
// Release resources created in the OnResetDevice callback here
//--------------------------------------------------------------------------------------
void CALLBACK OnLostDevice( void* pUserContext )
{
    SAFE_RELEASE(g_pFont);
    SAFE_RELEASE(g_pEffect);
}


//--------------------------------------------------------------------------------------
// Release resources created in the OnCreateDevice callback here
//--------------------------------------------------------------------------------------
void CALLBACK OnDestroyDevice( void* pUserContext )
{
    SAFE_RELEASE(g_pTexture);
    SAFE_RELEASE(g_pVertexDec);
    SAFE_RELEASE(g_pVB);
}



//--------------------------------------------------------------------------------------
// Initialize everything and go into a render loop
//--------------------------------------------------------------------------------------
INT WINAPI WinMain( HINSTANCE, HINSTANCE, LPSTR, int )
{
    // Enable run-time memory check for debug builds.
#if defined(DEBUG) | defined(_DEBUG)
    _CrtSetDbgFlag( _CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF );
#endif

    // Set the callback functions
    DXUTSetCallbackDeviceCreated( OnCreateDevice );
    DXUTSetCallbackDeviceReset( OnResetDevice );
    DXUTSetCallbackDeviceLost( OnLostDevice );
    DXUTSetCallbackDeviceDestroyed( OnDestroyDevice );
    DXUTSetCallbackMsgProc( MsgProc );
    DXUTSetCallbackFrameRender( OnFrameRender );
    DXUTSetCallbackFrameMove( OnFrameMove );

    // Initialize DXUT and create the desired Win32 window and Direct3D device for the application
    DXUTInit( true, true, true ); // Parse the command line, handle the default hotkeys, and show msgboxes
    DXUTSetCursorSettings( true, true ); // Show the cursor and clip it when in full screen
    DXUTCreateWindow( L"Texture Antialiasing" );
    DXUTCreateDevice( D3DADAPTER_DEFAULT, true, g_nWindowWidth, g_nWindowHeight, IsDeviceAcceptable, ModifyDeviceSettings );

    DXUTMainLoop();

    return DXUTGetExitCode();
}