//--------------------------------------------------------------------------------------
//	Simple Fog Shader - ITB747
//
//	Author: Michael Samiec - QUT
//	Version: 1.0
//	Date: 14/1/07
//
//	The program demonstrates the use of a fog vertex shader. There are three different fog
//	implementations - linear, exponential and inverse exponential.
//
//	This program is based upon the EmptyProject template provided by Microsoft Corporation 
//	through the DirectX Sample Browser. The program is also based upon DXUT (DirectX Utility
//	Toolkit) and the related files can be found in \common. 
//
//	Copyright (c) Microsoft Corporation. All rights reserved.
//--------------------------------------------------------------------------------------
#include "dxstdafx.h"

// Added function signatures

HRESULT RenderText();
void	InitApp();

// Global variables

LPD3DXEFFECT					g_pEffect = NULL;		// effect pointer that encapsulates the shader
LPD3DXFONT						g_pFont = NULL;			// font used for drawing text on screen

LPD3DXMESH						g_pMeshTeapot = NULL;	// teapot mesh
LPD3DXMESH						g_pMeshPlane = NULL;	// plane mesh
D3DXMATRIX						g_matTeapotWorld;		// teapot world matrix
D3DXMATRIX						g_matPlaneWorld;		// plane world matrix

D3DXVECTOR3						g_vecCamPos	(0.0f, 0.0f, 0.0f);	// camera position
D3DXVECTOR3						g_vecCamLook(0.0f, 0.0f, 1.0f);	// camera look
D3DXVECTOR3						g_vecCamUp	(0.0f, 1.0f, 0.0f);	// camera up

D3DCOLOR						g_colourFont = D3DCOLOR_XRGB(255, 255, 255); // colour used for text rendering

D3DXHANDLE						g_handleMatWVP = NULL;		// handle to worldviewprojection matrix
D3DXHANDLE						g_handleMatWorld = NULL;	// handle to world matrix
D3DXHANDLE						g_handleMatWIT = NULL;		// handle to worldinversetranspose matrix
D3DXHANDLE						g_handlenFogTech = NULL;	// handle to switch to define fog technique

FLOAT							g_fObjectZPos = 2.5f;		// used to change object's depth
FLOAT							g_fObjectXPos = 1.2f;
INT								g_nFogType = 0;				// switch used to change between fog effects

INT								g_nWindowWidth = 640;		// current window width
INT								g_nWindowHeight = 480;		// current window height
LPCWSTR							g_strFileName(L"Effect.fx");// effect file name

//--------------------------------------------------------------------------------------
// Rejects any devices that aren't acceptable by returning false
//--------------------------------------------------------------------------------------
bool CALLBACK IsDeviceAcceptable( D3DCAPS9* pCaps, D3DFORMAT AdapterFormat, 
                                  D3DFORMAT BackBufferFormat, bool bWindowed, void* pUserContext )
{
	// check support for pixel and vertex shader versions 2.0
	if (pCaps->PixelShaderVersion < D3DPS_VERSION(2, 0) || pCaps->VertexShaderVersion < D3DVS_VERSION(2, 0))
		return false;

    return true;
}


//--------------------------------------------------------------------------------------
// Before a device is created, modify the device settings as needed
//--------------------------------------------------------------------------------------
bool CALLBACK ModifyDeviceSettings( DXUTDeviceSettings* pDeviceSettings, const D3DCAPS9* pCaps, void* pUserContext )
{
	// if device isn't HAL inform of performance issues
	if (pCaps->DeviceType != D3DDEVTYPE_HAL)
		MessageBox(NULL, L"Full hardware support not avaliable. Performance will be affected.", L"Warning", MB_OK);

    return true;
}


//--------------------------------------------------------------------------------------
// Create any D3DPOOL_MANAGED resources here 
//--------------------------------------------------------------------------------------
HRESULT CALLBACK OnCreateDevice( IDirect3DDevice9* pd3dDevice, const D3DSURFACE_DESC* pBackBufferSurfaceDesc, void* pUserContext )
{
    return S_OK;
}


//--------------------------------------------------------------------------------------
// Create any D3DPOOL_DEFAULT resources here 
//--------------------------------------------------------------------------------------
HRESULT CALLBACK OnResetDevice( IDirect3DDevice9* pd3dDevice, 
                                const D3DSURFACE_DESC* pBackBufferSurfaceDesc, void* pUserContext )
{
	HRESULT hr;
	D3DXMATRIX matProj, matCamera;

	// create effect
	LPD3DXBUFFER pBuffer = NULL;
	if (FAILED(D3DXCreateEffectFromFile(pd3dDevice, g_strFileName, 0, 0, D3DXSHADER_DEBUG,
										0, &g_pEffect, &pBuffer)))
	{
		// if creation fails, and debug information has been returned, output debug info
		if (pBuffer)
		{
			OutputDebugStringA((char*)pBuffer->GetBufferPointer());
			SAFE_RELEASE(pBuffer);
		}

		MessageBox(0, L"D3DXCreateEffectFromFile() - FAILED", L"ERROR", 0);
		return E_FAIL;
	}

	// obtain handles to variables within effect
	g_handleMatWVP = g_pEffect->GetParameterByName(0, "g_matWorldViewProjection");
	g_handleMatWorld = g_pEffect->GetParameterByName(0, "g_matWorld");
	g_handleMatWIT = g_pEffect->GetParameterByName(0, "g_matWorldInverseTranspose");
	g_handlenFogTech = g_pEffect->GetParameterByName(0, "g_nFogType");

	// set technique as it doesn't change throughout the life of the effect
	V_RETURN(g_pEffect->SetTechnique("FogTech"))
	V_RETURN(g_pEffect->SetValue("g_vecCameraPos", &g_vecCamPos, sizeof(D3DXVECTOR3)))

	// create font used for rendering text
	V_RETURN(D3DXCreateFont(pd3dDevice, 16, 0, FW_BOLD, 0, false, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS,
							DEFAULT_QUALITY, DEFAULT_PITCH | FF_DONTCARE, L"Arial", &g_pFont))

	// create meshes
	V_RETURN(D3DXCreatePolygon(pd3dDevice, 1.0f, 4, &g_pMeshPlane, NULL))
	V_RETURN(D3DXCreateTeapot(pd3dDevice, &g_pMeshTeapot, NULL))

	// calculate and set projection matrix
	D3DXMatrixPerspectiveFovLH(&matProj, D3DX_PI * 0.5f, 4.0f/3.0f, 1.0f, 10000.0f);
	V_RETURN(pd3dDevice->SetTransform(D3DTS_PROJECTION, &matProj))

	// calculate and set view matrix
	D3DXMatrixLookAtLH(&matCamera,	&g_vecCamPos,
									&g_vecCamLook,
									&g_vecCamUp);
	V_RETURN(pd3dDevice->SetTransform(D3DTS_VIEW, &matCamera))

    return S_OK;
}


//--------------------------------------------------------------------------------------
// Handle updates to the scene
//--------------------------------------------------------------------------------------
void CALLBACK OnFrameMove( IDirect3DDevice9* pd3dDevice, double fTime, float fElapsedTime, void* pUserContext )
{
}

//--------------------------------------------------------------------------------------
// Performs all application specific initialization
//--------------------------------------------------------------------------------------
void InitApp()
{
	// calculate teapot world matrix
	D3DXMatrixTranslation(&g_matTeapotWorld, g_fObjectXPos, 0.0f, g_fObjectZPos);

	// calculate plane default matrix
	D3DXMATRIX matTrans, matScale, matRotY, matRotZ;
	
	D3DXMatrixRotationY(&matRotY, D3DX_PI/2.0f);
	D3DXMatrixRotationZ(&matRotZ, D3DX_PI/4.0f);
	D3DXMatrixTranslation(&matTrans, -1.5f, 0.0f, 1.0f);
	D3DXMatrixScaling(&matScale, 2.0f, 2.0f, 1.0f);

	D3DXMatrixMultiply(&g_matPlaneWorld, &matScale, &matRotZ);
	D3DXMatrixMultiply(&g_matPlaneWorld, &g_matPlaneWorld, &matRotY);
	D3DXMatrixMultiply(&g_matPlaneWorld, &g_matPlaneWorld, &matTrans);
}

//--------------------------------------------------------------------------------------
// Renders all text required by scene
// NB: Must be called between LPDIRECT3DDEVICE9::BeginScene and LPDIRECT3DDEVICE9::EndScene
//--------------------------------------------------------------------------------------

HRESULT RenderText()
{
	HRESULT hr;
	RECT rectPos; // used to position text on screen coordinates
	
	// text rendered to screen
	LPCWSTR textInfo1(L"Press F1 to increment through fog effects");
	LPCWSTR textInfo2(L"Mouse Wheel - Controls teapot's depth");
	LPCWSTR textInfo3 = L"";

	if (g_nFogType == 0)
		textInfo3 = L"Linear";
	else if (g_nFogType == 1)
		textInfo3 = L"Exponential";
	else if (g_nFogType == 2)
		textInfo3 = L"Inverse-Exponential";

	// define rectangle extremities
	rectPos.top = 10; 
	rectPos.left = 10;
	rectPos.bottom = g_nWindowHeight - 10;
	rectPos.right = g_nWindowWidth - 10;

	// draw text
	V_RETURN(g_pFont->DrawText(0, textInfo1, -1, &rectPos, DT_LEFT | DT_TOP | DT_NOCLIP, g_colourFont))
	V_RETURN(g_pFont->DrawText(0, textInfo2, -1, &rectPos, DT_LEFT | DT_BOTTOM | DT_NOCLIP, g_colourFont))
	V_RETURN(g_pFont->DrawText(0, textInfo3, -1, &rectPos, DT_RIGHT | DT_TOP, g_colourFont))

	return S_OK;
}


//--------------------------------------------------------------------------------------
// Render the scene 
//--------------------------------------------------------------------------------------
void CALLBACK OnFrameRender( IDirect3DDevice9* pd3dDevice, double fTime, float fElapsedTime, void* pUserContext )
{
	HRESULT hr;
	UINT unPasses;

	D3DXMATRIX matTrans;
	D3DXMATRIX matView, matProj;
	D3DXMATRIX matWorldViewProj, matWorldIT;
	D3DXMATRIX matBoxWorldTemp = g_matPlaneWorld;

	// world offset for each plane
	D3DXMatrixTranslation(&matTrans, 0.0f, 0.0f, 2.0f);

    // Clear the render target and the zbuffer 
	V(pd3dDevice->Clear(0, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER, D3DCOLOR_ARGB(0, 0, 0, 0), 1.0f, 0))

	// get view and projection matrices
	V(pd3dDevice->GetTransform(D3DTS_VIEW, &matView))
	V(pd3dDevice->GetTransform(D3DTS_PROJECTION, &matProj))

	// set specific fog effect
	V(g_pEffect->SetInt(g_handlenFogTech, g_nFogType))

	// begin drawing
	V(pd3dDevice->BeginScene())

	V(RenderText())

	// stores number of passes required for selected technique
	V(g_pEffect->Begin(&unPasses, 0))

	// iterate through each pass
	for(UINT unPass = 0; unPass < unPasses; ++unPass)
	{
		V(g_pEffect->BeginPass(unPass))

		// calculate world-view-projection matrix
		D3DXMatrixMultiply(&matWorldViewProj, &g_matTeapotWorld, &matView);
		D3DXMatrixMultiply(&matWorldViewProj, &matWorldViewProj, &matProj);

		// calculate world-inverse-transpose matrix
		D3DXMatrixInverse(&matWorldIT, NULL, &g_matTeapotWorld);
		D3DXMatrixTranspose(&matWorldIT, &matWorldIT);

		// set matrices for rendering teapot
		V(g_pEffect->SetMatrix(g_handleMatWVP, &matWorldViewProj))
		V(g_pEffect->SetMatrix(g_handleMatWorld, &g_matTeapotWorld))
		V(g_pEffect->SetMatrix(g_handleMatWIT, &matWorldIT))
		V(g_pEffect->CommitChanges())
		
		// render teapot
		V(g_pMeshTeapot->DrawSubset(0))

		// render plane
		for (int i = 0; i < 30; ++i)
		{
			// calculate world-view-projection matrix
			D3DXMatrixMultiply(&matWorldViewProj, &matBoxWorldTemp, &matView);
			D3DXMatrixMultiply(&matWorldViewProj, &matWorldViewProj, &matProj);

			// calculate world-inverse-transpose matrix
			D3DXMatrixInverse(&matWorldIT, NULL, &matBoxWorldTemp);
			D3DXMatrixTranspose(&matWorldIT, &matWorldIT);

			// set matrices for plane
			V(g_pEffect->SetMatrix(g_handleMatWVP, &matWorldViewProj))
			V(g_pEffect->SetMatrix(g_handleMatWorld, &matBoxWorldTemp))
			V(g_pEffect->SetMatrix(g_handleMatWIT, &matWorldIT))
			V(g_pEffect->CommitChanges())
			V(g_pMeshPlane->DrawSubset(0))

			// increment plane position
			D3DXMatrixMultiply(&matBoxWorldTemp, &matBoxWorldTemp, &matTrans);	
		}


		V(g_pEffect->EndPass())
	}

	V(g_pEffect->End())

	// end drawing
	V(pd3dDevice->EndScene())
}


//--------------------------------------------------------------------------------------
// Handle messages to the application 
//--------------------------------------------------------------------------------------
LRESULT CALLBACK MsgProc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam, 
                          bool* pbNoFurtherProcessing, void* pUserContext )
{
	switch(uMsg)
	{
		// store current window width and height
		case WM_SIZE:
			g_nWindowWidth = LOWORD(lParam);
			g_nWindowHeight = HIWORD(lParam);
			break;

		case WM_KEYUP:
		{
			// increment through fog effects
			switch(wParam)
			{
			case VK_F1:
				if (g_nFogType < 2)
					g_nFogType++;
				else 
					g_nFogType = 0;
				break;
			}
			break;
		}

		case WM_MOUSEWHEEL:
		{
			// get mouse offset
			int nDelta = GET_WHEEL_DELTA_WPARAM(wParam);
			g_fObjectZPos += nDelta / 300.0f;

			// clamp object position
			if (g_fObjectZPos < 2.5f)
				g_fObjectZPos = 2.5f;
			else if (g_fObjectZPos > 30.0f)
				g_fObjectZPos = 30.0f;

			// set new teapot matrix
			D3DXMatrixTranslation(&g_matTeapotWorld, g_fObjectXPos, 0.0f, g_fObjectZPos);

			break;
		}
	}
	return 0;
}


//--------------------------------------------------------------------------------------
// Release resources created in the OnResetDevice callback here 
//--------------------------------------------------------------------------------------
void CALLBACK OnLostDevice( void* pUserContext )
{
	SAFE_RELEASE(g_pMeshTeapot);
	SAFE_RELEASE(g_pMeshPlane);
	SAFE_RELEASE(g_pFont);
	SAFE_RELEASE(g_pEffect);
}


//--------------------------------------------------------------------------------------
// Release resources created in the OnCreateDevice callback here
//--------------------------------------------------------------------------------------
void CALLBACK OnDestroyDevice( void* pUserContext )
{
}



//--------------------------------------------------------------------------------------
// Initialize everything and go into a render loop
//--------------------------------------------------------------------------------------
INT WINAPI WinMain( HINSTANCE, HINSTANCE, LPSTR, int )
{
    // Enable run-time memory check for debug builds.
#if defined(DEBUG) | defined(_DEBUG)
    _CrtSetDbgFlag( _CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF );
#endif

    // Set the callback functions
    DXUTSetCallbackDeviceCreated( OnCreateDevice );
    DXUTSetCallbackDeviceReset( OnResetDevice );
    DXUTSetCallbackDeviceLost( OnLostDevice );
    DXUTSetCallbackDeviceDestroyed( OnDestroyDevice );
    DXUTSetCallbackMsgProc( MsgProc );
    DXUTSetCallbackFrameRender( OnFrameRender );
    DXUTSetCallbackFrameMove( OnFrameMove );
   
    // Initialize DXUT and create the desired Win32 window and Direct3D device for the application
    DXUTInit( true, true, true ); // Parse the command line, handle the default hotkeys, and show msgboxes
    DXUTSetCursorSettings( true, true ); // Show the cursor and clip it when in full screen
    DXUTCreateWindow( L"Simple Fog Shader" );
    DXUTCreateDevice( D3DADAPTER_DEFAULT, true, g_nWindowWidth, g_nWindowHeight, IsDeviceAcceptable, ModifyDeviceSettings );

	InitApp();

	DXUTMainLoop();

    return DXUTGetExitCode();
}


