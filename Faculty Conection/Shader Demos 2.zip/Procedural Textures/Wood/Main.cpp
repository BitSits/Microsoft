//--------------------------------------------------------------------------------------
//	Procedural Texture: Wood - ITB747
//
//	Author: Michael Samiec - QUT
//	Version: 1.0
//	Date: 21/3/07
//
//	This program encapsulates the wood.fx effect provided by nVidia in their
//	SDK 9.5 set.
//
//	The program demonstrates a simple position and colour shader pass through using
//	HLSL and DirectX 9.0c. This program is based upon the EmptyProject template provided 
//	by Microsoft through the DirectX Sample Browser.
//
//	Copyright (c) Microsoft Corporation. All rights reserved.
//--------------------------------------------------------------------------------------
#include "dxstdafx.h"

// function signatures
HRESULT	RenderText();

// Global variables

LPD3DXEFFECT					g_pEffect = NULL;		// effect pointer that encapsulates the shader
LPD3DXFONT						g_pFont = NULL;			// font used for drawing text on screen

// meshes used to display technique
LPD3DXMESH						g_pMeshTeapot = NULL;
LPD3DXMESH						g_pMeshSphere = NULL;
LPD3DXMESH						g_pMeshCone = NULL;
LPD3DXMESH						g_pMeshTorus = NULL;

// noise texture used in effect
LPDIRECT3DTEXTURE9				g_pTextureNoise = NULL;

// effect handles
D3DXHANDLE						g_handleMatWVP = NULL;
D3DXHANDLE						g_handleMatWIT = NULL;
D3DXHANDLE						g_handleMatWorld = NULL;
D3DXHANDLE						g_handleMatVI = NULL;

// camera variables
D3DXVECTOR3						g_vecCamPos	(0.0f, 0.0f, 0.0f);
D3DXVECTOR3						g_vecCamLook(0.0f, 0.0f, 0.0f);
D3DXVECTOR3						g_vecCamUp	(0.0f, 1.0f, 0.0f);

// colour used for text rendering
D3DCOLOR						g_colourFont = D3DCOLOR_XRGB(255, 255, 255);

// used to rotate object and camera
FLOAT							g_fCameraOffset = 0.0f;
FLOAT							g_fObjectRotY = 0.0f;
FLOAT							g_fObjectRotX = 0.0f;

// switch used for object selection
INT								g_nObjectSelect = 0;

// controls camera's orbit distance
FLOAT							g_fCameraOrbit = 2.5f;

INT								g_nWindowWidth = 640;					// current window width
INT								g_nWindowHeight = 480;					// current window height
LPCWSTR							g_strFileName(L"wood.fx");				// effect file name
LPCWSTR							g_strTexture(L"noiseL8_32x32x32.dds");	// noise texture file name

//--------------------------------------------------------------------------------------
// Rejects any devices that aren't acceptable by returning false
//--------------------------------------------------------------------------------------
bool CALLBACK IsDeviceAcceptable( D3DCAPS9* pCaps, D3DFORMAT AdapterFormat, 
                                  D3DFORMAT BackBufferFormat, bool bWindowed, void* pUserContext )
{
	// check support for pixel and vertex shader versions 2.0
	if (pCaps->PixelShaderVersion < D3DPS_VERSION(2, 0) || pCaps->VertexShaderVersion < D3DVS_VERSION(2, 0))
		return false;

    return true;
}


//--------------------------------------------------------------------------------------
// Before a device is created, modify the device settings as needed
//--------------------------------------------------------------------------------------
bool CALLBACK ModifyDeviceSettings( DXUTDeviceSettings* pDeviceSettings, const D3DCAPS9* pCaps, void* pUserContext )
{
	// if device isn't HAL inform of performance issues
	if (pCaps->DeviceType != D3DDEVTYPE_HAL)
		MessageBox(NULL, L"Full hardware support not avaliable. Performance will be affected.", L"Warning", MB_OK);

    return true;
}


//--------------------------------------------------------------------------------------
// Create any D3DPOOL_MANAGED resources here 
//--------------------------------------------------------------------------------------
HRESULT CALLBACK OnCreateDevice( IDirect3DDevice9* pd3dDevice, const D3DSURFACE_DESC* pBackBufferSurfaceDesc, void* pUserContext )
{
    return S_OK;
}

//--------------------------------------------------------------------------------------
// Updates and sets view matrix
//--------------------------------------------------------------------------------------

void SetCamera()
{
	HRESULT hr;
	D3DXMATRIX matCamera;
	LPDIRECT3DDEVICE9 pd3dDevice = DXUTGetD3DDevice();

	// orbits camera around centrepoint
	g_vecCamPos = D3DXVECTOR3(g_fCameraOrbit * sin(g_fCameraOffset), 0.0f, g_fCameraOrbit * cos(g_fCameraOffset));

	// calculate and set view matrix
	D3DXMatrixLookAtLH(&matCamera,	&g_vecCamPos,
									&g_vecCamLook,
									&g_vecCamUp);
	V(pd3dDevice->SetTransform(D3DTS_VIEW, &matCamera))
}

//--------------------------------------------------------------------------------------
// Create any D3DPOOL_DEFAULT resources here 
//--------------------------------------------------------------------------------------
HRESULT CALLBACK OnResetDevice( IDirect3DDevice9* pd3dDevice, 
                                const D3DSURFACE_DESC* pBackBufferSurfaceDesc, void* pUserContext )
{
	HRESULT hr;
	D3DXMATRIX matProj, matCamera;

	// create effect
	ID3DXBuffer* pBuffer = NULL;
	if (FAILED(D3DXCreateEffectFromFile(pd3dDevice, g_strFileName, 0, 0, D3DXSHADER_DEBUG,
										0, &g_pEffect, &pBuffer)))
	{
		// if creation fails, and debug information has been returned, output debug info
		if (pBuffer)
		{
			OutputDebugStringA((char*)pBuffer->GetBufferPointer());
			SAFE_RELEASE(pBuffer);
		}

		MessageBox(0, L"D3DXCreateEffectFromFile() - FAILED", L"ERROR", 0);
		return E_FAIL;
	}

	// get handles to variables that change often in effect
	g_handleMatWVP = g_pEffect->GetParameterByName(0, "WorldViewProj");
	g_handleMatWIT = g_pEffect->GetParameterByName(0, "WorldIT");
	g_handleMatWorld = g_pEffect->GetParameterByName(0, "World");
	g_handleMatVI = g_pEffect->GetParameterByName(0, "ViewI");

	// set technique
	V(g_pEffect->SetTechnique("wood"))

	// create meshes
	V_RETURN(D3DXCreateTeapot(pd3dDevice, &g_pMeshTeapot, NULL))
	V_RETURN(D3DXCreateSphere(pd3dDevice, 1.0f, 15, 15, &g_pMeshSphere, NULL))
	V_RETURN(D3DXCreateCylinder(pd3dDevice, 0.8f, 0.0f, 1.5f, 15, 15, &g_pMeshCone, NULL))
	V_RETURN(D3DXCreateTorus(pd3dDevice, 0.2f, 1.0f, 15, 15, &g_pMeshTorus, NULL))

	V_RETURN(D3DXCreateTextureFromFile(pd3dDevice, g_strTexture, &g_pTextureNoise))
	V_RETURN(g_pEffect->SetTexture("NoiseTex", g_pTextureNoise))

	// calculate and set projection matrix
	D3DXMatrixPerspectiveFovLH(&matProj, D3DX_PI * 0.5f, 4.0f/3.0f, 0.5f, 100.0f);
	V_RETURN(pd3dDevice->SetTransform(D3DTS_PROJECTION, &matProj))

	// update view matrix
	SetCamera();

	// create font used for rendering text
	V_RETURN(D3DXCreateFont(pd3dDevice, 16, 0, FW_BOLD, 0, false, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS,
							DEFAULT_QUALITY, DEFAULT_PITCH | FF_DONTCARE, L"Arial", &g_pFont))

    return S_OK;
}

//--------------------------------------------------------------------------------------
// Renders all text required by scene
// NB: Must be called between LPDIRECT3DDEVICE9::BeginScene and LPDIRECT3DDEVICE9::EndScene
//--------------------------------------------------------------------------------------

HRESULT RenderText()
{
	HRESULT hr;
	RECT rectPos; // used to position text on screen coordinates
	
	// text rendered to screen
	LPCWSTR textInfo1(L"RMB controls camera rotation\nLMB controls object rotation\nF1 cycles through objects");

	// define rectangle extremities
	rectPos.top = 10; 
	rectPos.left = 10;
	rectPos.bottom = g_nWindowHeight - 10;
	rectPos.right = g_nWindowWidth - 10;

	// draw text
	V_RETURN(g_pFont->DrawText(0, textInfo1, -1, &rectPos, DT_LEFT | DT_BOTTOM | DT_NOCLIP, g_colourFont))

	return S_OK;
}

//--------------------------------------------------------------------------------------
// Handle updates to the scene
//--------------------------------------------------------------------------------------
void CALLBACK OnFrameMove( IDirect3DDevice9* pd3dDevice, double fTime, float fElapsedTime, void* pUserContext )
{
}

//--------------------------------------------------------------------------------------
// Render the scene 
//--------------------------------------------------------------------------------------
void CALLBACK OnFrameRender( IDirect3DDevice9* pd3dDevice, double fTime, float fElapsedTime, void* pUserContext )
{
	HRESULT hr;
	UINT unPasses;

	D3DXMATRIX matRotY, matRotX;
	D3DXMATRIX matView, matProj, matWorld;
	D3DXMATRIX matWorldViewProj, matWorldInverseTranspose;
	D3DXMATRIX matViewInverse;

    // clear the render target and the zbuffer
	V(pd3dDevice->Clear(0, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER, D3DCOLOR_ARGB(0, 20, 20, 20), 1.0f, 0))

	// get matrices
	V(pd3dDevice->GetTransform(D3DTS_VIEW, &matView))
	V(pd3dDevice->GetTransform(D3DTS_PROJECTION, &matProj))

	// calculate world matrix for object
	D3DXMatrixRotationY(&matRotY, g_fObjectRotY);
	D3DXMatrixRotationX(&matRotX, g_fObjectRotX);
	D3DXMatrixMultiply(&matWorld, &matRotX, &matRotY);

	// calculate world-view-projection matrix
	D3DXMatrixMultiply(&matWorldViewProj, &matWorld, &matView);
	D3DXMatrixMultiply(&matWorldViewProj, &matWorldViewProj, &matProj);

	// calculate world-inverse-transpose matrix
	D3DXMatrixInverse(&matWorldInverseTranspose, NULL, &matWorld);
	D3DXMatrixTranspose(&matWorldInverseTranspose, &matWorldInverseTranspose);

	D3DXMatrixInverse(&matViewInverse, NULL, &matView);
	
	// set effect variables
	V(g_pEffect->SetMatrix(g_handleMatWIT, &matWorldInverseTranspose))
	V(g_pEffect->SetMatrix(g_handleMatWVP, &matWorldViewProj))
	V(g_pEffect->SetMatrix(g_handleMatWorld, &matWorld))
	V(g_pEffect->SetMatrix(g_handleMatVI, &matViewInverse))

	// begin drawing
	V(pd3dDevice->BeginScene())

	// stores number of passes required for selected technique
	V(g_pEffect->Begin(&unPasses, 0))

	// iterate through each pass
	for(UINT unPass = 0; unPass < unPasses; ++unPass)
	{
		V(g_pEffect->BeginPass(unPass))

		// draw selected object
		switch (g_nObjectSelect)
		{
		case 0:
			V(g_pMeshTeapot->DrawSubset(0))
			break;
		case 1:
			V(g_pMeshSphere->DrawSubset(0))
			break;
		case 2:
			V(g_pMeshCone->DrawSubset(0))
			break;
		case 3:
		default:
			V(g_pMeshTorus->DrawSubset(0))
			break;
		}

		V(g_pEffect->EndPass())
	}

	V(g_pEffect->End())

	V(RenderText())

	// end drawing
	V(pd3dDevice->EndScene())
}


//--------------------------------------------------------------------------------------
// Handle messages to the application 
//--------------------------------------------------------------------------------------
LRESULT CALLBACK MsgProc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam, 
                          bool* pbNoFurtherProcessing, void* pUserContext )
{
	// used to control object and camera rotation
	static BOOL	bMoveObject = false;
	static BOOL	bMoveCamera = false;
	static INT	nLastXPos = 0;
	static INT	nLastYPos = 0;

	switch(uMsg)
	{
		case WM_KEYUP:
			switch(wParam)
			{
			case VK_F1:
				// cycle through objects
				if (g_nObjectSelect < 3)
					g_nObjectSelect++;
				else
					g_nObjectSelect = 0;
				break;
			}
			break;

		case WM_SIZE:
			// store current window width and height
			g_nWindowWidth = LOWORD(lParam);
			g_nWindowHeight = HIWORD(lParam);
			break;

		case WM_MOUSEMOVE:
		{
			if (bMoveObject)
			{
				// calculate difference in x position
				INT nCurrXPos = LOWORD(lParam);
				INT nDiff = nCurrXPos - nLastXPos; 

				// increment object's rotation
				g_fObjectRotY -= (FLOAT)nDiff / 100.0f;
				nLastXPos = nCurrXPos;	

				// calculate difference in y position
				INT nCurrYPos = HIWORD(lParam);
				nDiff = nCurrYPos - nLastYPos;

				// increment object's rotation
				g_fObjectRotX += (FLOAT)nDiff / 50.0f;
				nLastYPos = nCurrYPos;
			}

			// rotate camera around object
			if (bMoveCamera)
			{
				// calculate difference in x position
				INT nCurrXPos = LOWORD(lParam);
				INT nDiff = nCurrXPos - nLastXPos;

				// adjust camera offset
				g_fCameraOffset += (FLOAT)nDiff / 50.0f;

				// update view matrix
				SetCamera();

				nLastXPos = nCurrXPos;
			}
			break;
		}

		case WM_LBUTTONDOWN:
		{
			bMoveObject = true;
			nLastXPos = LOWORD(lParam);
			nLastYPos = HIWORD(lParam);
			break;
		}

		case WM_LBUTTONUP:
		{
			bMoveObject = false;
			break;
		}

		case WM_RBUTTONDOWN:
		{
			bMoveCamera = true;
			nLastXPos = LOWORD(lParam);
			nLastYPos = HIWORD(lParam);			
			break;
		}

		case WM_RBUTTONUP:
		{
			bMoveCamera = false;
			break;
		}
	}
	return 0;
}


//--------------------------------------------------------------------------------------
// Release resources created in the OnResetDevice callback here 
//--------------------------------------------------------------------------------------
void CALLBACK OnLostDevice( void* pUserContext )
{
	SAFE_RELEASE(g_pFont);
	SAFE_RELEASE(g_pEffect);
	SAFE_RELEASE(g_pMeshTeapot);
	SAFE_RELEASE(g_pMeshSphere);
	SAFE_RELEASE(g_pMeshCone);
	SAFE_RELEASE(g_pMeshTorus);
	SAFE_RELEASE(g_pTextureNoise);
}


//--------------------------------------------------------------------------------------
// Release resources created in the OnCreateDevice callback here
//--------------------------------------------------------------------------------------
void CALLBACK OnDestroyDevice( void* pUserContext )
{
}



//--------------------------------------------------------------------------------------
// Initialize everything and go into a render loop
//--------------------------------------------------------------------------------------
INT WINAPI WinMain( HINSTANCE, HINSTANCE, LPSTR, int )
{
    // Enable run-time memory check for debug builds.
#if defined(DEBUG) | defined(_DEBUG)
    _CrtSetDbgFlag( _CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF );
#endif

    // Set the callback functions
    DXUTSetCallbackDeviceCreated( OnCreateDevice );
    DXUTSetCallbackDeviceReset( OnResetDevice );
    DXUTSetCallbackDeviceLost( OnLostDevice );
    DXUTSetCallbackDeviceDestroyed( OnDestroyDevice );
    DXUTSetCallbackMsgProc( MsgProc );
    DXUTSetCallbackFrameRender( OnFrameRender );
    DXUTSetCallbackFrameMove( OnFrameMove );

    // Initialize DXUT and create the desired Win32 window and Direct3D device for the application
    DXUTInit( true, true, true ); // Parse the command line, handle the default hotkeys, and show msgboxes
    DXUTSetCursorSettings( true, true ); // Show the cursor and clip it when in full screen
    DXUTCreateWindow( L"Procedural Texture - Wood" );
    DXUTCreateDevice( D3DADAPTER_DEFAULT, true, g_nWindowWidth, g_nWindowHeight, IsDeviceAcceptable, ModifyDeviceSettings );

    // Start the render loop
    DXUTMainLoop();

    return DXUTGetExitCode();
}


