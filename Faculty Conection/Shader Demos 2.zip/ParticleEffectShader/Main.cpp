//--------------------------------------------------------------------------------------
//	Particle Effect Shader - ITB747
//	
//	Author: Michael Samiec - QUT
//	Version: 1.0
//	Date: 12/5/07
//	
//	This effect demonstrates two particle effects. The particle system used is based upon the
//	particle class provided in "Introduction to 3D Game Programming With DirectX 9.0c" by Frank
//	D. Luna. The two textures used in this demo are also sourced from the book and its examples.
//	
//	This program is based upon the EmptyProject template provided by Microsoft Corporation
//	through the DirectX Sample Browser. The program is also based upon DXUT (DirectX Utility
//	Toolkit) and the related files can be found in \common.
//	
//	Copyright (c) Microsoft Corporation. All rights reserved.
//--------------------------------------------------------------------------------------
#include "dxstdafx.h"
#include <time.h>
#include <vector>

// Added function signatures
HRESULT RenderText();

// Global variables

LPD3DXEFFECT						g_pEffect = NULL;		// effect pointer that encapsulates the shader
LPD3DXFONT							g_pFont = NULL;			// font used for drawing text on screen
LPDIRECT3DVERTEXBUFFER9				g_pVB = NULL;			// particle buffer used to hold the particles to be rendered to the scene
LPDIRECT3DVERTEXDECLARATION9		g_pParticleDecl = NULL;	// particle vertex decleration
LPDIRECT3DTEXTURE9					g_pTextureBolt = NULL;  // texture used for first effect
LPDIRECT3DTEXTURE9					g_pTextureFire = NULL;	// texture used for second effect

D3DXVECTOR3							g_vecCamPos		( 0.0f, 0.1f,-4.0f);	// camera position
D3DXVECTOR3							g_vecCamLook	( 0.0f, 0.0f, 0.0f);	// camera look
D3DXVECTOR3							g_vecCamUp		( 0.0f, 0.0f, 1.0f);	// camera up

// colour used for text rendering
D3DCOLOR							g_colourFont = D3DCOLOR_XRGB(255, 255, 255);

D3DXHANDLE							g_handleMatWVP = NULL;      // handle to worldviewprojection matrix
D3DXHANDLE							g_handleFTime = NULL;		// handle to time
D3DXHANDLE							g_handleVecAccel = NULL;	// handle to acceleration vector
D3DXHANDLE							g_handleTexture = NULL;		// handle to texture

// switch used to switch between particle effects
BOOL								g_bParticleSwitch = TRUE;

INT									g_nWindowWidth = 640;			// current window width
INT									g_nWindowHeight = 480;			// current window height
LPCWSTR								g_strFileName(L"Effect.fx");	// effect file name

static const int			PARTICLE_NUM = 500;						// max number of particles
static const float			PARTICLE_SIZE = 20.0f;					// max size (in pixels) of particles
static const float			PARTICLE_LIFETIME = 10.0f;				// max life time of particles
static const D3DXVECTOR3	PARTICLE_STARTPOS(0.0f, 0.0f, 0.0f);	// starting position for particles
static const D3DXVECTOR3	ACCEL_ONE(0.0f, -2.5f, 0.0f);			// acceleration used in first effect
static const D3DXVECTOR3	ACCEL_TWO(0.0f, 0.0f, 0.0f);			// acceleration used in second effect

struct Particle
{
	D3DXVECTOR3 m_vecInitPos;
	D3DXVECTOR3	m_vecInitVel;
	float		m_fInitialTime;
	float		m_fLifeTime;
	float		m_fSize;

	Particle() :	m_vecInitPos(PARTICLE_STARTPOS), 
					m_vecInitVel(0.0f, 0.0f, 0.0f), 
					m_fInitialTime(-1.0f),
					m_fLifeTime(0.0f),
					m_fSize(0.0f)

	{
	}
};

std::vector<Particle>	m_vecParticles;			// stores all particles
std::vector<Particle*>	m_vecAliveParticles;	// references to m_vecParticles - stores particles currently active
std::vector<Particle*>	m_vecDeadParticles;		// references to m_vecParticles - stores particles currently inactive

//--------------------------------------------------------------------------------------
//	Generates a random float in the range of nRange. If bBothSides is specified, the range
//	is spread across both the positive and negative spectrum.
//--------------------------------------------------------------------------------------
float GenRan(unsigned int nRange, bool bBothSides = false)
{
	// generate a random float in the range
	float fRandom = (float)(rand()%(nRange*1000)) / 1000;

	if (bBothSides)
		return fRandom - (float)nRange/2;
	else
		return fRandom;
}

//--------------------------------------------------------------------------------------
//	Creates the particles
//--------------------------------------------------------------------------------------
void SetupParticles()
{
	m_vecParticles.clear();

	m_vecParticles.resize(PARTICLE_NUM);
	m_vecDeadParticles.reserve(PARTICLE_NUM);
	m_vecAliveParticles.reserve(PARTICLE_NUM);
}

//--------------------------------------------------------------------------------------
//	Updates the particles
//--------------------------------------------------------------------------------------
void UpdateParticles(float fTime)
{
	std::vector<Particle>::iterator iter;

	// clear each vector
	m_vecDeadParticles.resize(0);
	m_vecAliveParticles.resize(0);

	// for all particles
	for (iter = m_vecParticles.begin(); iter != m_vecParticles.end(); ++iter)
	{
		// if currently active
		if ((*iter).m_fInitialTime > 0)
		{
			// if life has expired
			if ((*iter).m_fInitialTime + (*iter).m_fLifeTime < fTime)
			{
				// push to dead vector
				(*iter).m_fInitialTime = -1;
				m_vecDeadParticles.push_back(&(*iter));
			}
			else
			{
				// push to alive vector
				m_vecAliveParticles.push_back(&(*iter));
			}
		}
		else
			m_vecDeadParticles.push_back(&(*iter));
	}

	// if there is a dead particles
	if (!m_vecDeadParticles.empty())
	{
		// get particle
		Particle* pParticle = m_vecDeadParticles.back();

		// depending on technique, initalize particle
		if (g_bParticleSwitch)
		{
			pParticle->m_fInitialTime = fTime;
			pParticle->m_fLifeTime = GenRan(PARTICLE_LIFETIME);
			pParticle->m_fSize = GenRan(PARTICLE_SIZE-2) + 2.0f;
			pParticle->m_vecInitPos = PARTICLE_STARTPOS + D3DXVECTOR3(0.0f, -2.5f, 0.0f);
			pParticle->m_vecInitVel = D3DXVECTOR3(GenRan(2, true), GenRan(5)+2.0f, 0.0f);
		}
		else
		{
			pParticle->m_fInitialTime = fTime;
			pParticle->m_fLifeTime = GenRan(PARTICLE_LIFETIME);
			pParticle->m_fSize = GenRan(PARTICLE_SIZE-5) + 5.0f;
			pParticle->m_vecInitPos = PARTICLE_STARTPOS;
			pParticle->m_vecInitVel = D3DXVECTOR3(GenRan(7, true), GenRan(7, true), 0.0f);
		}

		m_vecAliveParticles.push_back(pParticle);
		m_vecDeadParticles.pop_back();
	}
}

//--------------------------------------------------------------------------------------
// Rejects any devices that aren't acceptable by returning false
//--------------------------------------------------------------------------------------
bool CALLBACK IsDeviceAcceptable( D3DCAPS9* pCaps, D3DFORMAT AdapterFormat,
                                  D3DFORMAT BackBufferFormat, bool bWindowed, void* pUserContext )
{
    // check support for pixel and vertex shader versions 2.0
    if (pCaps->PixelShaderVersion < D3DPS_VERSION(2, 0) || pCaps->VertexShaderVersion < D3DVS_VERSION(2, 0))
        return false;

    return true;
}


//--------------------------------------------------------------------------------------
// Before a device is created, modify the device settings as needed
//--------------------------------------------------------------------------------------
bool CALLBACK ModifyDeviceSettings( DXUTDeviceSettings* pDeviceSettings, const D3DCAPS9* pCaps, void* pUserContext )
{
    // if device isn't HAL inform of performance issues
    if (pCaps->DeviceType != D3DDEVTYPE_HAL)
        MessageBox(NULL, L"Full hardware support not avaliable. Performance will be affected.", L"Warning", MB_OK);

    return true;
}


//--------------------------------------------------------------------------------------
// Create any D3DPOOL_MANAGED resources here
//--------------------------------------------------------------------------------------
HRESULT CALLBACK OnCreateDevice( IDirect3DDevice9* pd3dDevice, const D3DSURFACE_DESC* pBackBufferSurfaceDesc, void* pUserContext )
{
    HRESULT hr;

	// define particle vertex structure
	D3DVERTEXELEMENT9 VertexArray[] =
	{
		{0, 0, D3DDECLTYPE_FLOAT3, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_POSITION, 0},	// position
		{0, 12, D3DDECLTYPE_FLOAT3, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_TEXCOORD, 0},	// velocity
		{0, 24, D3DDECLTYPE_FLOAT1, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_TEXCOORD, 1},	// time
		{0, 28, D3DDECLTYPE_FLOAT1, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_TEXCOORD, 2},	// life
		{0, 32, D3DDECLTYPE_FLOAT1, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_TEXCOORD, 3},	// size
		D3DDECL_END()
	};

	V_RETURN(pd3dDevice->CreateVertexDeclaration(VertexArray, &g_pParticleDecl))

	// create textures
	V_RETURN(D3DXCreateTextureFromFile(pd3dDevice, L"bolt.dds", &g_pTextureBolt))
	V_RETURN(D3DXCreateTextureFromFile(pd3dDevice, L"torch.dds", &g_pTextureFire))

    return S_OK;
}


//--------------------------------------------------------------------------------------
// Create any D3DPOOL_DEFAULT resources here
//--------------------------------------------------------------------------------------
HRESULT CALLBACK OnResetDevice( IDirect3DDevice9* pd3dDevice,
                                const D3DSURFACE_DESC* pBackBufferSurfaceDesc, void* pUserContext )
{
    HRESULT hr;

    // create vertex buffer used to hold particles
	V_RETURN(pd3dDevice->CreateVertexBuffer(	PARTICLE_NUM*sizeof(Particle), 
												D3DUSAGE_DYNAMIC | D3DUSAGE_WRITEONLY | D3DUSAGE_POINTS,
												0, D3DPOOL_DEFAULT, &g_pVB, 0))


    // calculate and set projection matrix
    D3DXMATRIX matProj;
    D3DXMatrixPerspectiveFovLH(&matProj, D3DX_PI * 0.45f, 4.0f/3.0f, 0.5f, 1000.0f);
    V_RETURN(pd3dDevice->SetTransform(D3DTS_PROJECTION, &matProj))

    // calculate and set view matrix
    D3DXMATRIX matCamera;
    D3DXMatrixLookAtLH(&matCamera,	&g_vecCamPos,
                                    &g_vecCamLook,
                                    &g_vecCamUp);
    V_RETURN(pd3dDevice->SetTransform(D3DTS_VIEW, &matCamera))

    // create effect
    LPD3DXBUFFER pBuffer = NULL;
    if (FAILED(D3DXCreateEffectFromFile(pd3dDevice, g_strFileName, 0, 0, D3DXSHADER_DEBUG,
                                        0, &g_pEffect, &pBuffer)))
    {
        // if creation fails, and debug information has been returned, output debug info
        if (pBuffer)
        {
            OutputDebugStringA((char*)pBuffer->GetBufferPointer());
            SAFE_RELEASE(pBuffer);
        }

        MessageBox(0, L"D3DXCreateEffectFromFile() - FAILED", L"ERROR", 0);
        return E_FAIL;
    }

    // obtain handles to variables within effect
    g_handleMatWVP = g_pEffect->GetParameterByName(0, "g_matWorldViewProjection");
	g_handleFTime = g_pEffect->GetParameterByName(0, "g_fTime");
	g_handleVecAccel = g_pEffect->GetParameterByName(0, "g_vecAccel");
	g_handleTexture = g_pEffect->GetParameterByName(0, "g_texture");

	// set initial values
	V_RETURN(g_pEffect->SetValue(g_handleVecAccel, ACCEL_ONE, sizeof(D3DXVECTOR3)))
    V_RETURN(g_pEffect->SetTexture(g_handleTexture, g_pTextureFire))

	// set technique
    V_RETURN(g_pEffect->SetTechnique("ParticleEffectTech"))

    // create font used for rendering text
    V_RETURN(D3DXCreateFont(pd3dDevice, 16, 0, FW_BOLD, 0, false, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS,
                            DEFAULT_QUALITY, DEFAULT_PITCH | FF_DONTCARE, L"Arial", &g_pFont))

    return S_OK;
}


//--------------------------------------------------------------------------------------
// Handle updates to the scene
//--------------------------------------------------------------------------------------
void CALLBACK OnFrameMove( IDirect3DDevice9* pd3dDevice, double fTime, float fElapsedTime, void* pUserContext )
{
	UpdateParticles((float)fTime);
}

//--------------------------------------------------------------------------------------
// Renders all text required by scene
// NB: Must be called between LPDIRECT3DDEVICE9::BeginScene and LPDIRECT3DDEVICE9::EndScene
//--------------------------------------------------------------------------------------

HRESULT RenderText()
{
    HRESULT hr;
    RECT rectPos; // used to position text on screen coordinates
    
    // text rendered to screen
    LPCWSTR textInfo1(L"Press F1 to switch between particle effects");

    // define rectangle extremities
    rectPos.top = 10;
    rectPos.left = 10;
    rectPos.bottom = g_nWindowHeight - 10;
    rectPos.right = g_nWindowWidth - 10;

    // draw text
    V_RETURN(g_pFont->DrawText(0, textInfo1, -1, &rectPos, DT_LEFT | DT_BOTTOM | DT_NOCLIP, g_colourFont))

    return S_OK;
}


//--------------------------------------------------------------------------------------
// Render the scene
//--------------------------------------------------------------------------------------
void CALLBACK OnFrameRender( IDirect3DDevice9* pd3dDevice, double fTime, float fElapsedTime, void* pUserContext )
{
    HRESULT hr;

    D3DXMATRIX matView, matProj, matWorld;
    D3DXMATRIX matWorldViewProj;

    // Clear the render target and the zbuffer
    V(pd3dDevice->Clear(0, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER, D3DCOLOR_ARGB(0, 0, 0, 0), 1.0f, 0))

    // get matrices
    V(pd3dDevice->GetTransform(D3DTS_VIEW, &matView))
    V(pd3dDevice->GetTransform(D3DTS_PROJECTION, &matProj))
    V(pd3dDevice->GetTransform(D3DTS_WORLD, &matWorld))

	// calculate and set WVP matrix
	D3DXMatrixMultiply(&matWorldViewProj, &matWorld, &matView);
	D3DXMatrixMultiply(&matWorldViewProj, &matWorldViewProj, &matProj);
	V(g_pEffect->SetMatrix(g_handleMatWVP, &matWorldViewProj))

	// set run time
	V(g_pEffect->SetFloat(g_handleFTime, (float)fTime))

    // set particle vertex structure
    V(pd3dDevice->SetVertexDeclaration(g_pParticleDecl))
    V(pd3dDevice->SetStreamSource(0, g_pVB, 0, sizeof(Particle)))

    // begin drawing
    V(pd3dDevice->BeginScene())

    UINT unPasses;    // stores number of passes required for selected technique
    V(g_pEffect->Begin(&unPasses, 0))

    // iterate through each pass
    for(UINT unPass = 0; unPass < unPasses; ++unPass)
    {
        V(g_pEffect->BeginPass(unPass))
        
		// lock the vertex buffer
		Particle* p = NULL;
		V(g_pVB->Lock(0, 0, (void**)&p, D3DLOCK_DISCARD));
		int vbIndex = 0;

		// copy the live particles in
		for (unsigned int i = 0; i < m_vecAliveParticles.size(); ++i)
		{
			p[vbIndex] = *m_vecAliveParticles[i];
			++vbIndex;
		}

		V(g_pVB->Unlock())

		if (vbIndex > 0)
		{
			// render particles
			V(pd3dDevice->DrawPrimitive(D3DPT_POINTLIST, 0, vbIndex))
		}

        V(g_pEffect->EndPass())
    }

    V(g_pEffect->End())

	V(RenderText())

    // end drawing
    V(pd3dDevice->EndScene())
}


//--------------------------------------------------------------------------------------
// Handle messages to the application
//--------------------------------------------------------------------------------------
LRESULT CALLBACK MsgProc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam,
                          bool* pbNoFurtherProcessing, void* pUserContext )
{
	HRESULT hr;

    switch(uMsg)
    {
        // store current window width and height
        case WM_SIZE:
            g_nWindowWidth = LOWORD(lParam);
            g_nWindowHeight = HIWORD(lParam);
            break;

        case WM_KEYUP:
            switch(wParam)
            {
            // increment through texture sampler states
            case VK_F1:
				g_bParticleSwitch = !g_bParticleSwitch;
				SetupParticles();

				if (g_bParticleSwitch)
				{
					V_RETURN(g_pEffect->SetTexture(g_handleTexture, g_pTextureFire))
					V_RETURN(g_pEffect->SetValue(g_handleVecAccel, ACCEL_ONE, sizeof(D3DXVECTOR3)))
				}
				else
				{
					V_RETURN(g_pEffect->SetTexture(g_handleTexture, g_pTextureBolt))
					V_RETURN(g_pEffect->SetValue(g_handleVecAccel, ACCEL_TWO, sizeof(D3DXVECTOR3)))
				}
				break;
            }
            break;
    }
    return 0;
}


//--------------------------------------------------------------------------------------
// Release resources created in the OnResetDevice callback here
//--------------------------------------------------------------------------------------
void CALLBACK OnLostDevice( void* pUserContext )
{
    SAFE_RELEASE(g_pFont);
    SAFE_RELEASE(g_pEffect);
    SAFE_RELEASE(g_pVB);
}


//--------------------------------------------------------------------------------------
// Release resources created in the OnCreateDevice callback here
//--------------------------------------------------------------------------------------
void CALLBACK OnDestroyDevice( void* pUserContext )
{
	SAFE_RELEASE(g_pTextureFire);
	SAFE_RELEASE(g_pTextureBolt);
	SAFE_RELEASE(g_pParticleDecl);
}



//--------------------------------------------------------------------------------------
// Initialize everything and go into a render loop
//--------------------------------------------------------------------------------------
INT WINAPI WinMain( HINSTANCE, HINSTANCE, LPSTR, int )
{
    // Enable run-time memory check for debug builds.
#if defined(DEBUG) | defined(_DEBUG)
    _CrtSetDbgFlag( _CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF );
#endif

    // Set the callback functions
    DXUTSetCallbackDeviceCreated( OnCreateDevice );
    DXUTSetCallbackDeviceReset( OnResetDevice );
    DXUTSetCallbackDeviceLost( OnLostDevice );
    DXUTSetCallbackDeviceDestroyed( OnDestroyDevice );
    DXUTSetCallbackMsgProc( MsgProc );
    DXUTSetCallbackFrameRender( OnFrameRender );
    DXUTSetCallbackFrameMove( OnFrameMove );

    // Initialize DXUT and create the desired Win32 window and Direct3D device for the application
    DXUTInit( true, true, true ); // Parse the command line, handle the default hotkeys, and show msgboxes
    DXUTSetCursorSettings( true, true ); // Show the cursor and clip it when in full screen
    DXUTCreateWindow( L"Particle Effect" );
    DXUTCreateDevice( D3DADAPTER_DEFAULT, true, g_nWindowWidth, g_nWindowHeight, IsDeviceAcceptable, ModifyDeviceSettings );

	srand(time(NULL));
	SetupParticles();

    DXUTMainLoop();

    return DXUTGetExitCode();
}