//--------------------------------------------------------------------------------------
//	Motion Blur Shader - ITB747
//
//	Author: Michael Samiec - QUT
//	Version: 1.0
//	Date: 6/3/07
//
//	This program demonstrates a pixel shader motion blur technique. It is based upon the
//	motion blur samples avaliable on the nVidia SDK. The effect works by rendering the scene
//	to a texture, calculate each vertice's screen velocity, and then offset render the scene
//	by offseting into the texture based on the pixel's current position and its velocity. The
//	blur is sampled 16 times.
//
//	The program demonstrates a simple position and colour shader pass through using
//	HLSL and DirectX 9.0c. This program is based upon the EmptyProject template provided 
//	by Microsoft through the DirectX Sample Browser.
//
//	Copyright (c) Microsoft Corporation. All rights reserved.
//--------------------------------------------------------------------------------------
#include "dxstdafx.h"

// function signatures
HRESULT	RenderText();

// Global variables

LPD3DXEFFECT					g_pEffect = NULL;		// effect pointer that encapsulates the shader
LPD3DXFONT						g_pFont = NULL;			// font used for drawing text on screen
LPD3DXMESH						g_pMeshSphere = NULL;
LPD3DXMESH						g_pMeshCone = NULL;

LPDIRECT3DTEXTURE9				g_pTexture = NULL;		// used to render scene
LPDIRECT3DSURFACE9				g_pTexSurface = NULL;	// used to access surface of texture
LPDIRECT3DSURFACE9				g_pBBSurface = NULL;	// used to access default surface

// effect handles
D3DXHANDLE						g_handleMatWVP = NULL;
D3DXHANDLE						g_handleMatPrevWVP = NULL;
D3DXHANDLE						g_handleMatWV = NULL;
D3DXHANDLE						g_handleMatPrevWV = NULL;
D3DXHANDLE						g_handleMatWIT = NULL;
D3DXHANDLE						g_handleMatWorld = NULL;
D3DXHANDLE						g_handleTexture = NULL;
D3DXHANDLE						g_handleFBlurFactor = NULL;
D3DXHANDLE						g_handleMatAmb = NULL;
D3DXHANDLE						g_handleMatDiff = NULL;

// camera variables
D3DXVECTOR3						g_vecCamPos	(0.0f, 0.0f, 0.0f);
D3DXVECTOR3						g_vecCamLook(0.0f, 0.0f, 1.0f);
D3DXVECTOR3						g_vecCamUp	(0.0f, 1.0f, 0.0f);

// light direction
D3DXVECTOR3						g_vecLightDir(1.0f, 1.0f, -1.0f);

// light colours
D3DXCOLOR						g_lightAmbient	= D3DXCOLOR(0.3f, 0.4f, 0.3f, 1.0f);
D3DXCOLOR						g_lightDiffuse	= D3DXCOLOR(1.0f, 1.0f, 1.0f, 1.0f);

// plane colours
D3DXCOLOR						g_matPlaneAmb	= D3DXCOLOR(0.2f, 0.2f, 0.7f, 1.0f);
D3DXCOLOR						g_matPlaneDiff	= D3DXCOLOR(0.2f, 0.5f, 0.5f, 0.5f);

// object colours
D3DXCOLOR						g_matTeapotAmb	= D3DXCOLOR(0.9f, 0.2f, 0.0f, 1.0f);
D3DXCOLOR						g_matTeapotDiff	= D3DXCOLOR(1.0f, 0.5f, 0.0f, 0.2f);

// colour used for text rendering
D3DCOLOR						g_colourFont = D3DCOLOR_XRGB(255, 255, 255);

// hold previous WVP and WV matrices for moving sphere
D3DXMATRIX						g_matPrevWVP;
D3DXMATRIX						g_matPrevWV;

LPCWSTR							g_textEffect = NULL;	// extra text identifying which effect is currently active
FLOAT							g_fSphereRotY = 0.0f;	// controls sphere's rotation around cone
BOOL							g_bFirstFrame = true;	// used to initalize previous matrices to initial matrix on first render
FLOAT							g_fBlurFactor = 2.0f;	// initial blur factor, can be alter in the program
BOOL							g_bFrontBlur = false;	// specifies whether to blur the front side of the sphere

INT								g_nWindowWidth = 640;		// current window width
INT								g_nWindowHeight = 480;		// current window height
LPCWSTR							g_strFileName(L"Effect.fx");// effect file name

//--------------------------------------------------------------------------------------
// Rejects any devices that aren't acceptable by returning false
//--------------------------------------------------------------------------------------
bool CALLBACK IsDeviceAcceptable( D3DCAPS9* pCaps, D3DFORMAT AdapterFormat, 
                                  D3DFORMAT BackBufferFormat, bool bWindowed, void* pUserContext )
{
	// check support for pixel and vertex shader versions 2.0
	if (pCaps->PixelShaderVersion < D3DPS_VERSION(2, 0) || pCaps->VertexShaderVersion < D3DVS_VERSION(2, 0))
		return false;
	
    return true;
}


//--------------------------------------------------------------------------------------
// Before a device is created, modify the device settings as needed
//--------------------------------------------------------------------------------------
bool CALLBACK ModifyDeviceSettings( DXUTDeviceSettings* pDeviceSettings, const D3DCAPS9* pCaps, void* pUserContext )
{
	// if device isn't HAL inform of performance issues
	if (pCaps->DeviceType != D3DDEVTYPE_HAL)
		MessageBox(NULL, L"Full hardware support not avaliable. Performance will be affected.", L"Warning", MB_OK);

    return true;
}


//--------------------------------------------------------------------------------------
// Create any D3DPOOL_MANAGED resources here 
//--------------------------------------------------------------------------------------
HRESULT CALLBACK OnCreateDevice( IDirect3DDevice9* pd3dDevice, const D3DSURFACE_DESC* pBackBufferSurfaceDesc, void* pUserContext )
{
    return S_OK;
}


//--------------------------------------------------------------------------------------
// Create any D3DPOOL_DEFAULT resources here 
//--------------------------------------------------------------------------------------
HRESULT CALLBACK OnResetDevice( IDirect3DDevice9* pd3dDevice, 
                                const D3DSURFACE_DESC* pBackBufferSurfaceDesc, void* pUserContext )
{
	HRESULT hr;
	D3DXMATRIX matProj, matCamera;

	// create effect
	ID3DXBuffer* pBuffer = NULL;
	if (FAILED(D3DXCreateEffectFromFile(pd3dDevice, g_strFileName, 0, 0, D3DXSHADER_DEBUG,
										0, &g_pEffect, &pBuffer)))
	{
		// if creation fails, and debug information has been returned, output debug info
		if (pBuffer)
		{
			OutputDebugStringA((char*)pBuffer->GetBufferPointer());
			SAFE_RELEASE(pBuffer);
		}

		MessageBox(0, L"D3DXCreateEffectFromFile() - FAILED", L"ERROR", 0);
		return E_FAIL;
	}

	// get handles to matrices
	g_handleMatWVP = g_pEffect->GetParameterByName(0, "g_matWVP");
	g_handleMatWV = g_pEffect->GetParameterByName(0, "g_matWV");
	g_handleMatPrevWVP = g_pEffect->GetParameterByName(0, "g_matPrevWVP");
	g_handleMatPrevWV = g_pEffect->GetParameterByName(0, "g_matPrevWV");
	g_handleMatWIT = g_pEffect->GetParameterByName(0, "g_matWIT");
	g_handleMatWorld = g_pEffect->GetParameterByName(0, "g_matWorld");

	// get handles to other variables
	g_handleMatAmb = g_pEffect->GetParameterByName(0, "g_vecMaterialAmbient");
	g_handleMatDiff = g_pEffect->GetParameterByName(0, "g_vecMaterialDiffuse");
	g_handleFBlurFactor = g_pEffect->GetParameterByName(0, "g_fBlurFactor");
	g_handleTexture = g_pEffect->GetParameterByName(0, "g_textureScene");

	// normalize light direction
	D3DXVECTOR3 vecLightDirNormalize;
	D3DXVec3Normalize(&vecLightDirNormalize, &g_vecLightDir);

	// set variables within effect that only need to be set once
	V(g_pEffect->SetValue("g_vecLightDirection", &vecLightDirNormalize, sizeof(D3DXVECTOR3)))
	V(g_pEffect->SetValue("g_vecCameraPos", &g_vecCamPos, sizeof(D3DXVECTOR3)))
	V(g_pEffect->SetValue("g_vecLightAmbient", &g_lightAmbient, sizeof(D3DXCOLOR)))
	V(g_pEffect->SetValue("g_vecLightDiffuse", &g_lightDiffuse, sizeof(D3DXCOLOR)))

	V(g_pEffect->SetFloat(g_handleFBlurFactor, g_fBlurFactor))
	V(g_pEffect->SetBool("g_bFrontBlur", g_bFrontBlur))
	
	V(g_pEffect->SetTechnique("MotionTech"))
	g_textEffect = L"Motion Blur";

	// create meshes
	V_RETURN(D3DXCreateSphere(pd3dDevice, 0.4f, 15, 15, &g_pMeshSphere, NULL))
	V_RETURN(D3DXCreateCylinder(pd3dDevice, 1.00f, 0.0f, 2.0f, 20, 10, &g_pMeshCone, NULL))

	// calculate and set projection matrix
	D3DXMatrixPerspectiveFovLH(&matProj, D3DX_PI * 0.5f, 4.0f/3.0f, 0.5f, 100.0f);
	V_RETURN(pd3dDevice->SetTransform(D3DTS_PROJECTION, &matProj))

	// calculate and set view matrix
	D3DXMatrixLookAtLH(&matCamera,	&g_vecCamPos,
									&g_vecCamLook,
									&g_vecCamUp);
	V_RETURN(pd3dDevice->SetTransform(D3DTS_VIEW, &matCamera))

	// create font used for rendering text
	V_RETURN(D3DXCreateFont(pd3dDevice, 16, 0, FW_BOLD, 0, false, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS,
							DEFAULT_QUALITY, DEFAULT_PITCH | FF_DONTCARE, L"Arial", &g_pFont))

	// get current display mode to ensure texture has same format
	D3DDISPLAYMODE DisplayMode;
	V_RETURN(pd3dDevice->GetDisplayMode(D3DADAPTER_DEFAULT, &DisplayMode))

	// create texture for rendering scene - use D3DX_DEFAULT as sizes larger don't have a depth buffer
	V_RETURN(D3DXCreateTexture(pd3dDevice, D3DX_DEFAULT, D3DX_DEFAULT, 1, D3DUSAGE_RENDERTARGET, DisplayMode.Format, D3DPOOL_DEFAULT, &g_pTexture))
	V_RETURN(g_pTexture->GetSurfaceLevel(0, &g_pTexSurface))	// get texture surface
	V_RETURN(pd3dDevice->GetRenderTarget(0, &g_pBBSurface))		// get default surface

	g_bFirstFrame = true;

    return S_OK;
}

//--------------------------------------------------------------------------------------
// Renders all text required by scene
// NB: Must be called between LPDIRECT3DDEVICE9::BeginScene and LPDIRECT3DDEVICE9::EndScene
//--------------------------------------------------------------------------------------

HRESULT RenderText()
{
	HRESULT hr;
	RECT rectPos; // used to position text on screen coordinates
	
	// text rendered to screen
	LPCWSTR textInfo1(L"F1/F2 - decrease/increase motion blur\nF3 - turn on/off front side blur");
	LPCWSTR textInfo2(L"F5 - Motion blur\nF6 - Motion blur highlight\nF7 - No motion blur");

	// define rectangle extremities
	rectPos.top = 10; 
	rectPos.left = 10;
	rectPos.bottom = g_nWindowHeight - 10;
	rectPos.right = g_nWindowWidth - 10;

	// draw text
	V_RETURN(g_pFont->DrawText(0, textInfo1, -1, &rectPos, DT_LEFT | DT_BOTTOM, g_colourFont))
	V_RETURN(g_pFont->DrawText(0, textInfo2, -1, &rectPos, DT_RIGHT | DT_BOTTOM, g_colourFont))
	V_RETURN(g_pFont->DrawText(0, g_textEffect, -1, &rectPos, DT_CENTER | DT_TOP, g_colourFont))

	return S_OK;
}

//--------------------------------------------------------------------------------------
// Handle updates to the scene
//--------------------------------------------------------------------------------------
void CALLBACK OnFrameMove( IDirect3DDevice9* pd3dDevice, double fTime, float fElapsedTime, void* pUserContext )
{
	// rotate sphere around cone
	if (g_fSphereRotY <= D3DX_PI*2)
		g_fSphereRotY += fElapsedTime * 4;
	else
		g_fSphereRotY -= D3DX_PI*2;
}

//--------------------------------------------------------------------------------------
// Render the scene 
//--------------------------------------------------------------------------------------
void CALLBACK OnFrameRender( IDirect3DDevice9* pd3dDevice, double fTime, float fElapsedTime, void* pUserContext )
{
	HRESULT hr;
	UINT unPasses;

	D3DXMATRIX matRotY, matRotX, matRot;
	D3DXMATRIX matTrans1, matTrans2;
	D3DXMATRIX matView, matProj, matWorld;
	D3DXMATRIX matWVP, matWV, matWIT;

	// get matrices
	V(pd3dDevice->GetTransform(D3DTS_VIEW, &matView))
	V(pd3dDevice->GetTransform(D3DTS_PROJECTION, &matProj))
	V(pd3dDevice->GetTransform(D3DTS_WORLD, &matWorld))

	//V(g_pEffect->SetMatrix("g_mat
	V(g_pEffect->SetMatrix("g_matPrevWVP", &g_matPrevWVP))
	V(g_pEffect->SetMatrix(g_handleMatWorld, &matWorld))
	V(g_pEffect->SetMatrix(g_handleMatWVP, &matWVP))

	// begin drawing
	V(pd3dDevice->BeginScene())

	// stores number of passes required for selected technique
	V(g_pEffect->Begin(&unPasses, 0))

	// iterate through each pass
	for(UINT unPass = 0; unPass < unPasses; ++unPass)
	{
		// render scene to texture
		if (unPass == 0)
		{
			V(pd3dDevice->SetRenderTarget(0, g_pTexSurface))
			V(pd3dDevice->Clear(0, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER, D3DCOLOR_ARGB(0, 20, 20, 20), 1.0f, 0))
		}
		// render motion blurred scene
		else if (unPass == 1)
		{
			V(pd3dDevice->SetRenderTarget(0, g_pBBSurface))
			V(pd3dDevice->Clear(0, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER, D3DCOLOR_ARGB(0, 20, 20, 20), 1.0f, 0))

			V(g_pEffect->SetTexture(g_handleTexture, g_pTexture))
		}

		V(g_pEffect->BeginPass(unPass))

		D3DXMatrixTranslation(&matTrans1, 0.0f, 0.0f, 3.5f);

		// render cone - as it doesn't move, just set the prev matrix as the current one

		// calculate cone world matrix
		D3DXMatrixRotationX(&matRotX, -D3DX_PI * 0.5f);
		D3DXMatrixMultiply(&matWorld, &matRotX, &matTrans1);

		// calculate world-view-projection matrix
		D3DXMatrixMultiply(&matWV, &matWorld, &matView);
		D3DXMatrixMultiply(&matWVP, &matWV, &matProj);

		// calculate world-inverse-transpose matrix
		D3DXMatrixInverse(&matWIT, NULL, &matWorld);
		D3DXMatrixTranspose(&matWIT, &matWIT);

		// set effect variables
		V(g_pEffect->SetMatrix(g_handleMatWVP, &matWVP))
		V(g_pEffect->SetMatrix(g_handleMatWV, &matWV))
		V(g_pEffect->SetMatrix(g_handleMatPrevWVP, &matWVP))
		V(g_pEffect->SetMatrix(g_handleMatPrevWV, &matWV))
		V(g_pEffect->SetMatrix(g_handleMatWIT, &matWIT))
		V(g_pEffect->SetMatrix(g_handleMatWorld, &matWorld))
		V(g_pEffect->SetValue(g_handleMatAmb, &g_matPlaneAmb, sizeof(D3DXCOLOR)))
		V(g_pEffect->SetValue(g_handleMatDiff, &g_matPlaneDiff, sizeof(D3DXCOLOR)))
		V(g_pEffect->CommitChanges())

		V(g_pMeshCone->DrawSubset(0))

		// render sphere
		
		D3DXMatrixRotationY(&matRotY, g_fSphereRotY);
		D3DXMatrixTranslation(&matTrans2, 1.5f, 0.0f, 0.0f);

		// calculate sphere matrix
		D3DXMatrixMultiply(&matWorld, &matTrans2, &matRotY);
		D3DXMatrixMultiply(&matWorld, &matWorld, &matTrans1);

		// calculate world-view-projection matrix
		D3DXMatrixMultiply(&matWV, &matWorld, &matView);
		D3DXMatrixMultiply(&matWVP, &matWV, &matProj);

		// calculate world-inverse-transpose matrix
		D3DXMatrixInverse(&matWIT, NULL, &matWorld);
		D3DXMatrixTranspose(&matWIT, &matWIT);
		
		// if this is the first render, set prev matrices to current ones
		if (g_bFirstFrame)
		{
			g_matPrevWVP = matWVP;
			g_matPrevWV = matWV;
			g_bFirstFrame = false;
		}

		// set effect variables
		V(g_pEffect->SetMatrix(g_handleMatWVP, &matWVP))
		V(g_pEffect->SetMatrix(g_handleMatWV, &matWV))
		V(g_pEffect->SetMatrix(g_handleMatPrevWVP, &g_matPrevWVP))
		V(g_pEffect->SetMatrix(g_handleMatPrevWV, &g_matPrevWV))
		V(g_pEffect->SetMatrix(g_handleMatWIT, &matWIT))
		V(g_pEffect->SetMatrix(g_handleMatWorld, &matWorld))
		V(g_pEffect->SetValue(g_handleMatAmb, &g_matTeapotAmb, sizeof(D3DXCOLOR)))
		V(g_pEffect->SetValue(g_handleMatDiff, &g_matTeapotDiff, sizeof(D3DXCOLOR)))
		V(g_pEffect->CommitChanges())

		// render sphere
		V(g_pMeshSphere->DrawSubset(0))

		V(g_pEffect->EndPass())
	}

	V(g_pEffect->End())

	V(RenderText())

	// end drawing
	V(pd3dDevice->EndScene())

	// set previous matrices with current ones
	g_matPrevWVP = matWVP;
	g_matPrevWV = matWV;
}


//--------------------------------------------------------------------------------------
// Handle messages to the application 
//--------------------------------------------------------------------------------------
LRESULT CALLBACK MsgProc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam, 
                          bool* pbNoFurtherProcessing, void* pUserContext )
{
	HRESULT hr;

	switch(uMsg)
	{
		// store current window width and height
		case WM_SIZE:
			g_nWindowWidth = LOWORD(lParam);
			g_nWindowHeight = HIWORD(lParam);
			break;

		case WM_KEYUP:
		{
			switch(wParam)
			{

			// increase blur factor
			case VK_F1:
				if (g_fBlurFactor > 0.1f)
					g_fBlurFactor -= 0.25f;

				V(g_pEffect->SetFloat(g_handleFBlurFactor, g_fBlurFactor))
				break;

			// decrease blur factor
			case VK_F2:
				if (g_fBlurFactor < 4.0f)
					g_fBlurFactor += 0.25f;

				V(g_pEffect->SetFloat(g_handleFBlurFactor, g_fBlurFactor))
				break;

			case VK_F3:
				g_bFrontBlur = !g_bFrontBlur;
				V(g_pEffect->SetBool("g_bFrontBlur", g_bFrontBlur))
				break;

			case VK_F5:
				if (g_pEffect)
					V(g_pEffect->SetTechnique("MotionTech"))

				g_textEffect = L"Motion Blur";
				break;

			case VK_F6:
				if (g_pEffect)
					V(g_pEffect->SetTechnique("MotionGreyTech"))

				g_textEffect = L"Greyscale Blur Highlight";
				break;

			case VK_F7:
				if (g_pEffect)
					V(g_pEffect->SetTechnique("NoMotionTech"))

				g_textEffect = L"No Motion Blur";
				break;
			}
		}
	}
	return 0;
}


//--------------------------------------------------------------------------------------
// Release resources created in the OnResetDevice callback here 
//--------------------------------------------------------------------------------------
void CALLBACK OnLostDevice( void* pUserContext )
{
	SAFE_RELEASE(g_pTexture);
	SAFE_RELEASE(g_pTexSurface);
	SAFE_RELEASE(g_pBBSurface);
	SAFE_RELEASE(g_pFont);		
	SAFE_RELEASE(g_pEffect);
	SAFE_RELEASE(g_pMeshSphere);
	SAFE_RELEASE(g_pMeshCone);
}


//--------------------------------------------------------------------------------------
// Release resources created in the OnCreateDevice callback here
//--------------------------------------------------------------------------------------
void CALLBACK OnDestroyDevice( void* pUserContext )
{
}



//--------------------------------------------------------------------------------------
// Initialize everything and go into a render loop
//--------------------------------------------------------------------------------------
INT WINAPI WinMain( HINSTANCE, HINSTANCE, LPSTR, int )
{
    // Enable run-time memory check for debug builds.
#if defined(DEBUG) | defined(_DEBUG)
    _CrtSetDbgFlag( _CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF );
#endif

    // Set the callback functions
    DXUTSetCallbackDeviceCreated( OnCreateDevice );
    DXUTSetCallbackDeviceReset( OnResetDevice );
    DXUTSetCallbackDeviceLost( OnLostDevice );
    DXUTSetCallbackDeviceDestroyed( OnDestroyDevice );
    DXUTSetCallbackMsgProc( MsgProc );
    DXUTSetCallbackFrameRender( OnFrameRender );
    DXUTSetCallbackFrameMove( OnFrameMove );

    // Initialize DXUT and create the desired Win32 window and Direct3D device for the application
    DXUTInit( true, true, true ); // Parse the command line, handle the default hotkeys, and show msgboxes
    DXUTSetCursorSettings( true, true ); // Show the cursor and clip it when in full screen
    DXUTCreateWindow( L"Motion Blur Shader" );
    DXUTCreateDevice( D3DADAPTER_DEFAULT, true, g_nWindowWidth, g_nWindowHeight, IsDeviceAcceptable, ModifyDeviceSettings );

    // Start the render loop
    DXUTMainLoop();

    return DXUTGetExitCode();
}


