//--------------------------------------------------------------------------------------
//	Multi-texture Shader - ITB747
//
//	Author: Michael Samiec - QUT
//	Version: 1.0
//	Date: 19/2/07
//
//	This program demonstrates a shader that takes two different textures and outputs them onto
//	a single surface.
//
//	This program is based upon the EmptyProject template provided by Microsoft Corporation 
//	through the DirectX Sample Browser. The program is also based upon DXUT (DirectX Utility
//	Toolkit) and the related files can be found in \common. 
//
//	Copyright (c) Microsoft Corporation. All rights reserved.
//
//	The 'metal.jpg' and 'copper.jpg' textures are sourced from http://www.texturewarehouse.com/gallery/
//--------------------------------------------------------------------------------------
#include "dxstdafx.h"

// Added function signatures
HRESULT RenderText();

// Global variables

LPD3DXEFFECT					g_pEffect = NULL;		// effect pointer that encapsulates the shader
LPD3DXFONT						g_pFont = NULL;			// font used for drawing text on screen
LPD3DXMESH						g_pMeshBox = NULL;		// mesh to hold the box
LPDIRECT3DTEXTURE9				g_pTexture1 = NULL;	
LPDIRECT3DTEXTURE9				g_pTexture2 = NULL;		

D3DXVECTOR3						g_vecCamPos	(0.0f, 0.0f, 0.0f);	// camera position
D3DXVECTOR3						g_vecCamLook(0.0f, 0.0f, 1.0f);	// camera look
D3DXVECTOR3						g_vecCamUp	(0.0f, 1.0f, 0.0f);	// camera up

D3DCOLOR						g_colourFont = D3DCOLOR_XRGB(255, 255, 255); // colour used for text rendering

D3DXHANDLE						g_handleBlendFactor = NULL;	// handle to blend factor of two textures
D3DXHANDLE						g_handleTechTex1 = NULL;	// handle to texture 1 technique
D3DXHANDLE						g_handleTechTex2 = NULL;	// handle to texture 2 technique
D3DXHANDLE						g_handleTechTexBoth = NULL;	// handle to texture blend technique
D3DXHANDLE						g_handleMatWVP = NULL;		// handle to worldviewprojection matrix 

FLOAT							g_fBlend = 0.5f;			// variable used to blend textures
FLOAT							g_fRotate = 0.0f;			// used to rotate cubes

INT								g_nWindowWidth = 640;		// current window width
INT								g_nWindowHeight = 480;		// current window height
LPCWSTR							g_strEffectFilename(L"Effect.fx");		// effect filename
LPCWSTR							g_strBoxFilename(L"cube_texcoord.x");	// cube mesh filename

// vertex structure
struct Vertex_PosTex
{
	D3DXVECTOR3 pos;
	D3DXVECTOR2	texture;
};

//--------------------------------------------------------------------------------------
// Rejects any devices that aren't acceptable by returning false
//--------------------------------------------------------------------------------------
bool CALLBACK IsDeviceAcceptable( D3DCAPS9* pCaps, D3DFORMAT AdapterFormat, 
                                  D3DFORMAT BackBufferFormat, bool bWindowed, void* pUserContext )
{
	// check support for pixel and vertex shader versions 2.0
	if (pCaps->PixelShaderVersion < D3DPS_VERSION(2, 0) || pCaps->VertexShaderVersion < D3DVS_VERSION(2, 0))
		return false;

    return true;
}


//--------------------------------------------------------------------------------------
// Before a device is created, modify the device settings as needed
//--------------------------------------------------------------------------------------
bool CALLBACK ModifyDeviceSettings( DXUTDeviceSettings* pDeviceSettings, const D3DCAPS9* pCaps, void* pUserContext )
{
	// if device isn't HAL inform of performance issues
	if (pCaps->DeviceType != D3DDEVTYPE_HAL)
		MessageBox(NULL, L"Full hardware support not avaliable. Performance will be affected.", L"Warning", MB_OK);

    return true;
}


//--------------------------------------------------------------------------------------
// Create any D3DPOOL_MANAGED resources here 
//--------------------------------------------------------------------------------------
HRESULT CALLBACK OnCreateDevice( IDirect3DDevice9* pd3dDevice, const D3DSURFACE_DESC* pBackBufferSurfaceDesc, void* pUserContext )
{
	HRESULT hr;

	// managed memory so only needs to be recreated when the device is created
	V_RETURN(D3DXLoadMeshFromX(g_strBoxFilename, D3DXMESH_MANAGED, pd3dDevice, NULL, NULL, NULL, NULL, &g_pMeshBox))

	// create textures
	V_RETURN(D3DXCreateTextureFromFile(pd3dDevice, L"metal.jpg", &g_pTexture1))
	V_RETURN(D3DXCreateTextureFromFile(pd3dDevice, L"copper.jpg", &g_pTexture2))

    return S_OK;
}


//--------------------------------------------------------------------------------------
// Create any D3DPOOL_DEFAULT resources here 
//--------------------------------------------------------------------------------------
HRESULT CALLBACK OnResetDevice( IDirect3DDevice9* pd3dDevice, 
                                const D3DSURFACE_DESC* pBackBufferSurfaceDesc, void* pUserContext )
{
	HRESULT hr;

	// calculate and set projection matrix
	D3DXMATRIX matProj;
	D3DXMatrixPerspectiveFovLH(&matProj, D3DX_PI * 0.25f, 1.5f, 1.0f, 1000.0f);
	V_RETURN(pd3dDevice->SetTransform(D3DTS_PROJECTION, &matProj))

	// calculate and set view matrix
	D3DXMATRIX matCamera;
	D3DXMatrixLookAtLH(&matCamera,	&g_vecCamPos,
									&g_vecCamLook,
									&g_vecCamUp);
	V_RETURN(pd3dDevice->SetTransform(D3DTS_VIEW, &matCamera))

	// calculate and set world matrix
	D3DXMATRIX matTrans;
	D3DXMatrixTranslation(&matTrans, -2.0f, 0.0f, 5.0f);
	V_RETURN(pd3dDevice->SetTransform(D3DTS_WORLD, &matTrans))

	// create effect
	LPD3DXBUFFER pBuffer = NULL;
	if (FAILED(D3DXCreateEffectFromFile(pd3dDevice, g_strEffectFilename, 0, 0, D3DXSHADER_DEBUG,
										0, &g_pEffect, &pBuffer)))
	{
		// if creation fails, and debug information has been returned, output debug info
		if (pBuffer)
		{
			OutputDebugStringA((char*)pBuffer->GetBufferPointer());
			SAFE_RELEASE(pBuffer);
		}

		MessageBox(0, L"D3DXCreateEffectFromFile() - FAILED", L"ERROR", 0);
		return E_FAIL;
	}

	// set variables in effect that don't need to be changed
	V_RETURN(g_pEffect->SetTexture("g_texture1", g_pTexture1))
	V_RETURN(g_pEffect->SetTexture("g_texture2", g_pTexture2))

	// obtain handles to variables within effect
	g_handleBlendFactor = g_pEffect->GetParameterByName(0, "g_fBlendFactor");
	g_handleTechTex1 = g_pEffect->GetTechniqueByName("Texture1");
	g_handleTechTex2 = g_pEffect->GetTechniqueByName("Texture2");
	g_handleTechTexBoth = g_pEffect->GetTechniqueByName("TextureBoth");
	g_handleMatWVP = g_pEffect->GetParameterByName(0, "g_matWorldViewProjection");

	// create font used for rendering text
	V_RETURN(D3DXCreateFont(pd3dDevice, 16, 0, FW_BOLD, 0, false, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS,
							DEFAULT_QUALITY, DEFAULT_PITCH | FF_DONTCARE, L"Arial", &g_pFont))

	return S_OK;
}


//--------------------------------------------------------------------------------------
// Handle updates to the scene
//--------------------------------------------------------------------------------------
void CALLBACK OnFrameMove( IDirect3DDevice9* pd3dDevice, double fTime, float fElapsedTime, void* pUserContext )
{
	// increment object rotation
	g_fRotate += fElapsedTime;

	if (g_fRotate >= D3DX_PI * 2.0f)
		g_fRotate -= D3DX_PI * 2.0f;
}

//--------------------------------------------------------------------------------------
// Renders all text required by scene
// NB: Must be called between LPDIRECT3DDEVICE9::BeginScene and LPDIRECT3DDEVICE9::EndScene
//--------------------------------------------------------------------------------------

HRESULT RenderText()
{
	HRESULT hr;
	RECT rectPos; // used to position text on screen coordinates
	
	// text rendered to screen
	LPCWSTR textInfo1(L"Press F1/F2 to adjust blend factor");

	// define rectangle extremities
	rectPos.top = 10; 
	rectPos.left = 10;
	rectPos.bottom = g_nWindowHeight - 10;
	rectPos.right = g_nWindowWidth - 10;

	// draw text
	V_RETURN(g_pFont->DrawText(0, textInfo1, -1, &rectPos, DT_BOTTOM | DT_LEFT | DT_NOCLIP, g_colourFont))

	return S_OK;
}


//--------------------------------------------------------------------------------------
// Render the scene 
//--------------------------------------------------------------------------------------
void CALLBACK OnFrameRender( IDirect3DDevice9* pd3dDevice, double fTime, float fElapsedTime, void* pUserContext )
{
	HRESULT hr;

	D3DXMATRIX matView, matProj, matWorld, matTrans, matRotY, matRotWorld;
	D3DXMATRIX matWorldViewProj;

    // Clear the render target and the zbuffer 
	V(pd3dDevice->Clear(0, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER, D3DCOLOR_ARGB(0, 0, 0, 0), 1.0f, 0))

	D3DXMatrixTranslation(&matTrans, 2.0f, 0.0f, 0.0f);	// object offset translation
	D3DXMatrixRotationY(&matRotY, g_fRotate);			// object rotation matrix

	// get matrices
	V(pd3dDevice->GetTransform(D3DTS_VIEW, &matView))
	V(pd3dDevice->GetTransform(D3DTS_PROJECTION, &matProj))
	V(pd3dDevice->GetTransform(D3DTS_WORLD, &matWorld))

	// calculate object rotation matrix
	D3DXMatrixMultiply(&matRotWorld, &matRotY, &matWorld);

	// set blend factor
	V(g_pEffect->SetFloat(g_handleBlendFactor, g_fBlend))

	// for each object
	for (unsigned int i = 0; i < 3; ++i)
	{
		switch (i%3)
		{
		case 0:
			// set left-most cube world matrix
			V(g_pEffect->SetTechnique(g_handleTechTex1))
			matWorld = matRotWorld;
			break;
		case 1:
			// set middle cube world matrix
			V(g_pEffect->SetTechnique(g_handleTechTex2))
			D3DXMatrixMultiply(&matWorld, &matRotWorld, &matTrans);
			break;
		case 2:
			// set right-most cube world matrix
			V(g_pEffect->SetTechnique(g_handleTechTexBoth))
			D3DXMatrixMultiply(&matWorld, &matTrans, &matTrans);
			D3DXMatrixMultiply(&matWorld, &matRotWorld, &matWorld);
			break;
		}
			
		// calculate world-view-projection matrix
		D3DXMatrixMultiply(&matWorldViewProj, &matWorld, &matView);
		D3DXMatrixMultiply(&matWorldViewProj, &matWorldViewProj, &matProj);

		// set worldviewprojection matrix in effect
		V(g_pEffect->SetMatrix(g_handleMatWVP, &matWorldViewProj))

		// begin drawing
		V(pd3dDevice->BeginScene())

		V(RenderText())

		UINT unPasses;	// stores number of passes required for selected technique
		V(g_pEffect->Begin(&unPasses, 0))

		// iterate through each pass
		for(UINT unPass = 0; unPass < unPasses; ++unPass)
		{
			V(g_pEffect->BeginPass(unPass))
			
			// render triangle
			V(g_pMeshBox->DrawSubset(0))

			V(g_pEffect->EndPass())
		}

		V(g_pEffect->End())

		// end drawing
		V(pd3dDevice->EndScene())
	}
}


//--------------------------------------------------------------------------------------
// Handle messages to the application 
//--------------------------------------------------------------------------------------
LRESULT CALLBACK MsgProc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam, 
                          bool* pbNoFurtherProcessing, void* pUserContext )
{
	switch(uMsg)
	{
		case WM_KEYUP:
			switch(wParam)
			{
			case VK_F1:
				// increment blend factor
				g_fBlend -= 0.1f;

				if (g_fBlend < 0.0f)
					g_fBlend = 0.0f;
				break;
			
			case VK_F2:
				// decrement blend factor
				g_fBlend += 0.1f;

				if (g_fBlend > 1.0f)
					g_fBlend = 1.0f;
			}
			break;

		// store current window width and height
		case WM_SIZE:
			g_nWindowWidth = LOWORD(lParam);
			g_nWindowHeight = HIWORD(lParam);
			break;
	}
	return 0;
}


//--------------------------------------------------------------------------------------
// Release resources created in the OnResetDevice callback here 
//--------------------------------------------------------------------------------------
void CALLBACK OnLostDevice( void* pUserContext )
{
	SAFE_RELEASE(g_pFont);
	SAFE_RELEASE(g_pEffect);
}


//--------------------------------------------------------------------------------------
// Release resources created in the OnCreateDevice callback here
//--------------------------------------------------------------------------------------
void CALLBACK OnDestroyDevice( void* pUserContext )
{
	SAFE_RELEASE(g_pMeshBox);
	SAFE_RELEASE(g_pTexture1);
	SAFE_RELEASE(g_pTexture2);
}



//--------------------------------------------------------------------------------------
// Initialize everything and go into a render loop
//--------------------------------------------------------------------------------------
INT WINAPI WinMain( HINSTANCE, HINSTANCE, LPSTR, int )
{
    // Enable run-time memory check for debug builds.
#if defined(DEBUG) | defined(_DEBUG)
    _CrtSetDbgFlag( _CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF );
#endif

    // Set the callback functions
    DXUTSetCallbackDeviceCreated( OnCreateDevice );
    DXUTSetCallbackDeviceReset( OnResetDevice );
    DXUTSetCallbackDeviceLost( OnLostDevice );
    DXUTSetCallbackDeviceDestroyed( OnDestroyDevice );
    DXUTSetCallbackMsgProc( MsgProc );
    DXUTSetCallbackFrameRender( OnFrameRender );
    DXUTSetCallbackFrameMove( OnFrameMove );

    // Initialize DXUT and create the desired Win32 window and Direct3D device for the application
    DXUTInit( true, true, true ); // Parse the command line, handle the default hotkeys, and show msgboxes
    DXUTSetCursorSettings( true, true ); // Show the cursor and clip it when in full screen
    DXUTCreateWindow( L"MultiTexturing Shader" );
    DXUTCreateDevice( D3DADAPTER_DEFAULT, true, g_nWindowWidth, g_nWindowHeight, IsDeviceAcceptable, ModifyDeviceSettings );

	DXUTMainLoop();

    return DXUTGetExitCode();
}


