//--------------------------------------------------------------------------------------
//	Displacement Shader - ITB747
//
//	Author: Michael Samiec - QUT
//	Version: 1.0
//	Date: 1/3/07
//
//	This program demonstrates how to offset a polygon's vertices dynamically within a vertex
//	shader by using values within a greyscale texture. The whiter the value in the offset texture
//	the greater the offset. This program demonstrate two seperate textures and also allows the
//	user to increase and decrease the polygon count on the mesh to understand its effects on the
//	final mesh.
//
//	This program is based upon the EmptyProject template provided by Microsoft Corporation 
//	through the DirectX Sample Browser. The program is also based upon DXUT (DirectX Utility
//	Toolkit) and the related files can be found in \common. 
//
//	Copyright (c) Microsoft Corporation. All rights reserved.
//--------------------------------------------------------------------------------------
#include "dxstdafx.h"
#include <sstream>

// Added function signatures
HRESULT RenderText();
HRESULT CreatePlane();

// Global variables

LPD3DXEFFECT					g_pEffect = NULL;		// effect pointer that encapsulates the shader
LPD3DXFONT						g_pFont = NULL;			// font used for drawing text on screen
LPDIRECT3DVERTEXBUFFER9			g_pVB = NULL;			// vertex buffer used for the plane
LPDIRECT3DINDEXBUFFER9			g_pIB = NULL;			// index buffer used for plane
LPDIRECT3DVERTEXDECLARATION9	g_pVertexDec = NULL;	// vertex decleration of the square
LPDIRECT3DTEXTURE9				g_pTextureImage1 = NULL;
LPDIRECT3DTEXTURE9				g_pTextureDisp1 = NULL;
LPDIRECT3DTEXTURE9				g_pTextureImage2 = NULL;	
LPDIRECT3DTEXTURE9				g_pTextureDisp2 = NULL;

D3DXVECTOR3						g_vecCamPos	(0.0f, 0.0f, 0.0f);	// camera position
D3DXVECTOR3						g_vecCamLook(0.0f, 0.0f, 1.0f);	// camera look
D3DXVECTOR3						g_vecCamUp	(0.0f, 1.0f, 0.0f);	// camera up

D3DCOLOR						g_colourFont = D3DCOLOR_XRGB(255, 255, 255); // colour used for text rendering

D3DXHANDLE						g_handleDispFactor = NULL;	// handle to displacement multiplier
D3DXHANDLE						g_handleTextureImage = NULL;// handle to image texture
D3DXHANDLE						g_handleTextureDisp = NULL;	// handle to displacement texture
D3DXHANDLE						g_handleMatWVP = NULL;		// handle to worldviewprojection matrix 

FLOAT							g_fPlaneRotY = 0.0f;		// controls plane Y rotation
FLOAT							g_fPlaneRotX = 0.0f;		// controls plane X rotation

INT								g_nWindowWidth = 640;		// current window width
INT								g_nWindowHeight = 480;		// current window height
LPCWSTR							g_strFileName(L"Effect.fx");// effect file name

INT								g_nPlaneWidth = 8;			// no. of width vertices in the plane
INT								g_nPlaneHeight = 8;			// no. of length vertices in the plane
FLOAT							g_fDispFactor = 0.2f;

// vertex structure
struct Vertex_PosTex
{
	D3DXVECTOR3 pos;
	D3DXVECTOR3 norm;
	D3DXVECTOR2	texture;
	Vertex_PosTex(D3DXVECTOR3 a_pos, D3DXVECTOR3 a_norm, D3DXVECTOR2 a_tex) : pos(a_pos), norm(a_norm), texture(a_tex){}
	Vertex_PosTex(){}
};

//--------------------------------------------------------------------------------------
// Rejects any devices that aren't acceptable by returning false
//--------------------------------------------------------------------------------------
bool CALLBACK IsDeviceAcceptable( D3DCAPS9* pCaps, D3DFORMAT AdapterFormat, 
                                  D3DFORMAT BackBufferFormat, bool bWindowed, void* pUserContext )
{
	// check support for pixel and vertex shader versions 3.0
	if (pCaps->PixelShaderVersion < D3DPS_VERSION(3, 0) || pCaps->VertexShaderVersion < D3DVS_VERSION(3, 0))
		return false;

    return true;
}


//--------------------------------------------------------------------------------------
// Before a device is created, modify the device settings as needed
//--------------------------------------------------------------------------------------
bool CALLBACK ModifyDeviceSettings( DXUTDeviceSettings* pDeviceSettings, const D3DCAPS9* pCaps, void* pUserContext )
{
	// if device isn't HAL inform of performance issues
	if (pCaps->DeviceType != D3DDEVTYPE_HAL)
		MessageBox(NULL, L"Full hardware support not avaliable. Performance will be affected.", L"Warning", MB_OK);

    return true;
}


//--------------------------------------------------------------------------------------
// Create any D3DPOOL_MANAGED resources here 
//--------------------------------------------------------------------------------------
HRESULT CALLBACK OnCreateDevice( IDirect3DDevice9* pd3dDevice, const D3DSURFACE_DESC* pBackBufferSurfaceDesc, void* pUserContext )
{
	HRESULT hr;

	V_RETURN(CreatePlane())

	// define vertex structure
	D3DVERTEXELEMENT9 VertexArray[] = 
	{
		{0, 0, D3DDECLTYPE_FLOAT3, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_POSITION, 0},	// position
		{0, 12, D3DDECLTYPE_FLOAT3, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_NORMAL, 0},		// normal
		{0, 24, D3DDECLTYPE_FLOAT2, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_TEXCOORD, 0},	// texture coords
		D3DDECL_END()
	};

	V_RETURN(pd3dDevice->CreateVertexDeclaration(VertexArray, &g_pVertexDec))

	// create image textures
	V_RETURN(D3DXCreateTextureFromFile(pd3dDevice, L"displacement1.jpg", &g_pTextureImage1))
	V_RETURN(D3DXCreateTextureFromFile(pd3dDevice, L"displacement2.jpg", &g_pTextureImage2))

	// create displacement textures - need to load texture to floating point surface to allow vertex shader access to it
	V_RETURN(D3DXCreateTextureFromFileEx(pd3dDevice, L"displacement1.jpg", D3DX_DEFAULT, D3DX_DEFAULT, D3DX_DEFAULT, 0, D3DFMT_R32F, D3DPOOL_DEFAULT, D3DX_DEFAULT, D3DX_DEFAULT, 0, 0, 0, &g_pTextureDisp1))
	V_RETURN(D3DXCreateTextureFromFileEx(pd3dDevice, L"displacement2.jpg", D3DX_DEFAULT, D3DX_DEFAULT, D3DX_DEFAULT, 0, D3DFMT_R32F, D3DPOOL_DEFAULT, D3DX_DEFAULT, D3DX_DEFAULT, 0, 0, 0, &g_pTextureDisp2))
	return S_OK;
}

//--------------------------------------------------------------------------------------
// Create plane vertex and index buffers
//--------------------------------------------------------------------------------------
HRESULT CreatePlane()
{
	// release buffers if they exist
	SAFE_RELEASE(g_pVB);
	SAFE_RELEASE(g_pIB);

	HRESULT hr;

	LPDIRECT3DDEVICE9 pd3dDevice = DXUTGetD3DDevice();

	float xOffset = 0.0f;
	float yOffset = 0.0f;

	// define vertex array
	Vertex_PosTex* vertSquare = new Vertex_PosTex[g_nPlaneWidth * g_nPlaneHeight];

	for (int y = 0; y < g_nPlaneHeight; ++y)
	{
		for (int x = 0; x < g_nPlaneWidth; ++x)
		{
			xOffset = (float)x/(g_nPlaneWidth-1) * 1.0f - 0.5f;
			yOffset = (float)y/(g_nPlaneHeight-1) * 1.0f - 0.5f;
			vertSquare[g_nPlaneWidth*y + x] = Vertex_PosTex(D3DXVECTOR3(xOffset, yOffset, 0.0f), 
															D3DXVECTOR3(0.0f, 0.0f, -1.0f),
															D3DXVECTOR2(xOffset + 0.5f, 0.5f - yOffset));
		}
	}

	// define index array
	WORD nNumIndicies = 6 * (g_nPlaneWidth - 1) * (g_nPlaneHeight - 1);
	WORD* indexSquare = new WORD[nNumIndicies];

	for (int z = 0; z < nNumIndicies/6; ++z)
	{
		int nWidth = z % (g_nPlaneWidth - 1);
		int nHeight = z / (g_nPlaneWidth - 1);

		// layout of vertices for each square
		//
		//	1***2
		//	*	*
		//	*	*
		//	0***3

		indexSquare[z*6 + 0] = nWidth + (nHeight * g_nPlaneWidth);				// 0
		indexSquare[z*6 + 1] = nWidth + ((nHeight + 1) * g_nPlaneWidth);		// 1
		indexSquare[z*6 + 2] = nWidth + ((nHeight + 1) * g_nPlaneWidth) + 1;	// 2
		indexSquare[z*6 + 3] = nWidth + (nHeight * g_nPlaneWidth);				// 0
		indexSquare[z*6 + 4] = nWidth + ((nHeight + 1) * g_nPlaneWidth) + 1;	// 2
		indexSquare[z*6 + 5] = nWidth + (nHeight * g_nPlaneWidth) + 1;			// 3
	}

	// create vertex buffer used to hold triangle vertices
	V_RETURN(pd3dDevice->CreateVertexBuffer(sizeof(Vertex_PosTex) * g_nPlaneWidth * g_nPlaneHeight, D3DUSAGE_WRITEONLY, 0, D3DPOOL_MANAGED, &g_pVB, 0))
	void* pMem = NULL;
	V_RETURN(g_pVB->Lock(0, 0, &pMem, 0))
	memcpy(pMem, vertSquare, sizeof(Vertex_PosTex) * g_nPlaneWidth * g_nPlaneHeight);
	V_RETURN(g_pVB->Unlock())

	// create index buffer
	V_RETURN(pd3dDevice->CreateIndexBuffer(sizeof(WORD) * nNumIndicies, D3DUSAGE_WRITEONLY, D3DFMT_INDEX16, D3DPOOL_MANAGED, &g_pIB, 0)) 
	pMem = NULL;
	V_RETURN(g_pIB->Lock(0, 0, &pMem, 0))
	memcpy(pMem, indexSquare, sizeof(WORD) * nNumIndicies);
	V_RETURN(g_pIB->Unlock())

	// clean up memory
	delete[] vertSquare;
	delete[] indexSquare;

	return S_OK;
}


//--------------------------------------------------------------------------------------
// Create any D3DPOOL_DEFAULT resources here 
//--------------------------------------------------------------------------------------
HRESULT CALLBACK OnResetDevice( IDirect3DDevice9* pd3dDevice, 
                                const D3DSURFACE_DESC* pBackBufferSurfaceDesc, void* pUserContext )
{
	HRESULT hr;

	// calculate and set projection matrix
	D3DXMATRIX matProj;
	D3DXMatrixPerspectiveFovLH(&matProj, D3DX_PI * 0.5f, 4.0f/3.0f, 0.1f, 10.0f);
	V_RETURN(pd3dDevice->SetTransform(D3DTS_PROJECTION, &matProj))

	// calculate and set view matrix
	D3DXMATRIX matCamera;
	D3DXMatrixLookAtLH(&matCamera,	&g_vecCamPos,
									&g_vecCamLook,
									&g_vecCamUp);
	V_RETURN(pd3dDevice->SetTransform(D3DTS_VIEW, &matCamera))

	// create effect
	LPD3DXBUFFER pBuffer = NULL;
	if (FAILED(D3DXCreateEffectFromFile(pd3dDevice, g_strFileName, 0, 0, D3DXSHADER_DEBUG,
										0, &g_pEffect, &pBuffer)))
	{
		// if creation fails, and debug information has been returned, output debug info
		if (pBuffer)
		{
			OutputDebugStringA((char*)pBuffer->GetBufferPointer());
			SAFE_RELEASE(pBuffer);
		}

		MessageBox(0, L"D3DXCreateEffectFromFile() - FAILED", L"ERROR", 0);
		return E_FAIL;
	}

	// set technique used in effect
	V_RETURN(g_pEffect->SetTechnique("DisplacementTech"))

	// obtain handles to variables within effect
	g_handleMatWVP = g_pEffect->GetParameterByName(0, "g_matWorldViewProjection");
	g_handleTextureImage = g_pEffect->GetParameterByName(0, "g_textureImage");
	g_handleTextureDisp = g_pEffect->GetParameterByName(0, "g_textureDisp");
	g_handleDispFactor = g_pEffect->GetParameterByName(0, "g_fDispFactor");

	// set some initial values
	V_RETURN(g_pEffect->SetFloat(g_handleDispFactor, g_fDispFactor))
	V_RETURN(g_pEffect->SetTexture(g_handleTextureImage, g_pTextureImage1))
	V_RETURN(g_pEffect->SetTexture(g_handleTextureDisp, g_pTextureDisp1))


	// create font used for rendering text
	V_RETURN(D3DXCreateFont(pd3dDevice, 16, 0, FW_BOLD, 0, false, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS,
							DEFAULT_QUALITY, DEFAULT_PITCH | FF_DONTCARE, L"Arial", &g_pFont))

    return S_OK;
}


//--------------------------------------------------------------------------------------
// Handle updates to the scene
//--------------------------------------------------------------------------------------
void CALLBACK OnFrameMove( IDirect3DDevice9* pd3dDevice, double fTime, float fElapsedTime, void* pUserContext )
{
}

//--------------------------------------------------------------------------------------
// Renders all text required by scene
// NB: Must be called between LPDIRECT3DDEVICE9::BeginScene and LPDIRECT3DDEVICE9::EndScene
//--------------------------------------------------------------------------------------

HRESULT RenderText()
{
	HRESULT hr;
	RECT rectPos; // used to position text on screen coordinates
	
	// text rendered to screen
	LPCWSTR textInfo1(L"Press F1 to switch between wireframe and solid mode\nPress F2 to switch between textures\nPress F4/F5 to decrease/increase displacement factor\nPress F6/F7 to decrease/increase polygon count\nLMB controls plane rotation");
	std::stringstream ss;

	// calculate polygons
	ss << "Polygon count: ";
	ss << (g_nPlaneWidth - 1) * (g_nPlaneHeight - 1) * 2;
	
	// define rectangle extremities
	rectPos.top = 10; 
	rectPos.left = 10;
	rectPos.bottom = g_nWindowHeight - 10;
	rectPos.right = g_nWindowWidth - 10;

	// draw text
	V_RETURN(g_pFont->DrawText(0, textInfo1, -1, &rectPos, DT_LEFT | DT_BOTTOM | DT_NOCLIP, g_colourFont))
	V_RETURN(g_pFont->DrawTextA(0, ss.str().c_str(), -1, &rectPos, DT_LEFT | DT_TOP | DT_NOCLIP, g_colourFont))

	return S_OK;
}


//--------------------------------------------------------------------------------------
// Render the scene 
//--------------------------------------------------------------------------------------
void CALLBACK OnFrameRender( IDirect3DDevice9* pd3dDevice, double fTime, float fElapsedTime, void* pUserContext )
{
	HRESULT hr;

	D3DXMATRIX matView, matProj, matWorld;
	D3DXMATRIX matWorldViewProj, matRotY, matRotX, matRot, matTrans;

    // Clear the render target and the zbuffer 
	V(pd3dDevice->Clear(0, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER, D3DCOLOR_ARGB(0, 45, 50, 170), 1.0f, 0))

	// get matrices
	V(pd3dDevice->GetTransform(D3DTS_VIEW, &matView))
	V(pd3dDevice->GetTransform(D3DTS_PROJECTION, &matProj))
	V(pd3dDevice->GetTransform(D3DTS_WORLD, &matWorld))

	// calculate plane world matrix
	D3DXMatrixRotationY(&matRotY, g_fPlaneRotY);
	D3DXMatrixRotationX(&matRotX, g_fPlaneRotX);
	D3DXMatrixMultiply(&matRot, &matRotX, &matRotY);
	D3DXMatrixTranslation(&matTrans, 0.0f, 0.0f, 1.0f);
	D3DXMatrixMultiply(&matRot, &matRot, &matTrans);
	D3DXMatrixMultiply(&matWorld, &matRot, &matWorld);

	// calculate world-view-projection matrix
	D3DXMatrixMultiply(&matWorldViewProj, &matWorld, &matView);
	D3DXMatrixMultiply(&matWorldViewProj, &matWorldViewProj, &matProj);

	// get handle to worldviewprojection matrix in effect and set matrix
	V(g_pEffect->SetMatrix(g_handleMatWVP, &matWorldViewProj))

	// set up triangle to be rendered 
	V(pd3dDevice->SetStreamSource(0, g_pVB, 0, sizeof(Vertex_PosTex)))
	V(pd3dDevice->SetIndices(g_pIB))
	V(pd3dDevice->SetVertexDeclaration(g_pVertexDec))

	// begin drawing
	V(pd3dDevice->BeginScene())

	V(RenderText())

	UINT unPasses;	// stores number of passes required for selected technique
	V(g_pEffect->Begin(&unPasses, 0))

	// iterate through each pass
	for(UINT unPass = 0; unPass < unPasses; ++unPass)
	{
		V(g_pEffect->BeginPass(unPass))
		
		// render plane
		V(pd3dDevice->DrawIndexedPrimitive(D3DPT_TRIANGLELIST, 0, 0, (g_nPlaneWidth) * (g_nPlaneHeight), 0, ((g_nPlaneWidth - 1) * (g_nPlaneHeight - 1) * 2)))

		V(g_pEffect->EndPass())
	}

	V(g_pEffect->End())

	// end drawing
	V(pd3dDevice->EndScene())
}


//--------------------------------------------------------------------------------------
// Handle messages to the application 
//--------------------------------------------------------------------------------------
LRESULT CALLBACK MsgProc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam, 
                          bool* pbNoFurtherProcessing, void* pUserContext )
{
	HRESULT hr;
	static bool bRotatePlane = false;
	static INT	nLastXPos = 0;
	static INT	nLastYPos = 0;
	static BOOL bFirstTexture = false;

	switch(uMsg)
	{
		case WM_KEYUP:
		{
			switch(wParam)
			{
			case VK_F1:
				// switch between wireframe and solid rendering modes
				DWORD currState;
				DXUTGetD3DDevice()->GetRenderState(D3DRS_FILLMODE, &currState);

				if (currState != D3DFILL_WIREFRAME)
					DXUTGetD3DDevice()->SetRenderState(D3DRS_FILLMODE, D3DFILL_WIREFRAME);
				else
					DXUTGetD3DDevice()->SetRenderState(D3DRS_FILLMODE, D3DFILL_SOLID);
				break;

			case VK_F2:
				// switch between textures
				if (bFirstTexture)
				{
					V(g_pEffect->SetTexture(g_handleTextureImage, g_pTextureImage1))
					V(g_pEffect->SetTexture(g_handleTextureDisp, g_pTextureDisp1))
				}
				else
				{
					V(g_pEffect->SetTexture(g_handleTextureImage, g_pTextureImage2))
					V(g_pEffect->SetTexture(g_handleTextureDisp, g_pTextureDisp2))
				}

				bFirstTexture = !bFirstTexture;

				break;

			case VK_F4:
				// decrease vertex displacement factor
				if (g_fDispFactor > -1.0f)
					g_fDispFactor -= 0.1f;

				V(g_pEffect->SetFloat(g_handleDispFactor, g_fDispFactor))
				break;

			case VK_F5:
				// increase vertex displacement factor
				if (g_fDispFactor < 0.5f)
					g_fDispFactor += 0.1f;

				V(g_pEffect->SetFloat(g_handleDispFactor, g_fDispFactor))
				break;

			case VK_F6:
				// decrease plane vertices
				if (g_nPlaneWidth > 2 && g_nPlaneHeight > 2)
				{
					g_nPlaneWidth--;
					g_nPlaneHeight--;
				}
				
				CreatePlane();
				break;

			case VK_F7:
				// increase plane vertices
				g_nPlaneWidth++;
				g_nPlaneHeight++;
				
				CreatePlane();
				break;
			}
			break;
		}
		// store current window width and height
		case WM_SIZE:
			g_nWindowWidth = LOWORD(lParam);
			g_nWindowHeight = HIWORD(lParam);
			break;

		case WM_MOUSEMOVE:
		{
			// if left mouse button is down
			if (bRotatePlane)
			{
				// calculate plane rotation
				INT nCurrXPos = LOWORD(lParam);
				INT nDiff = nCurrXPos - nLastXPos; 
				g_fPlaneRotY -= (FLOAT)nDiff / 200.0f;
				nLastXPos = nCurrXPos;

				INT nCurrYPos = HIWORD(lParam);
				nDiff = nCurrYPos - nLastYPos;
				g_fPlaneRotX -= (FLOAT)nDiff / 200.0f;
				nLastYPos = nCurrYPos;


				// don't let plane rotate past 90 degree mark on either axis
				if (g_fPlaneRotX < -D3DX_PI / 2)
					g_fPlaneRotX = -D3DX_PI / 2;
				else if (g_fPlaneRotX > D3DX_PI / 2)
					g_fPlaneRotX = D3DX_PI / 2;

				if (g_fPlaneRotY < -D3DX_PI / 2)
					g_fPlaneRotY = -D3DX_PI / 2;
				else if (g_fPlaneRotY > D3DX_PI / 2)
					g_fPlaneRotY = D3DX_PI / 2;
			}
			break;
		}

		case WM_LBUTTONDOWN:
		{
			bRotatePlane = true;
			nLastXPos = LOWORD(lParam);
			nLastYPos = HIWORD(lParam);
			break;
		}

		case WM_LBUTTONUP:
		{
			bRotatePlane = false;
			break;
		}
	}
	return 0;
}


//--------------------------------------------------------------------------------------
// Release resources created in the OnResetDevice callback here 
//--------------------------------------------------------------------------------------
void CALLBACK OnLostDevice( void* pUserContext )
{
	SAFE_RELEASE(g_pFont);
	SAFE_RELEASE(g_pEffect);
}


//--------------------------------------------------------------------------------------
// Release resources created in the OnCreateDevice callback here
//--------------------------------------------------------------------------------------
void CALLBACK OnDestroyDevice( void* pUserContext )
{
	SAFE_RELEASE(g_pTextureImage1);
	SAFE_RELEASE(g_pTextureDisp1);
	SAFE_RELEASE(g_pTextureImage2);
	SAFE_RELEASE(g_pTextureDisp2);
	SAFE_RELEASE(g_pVertexDec);
	SAFE_RELEASE(g_pVB);
	SAFE_RELEASE(g_pIB);
}



//--------------------------------------------------------------------------------------
// Initialize everything and go into a render loop
//--------------------------------------------------------------------------------------
INT WINAPI WinMain( HINSTANCE, HINSTANCE, LPSTR, int )
{
    // Enable run-time memory check for debug builds.
#if defined(DEBUG) | defined(_DEBUG)
    _CrtSetDbgFlag( _CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF );
#endif

    // Set the callback functions
    DXUTSetCallbackDeviceCreated( OnCreateDevice );
    DXUTSetCallbackDeviceReset( OnResetDevice );
    DXUTSetCallbackDeviceLost( OnLostDevice );
    DXUTSetCallbackDeviceDestroyed( OnDestroyDevice );
    DXUTSetCallbackMsgProc( MsgProc );
    DXUTSetCallbackFrameRender( OnFrameRender );
    DXUTSetCallbackFrameMove( OnFrameMove );

    // Initialize DXUT and create the desired Win32 window and Direct3D device for the application
    DXUTInit( true, true, true ); // Parse the command line, handle the default hotkeys, and show msgboxes
    DXUTSetCursorSettings( true, true ); // Show the cursor and clip it when in full screen
    DXUTCreateWindow( L"Displacement Shader" );
    DXUTCreateDevice( D3DADAPTER_DEFAULT, true, g_nWindowWidth, g_nWindowHeight, IsDeviceAcceptable, ModifyDeviceSettings );

	DXUTMainLoop();

    return DXUTGetExitCode();
}