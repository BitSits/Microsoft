//--------------------------------------------------------------------------------------
//	Billboarding Shader - ITB747
//
//	Author: Michael Samiec - QUT
//	Version: 1.0
//	Date: 5/5/07
//
//	This program demonstrates 'false spherical billboarding' technique. In it 2d planes are
//	oriented to face a plane perpendicular to the camera's viewing direction. The orientation
//	of the plane is done in the vertex shader by adjusting the vertex position using the view
//	matrix.
//
//	This program is based upon the EmptyProject template provided by Microsoft Corporation 
//	through the DirectX Sample Browser. The program is also based upon DXUT (DirectX Utility
//	Toolkit) and the related files can be found in \common. 
//
//	Copyright (c) Microsoft Corporation. All rights reserved.
//--------------------------------------------------------------------------------------
#include "dxstdafx.h"

// Added function signatures
void	RetrieveInput(double dTimeDiff);
HRESULT RenderText();

// Global variables

LPD3DXEFFECT					g_pEffect = NULL;		// effect pointer that encapsulates the shader
LPD3DXFONT						g_pFont = NULL;			// font used for drawing text on screen
LPDIRECT3DVERTEXBUFFER9			g_pVB = NULL;			// vertex buffer used for the square
LPDIRECT3DVERTEXDECLARATION9	g_pVertexDec = NULL;	// vertex decleration of the square
LPDIRECT3DTEXTURE9				g_pTextures[3];			// texture used for animation

D3DXVECTOR3						g_vecCamPos	(0.0f, 0.0f, 0.0f);	// camera position
D3DXVECTOR3						g_vecCamLook(0.0f, 0.0f, 1.0f);	// camera look
D3DXVECTOR3						g_vecCamUp	(0.0f, 1.0f, 0.0f);	// camera up

D3DCOLOR						g_colourFont = D3DCOLOR_XRGB(255, 255, 255); // colour used for text rendering

D3DXHANDLE						g_handleMatView = NULL;			// handle to view matrix
D3DXHANDLE						g_handleMatWVP = NULL;			// handle to worldviewprojection matrix
D3DXHANDLE						g_handleTexture = NULL;			// handle to texture

INT								g_nWindowWidth = 640;			// current window width
INT								g_nWindowHeight = 480;			// current window height
LPCWSTR							g_strFileName(L"Effect.fx");	// effect file name

const INT						BILLBOARDRANGEX = 9;			// width of billboarding samples
const INT						BILLBOARDRANGEY = 9;			// depth of billboarding samples	
const FLOAT						BILLBOARDSPACING = 7.0f;		// spacing between billboards


// vertex structure
struct Vertex_PosTex
{
	D3DXVECTOR3 pos;
	D3DXVECTOR2	texture;
};

// definition of square vertices
Vertex_PosTex vertSquare[] = 
{
	{D3DXVECTOR3(-1.0f,-1.0f, 0.0f), D3DXVECTOR2(0.0f, 1.0f)},
	{D3DXVECTOR3(-1.0f, 1.0f, 0.0f), D3DXVECTOR2(0.0f, 0.0f)},
	{D3DXVECTOR3( 1.0f,-1.0f, 0.0f), D3DXVECTOR2(1.0f, 1.0f)},
	{D3DXVECTOR3( 1.0f, 1.0f, 0.0f), D3DXVECTOR2(1.0f, 0.0f)},
};

//--------------------------------------------------------------------------------------
// Rejects any devices that aren't acceptable by returning false
//--------------------------------------------------------------------------------------
bool CALLBACK IsDeviceAcceptable( D3DCAPS9* pCaps, D3DFORMAT AdapterFormat, 
                                  D3DFORMAT BackBufferFormat, bool bWindowed, void* pUserContext )
{
	// check support for pixel and vertex shader versions 2.0
	if (pCaps->PixelShaderVersion < D3DPS_VERSION(2, 0) || pCaps->VertexShaderVersion < D3DVS_VERSION(2, 0))
		return false;

    return true;
}


//--------------------------------------------------------------------------------------
// Before a device is created, modify the device settings as needed
//--------------------------------------------------------------------------------------
bool CALLBACK ModifyDeviceSettings( DXUTDeviceSettings* pDeviceSettings, const D3DCAPS9* pCaps, void* pUserContext )
{
	// if device isn't HAL inform of performance issues
	if (pCaps->DeviceType != D3DDEVTYPE_HAL)
		MessageBox(NULL, L"Full hardware support not avaliable. Performance will be affected.", L"Warning", MB_OK);

    return true;
}


//--------------------------------------------------------------------------------------
// Create any D3DPOOL_MANAGED resources here 
//--------------------------------------------------------------------------------------
HRESULT CALLBACK OnCreateDevice( IDirect3DDevice9* pd3dDevice, const D3DSURFACE_DESC* pBackBufferSurfaceDesc, void* pUserContext )
{
	HRESULT hr;
	// create vertex buffer used to hold triangle vertices
	V_RETURN(pd3dDevice->CreateVertexBuffer(sizeof(vertSquare), D3DUSAGE_WRITEONLY, 0, D3DPOOL_MANAGED, &g_pVB, 0))
	
	// lock memory, copy data in, unlock memory
	void* pMem = NULL;
	V_RETURN(g_pVB->Lock(0, 0, &pMem, 0))
	memcpy(pMem, vertSquare, sizeof(vertSquare));
	V_RETURN(g_pVB->Unlock())

	// define vertex structure
	D3DVERTEXELEMENT9 VertexArray[] = 
	{
		{0, 0, D3DDECLTYPE_FLOAT3, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_POSITION, 0},	// position
		{0, 12, D3DDECLTYPE_FLOAT2, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_TEXCOORD, 0},	// texture coords
		D3DDECL_END()
	};

	V_RETURN(pd3dDevice->CreateVertexDeclaration(VertexArray, &g_pVertexDec))

	// load up each texture marking each's alpha colour
	D3DXCreateTextureFromFileEx(pd3dDevice, L"tree.png", 512, 512, 0, 0,
								D3DFMT_UNKNOWN, D3DPOOL_MANAGED, D3DX_DEFAULT,
								D3DX_DEFAULT, 0x00FFFFFF, NULL, NULL, &g_pTextures[0]);

	D3DXCreateTextureFromFileEx(pd3dDevice, L"explosion.jpg", 512, 512, 0, 0,
								D3DFMT_UNKNOWN, D3DPOOL_MANAGED, D3DX_DEFAULT,
								D3DX_DEFAULT, 0xFF000000, NULL, NULL, &g_pTextures[1]);

	D3DXCreateTextureFromFileEx(pd3dDevice, L"vegas.jpg", 512, 512, 0, 0,
								D3DFMT_UNKNOWN, D3DPOOL_MANAGED, D3DX_DEFAULT,
								D3DX_DEFAULT, 0xFF000000, NULL, NULL, &g_pTextures[2]);

    return S_OK;
}


//--------------------------------------------------------------------------------------
// Create any D3DPOOL_DEFAULT resources here 
//--------------------------------------------------------------------------------------
HRESULT CALLBACK OnResetDevice( IDirect3DDevice9* pd3dDevice, 
                                const D3DSURFACE_DESC* pBackBufferSurfaceDesc, void* pUserContext )
{
	HRESULT hr;

	// calculate and set projection matrix
	D3DXMATRIX matProj;
	D3DXMatrixPerspectiveFovLH(&matProj, D3DX_PI * 0.5f, 4.0f/3.0f, 1.0f, 1000.0f);
	V_RETURN(pd3dDevice->SetTransform(D3DTS_PROJECTION, &matProj))

	// calculate and set world matrix
	D3DXMATRIX matTrans, matScale, matWorld;
	D3DXMatrixTranslation(&matTrans, 0.0f, 0.0f, 2.0f);
	D3DXMatrixScaling(&matScale, 1.5f, 1.5f, 1.0f);
	D3DXMatrixMultiply(&matWorld, &matScale, &matTrans);
	V_RETURN(pd3dDevice->SetTransform(D3DTS_WORLD, &matWorld))

	// create effect
	LPD3DXBUFFER pBuffer = NULL;
	if (FAILED(D3DXCreateEffectFromFile(pd3dDevice, g_strFileName, 0, 0, D3DXSHADER_DEBUG,
										0, &g_pEffect, &pBuffer)))
	{
		// if creation fails, and debug information has been returned, output debug info
		if (pBuffer)
		{
			OutputDebugStringA((char*)pBuffer->GetBufferPointer());
			SAFE_RELEASE(pBuffer);
		}

		MessageBox(0, L"D3DXCreateEffectFromFile() - FAILED", L"ERROR", 0);
		return E_FAIL;
	}

	// set technique and texture used in effect
	V_RETURN(g_pEffect->SetTechnique("BillboardingTech"))

	// obtain handles to variables within effect
	g_handleMatView = g_pEffect->GetParameterByName(0, "g_matView");
	g_handleMatWVP = g_pEffect->GetParameterByName(0, "g_matWorldViewProjection");
	g_handleTexture = g_pEffect->GetParameterByName(0, "g_texture");

	// create font used for rendering text
	V_RETURN(D3DXCreateFont(pd3dDevice, 16, 0, FW_BOLD, 0, false, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS,
							DEFAULT_QUALITY, DEFAULT_PITCH | FF_DONTCARE, L"Arial", &g_pFont))

    return S_OK;
}


//--------------------------------------------------------------------------------------
// Retrieve's keyboard input and updates the camera (view matrix) accordingly
//--------------------------------------------------------------------------------------
void RetrieveInput(double dTimeDiff)
{
	unsigned char cKeyStatus[256];
	static double g_dCameraLookAdjust = 0.0;
	LPDIRECT3DDEVICE9 pd3dDevice = DXUTGetD3DDevice();

	if (pd3dDevice == NULL)
		return;

	// get each key's status
	if(!GetKeyboardState(cKeyStatus))
		return;

	// evaluate movement directions
	D3DXVECTOR3 vFacing = g_vecCamLook - g_vecCamPos;
	D3DXVec3Normalize(&vFacing, &vFacing);
	vFacing *= dTimeDiff * 5;

	D3DXVECTOR3 vStrafe;
	D3DXVec3Cross(&vStrafe, &vFacing, &g_vecCamUp);
	D3DXVec3Normalize(&vStrafe, &vStrafe);
	vStrafe *= dTimeDiff * 5;

	double dTwist = dTimeDiff * 5;

	// move forward
	if (cKeyStatus[VK_UP]& 0x80 || cKeyStatus[VK_NUMPAD8]& 0x80)
	{
		g_vecCamPos += vFacing;
		g_vecCamLook += vFacing;
	}

	// move backward
	if (cKeyStatus[VK_DOWN]& 0x80 || cKeyStatus[VK_NUMPAD2]& 0x80 || cKeyStatus[VK_NUMPAD5]& 0x80)
	{
		g_vecCamPos -= vFacing;
		g_vecCamLook -= vFacing;
	}

	// strafe left
	if (cKeyStatus[VK_NUMPAD7]& 0x80)
	{
		g_vecCamPos += vStrafe;
		g_vecCamLook += vStrafe;		
	}

	// strafe right
	if (cKeyStatus[VK_NUMPAD9]& 0x80)
	{
		g_vecCamPos -= vStrafe;
		g_vecCamLook -= vStrafe;		
	}

	// turn right
	if (cKeyStatus[VK_RIGHT]& 0x80 || cKeyStatus[VK_NUMPAD6]& 0x80)
		g_dCameraLookAdjust += dTwist;

	// turn left
	if (cKeyStatus[VK_LEFT]& 0x80 || cKeyStatus[VK_NUMPAD4]& 0x80)
		g_dCameraLookAdjust -= dTwist;

	g_vecCamLook = g_vecCamPos + 
					D3DXVECTOR3(sin(g_dCameraLookAdjust), 0.0f, cos(g_dCameraLookAdjust));

	D3DXMATRIX matView;
	D3DXMatrixLookAtLH(&matView,	&g_vecCamPos, //Camera Position
									&g_vecCamLook, //Look At Position
									&g_vecCamUp); //Up Direction
	pd3dDevice->SetTransform(D3DTS_VIEW, &matView);
}


//--------------------------------------------------------------------------------------
// Handle updates to the scene
//--------------------------------------------------------------------------------------
void CALLBACK OnFrameMove( IDirect3DDevice9* pd3dDevice, double dTime, float fElapsedTime, void* pUserContext )
{
	// retrieve keyboard input
	RetrieveInput(fElapsedTime);
}

//--------------------------------------------------------------------------------------
// Renders all text required by scene
// NB: Must be called between LPDIRECT3DDEVICE9::BeginScene and LPDIRECT3DDEVICE9::EndScene
//--------------------------------------------------------------------------------------

HRESULT RenderText()
{
	HRESULT hr;
	RECT rectPos; // used to position text on screen coordinates
	
	// text rendered to screen
	LPCWSTR textInfo1(L"Use numpad to control camera");


	// define rectangle extremities
	rectPos.top = 10; 
	rectPos.left = 10;
	rectPos.bottom = g_nWindowHeight - 10;
	rectPos.right = g_nWindowWidth - 10;

	// draw text
	V_RETURN(g_pFont->DrawText(0, textInfo1, -1, &rectPos, DT_LEFT | DT_BOTTOM | DT_NOCLIP, g_colourFont))

	return S_OK;
}


//--------------------------------------------------------------------------------------
// Render the scene 
//--------------------------------------------------------------------------------------
void CALLBACK OnFrameRender( IDirect3DDevice9* pd3dDevice, double fTime, float fElapsedTime, void* pUserContext )
{
	HRESULT hr;

	D3DXMATRIX matView, matProj, matWorld;
	D3DXMATRIX matWorldViewProj, matTrans;

    // Clear the render target and the zbuffer 
	V(pd3dDevice->Clear(0, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER, D3DCOLOR_ARGB(0, 0, 0, 0), 1.0f, 0))

	// get matrices
	V(pd3dDevice->GetTransform(D3DTS_VIEW, &matView))
	V(pd3dDevice->GetTransform(D3DTS_PROJECTION, &matProj))
	V(pd3dDevice->GetTransform(D3DTS_WORLD, &matWorld))

	// set view matrix in effect
	V(g_pEffect->SetMatrix(g_handleMatView, &matView))

	// set up triangle to be rendered 
	V(pd3dDevice->SetVertexDeclaration(g_pVertexDec))
	V(pd3dDevice->SetStreamSource(0, g_pVB, 0, sizeof(Vertex_PosTex)))

	// begin drawing
	V(pd3dDevice->BeginScene())

	UINT unPasses;	// stores number of passes required for selected technique
	V(g_pEffect->Begin(&unPasses, 0))

	// iterate through each pass
	for(UINT unPass = 0; unPass < unPasses; ++unPass)
	{
		V(g_pEffect->BeginPass(unPass))

		for (int i = 0; i < BILLBOARDRANGEX; ++i)	// width
		{
			for (int j = 0; j < BILLBOARDRANGEY; ++j)	// depth
			{
				D3DXMatrixTranslation(&matTrans, i * BILLBOARDSPACING, 0.0f, j * BILLBOARDSPACING);

				// calculate world-view-projection matrix
				D3DXMatrixMultiply(&matWorldViewProj, &matWorld, &matTrans);
				D3DXMatrixMultiply(&matWorldViewProj, &matWorldViewProj, &matView);
				D3DXMatrixMultiply(&matWorldViewProj, &matWorldViewProj, &matProj);

				// get handle to worldviewprojection matrix in effect and set matrix
				V(g_pEffect->SetMatrix(g_handleMatWVP, &matWorldViewProj))

				// set texture
				V(g_pEffect->SetTexture(g_handleTexture, g_pTextures[i%3]))

				V(g_pEffect->CommitChanges())

				// render triangle
				V(pd3dDevice->DrawPrimitive(D3DPT_TRIANGLESTRIP, 0, 2))
			}
		}
		V(g_pEffect->EndPass())
	}

	V(g_pEffect->End())

	V(RenderText())

	// end drawing
	V(pd3dDevice->EndScene())
}


//--------------------------------------------------------------------------------------
// Handle messages to the application 
//--------------------------------------------------------------------------------------
LRESULT CALLBACK MsgProc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam, 
                          bool* pbNoFurtherProcessing, void* pUserContext )
{
	switch(uMsg)
	{
		// store current window width and height
		case WM_SIZE:
			g_nWindowWidth = LOWORD(lParam);
			g_nWindowHeight = HIWORD(lParam);
			break;
	}
	return 0;
}


//--------------------------------------------------------------------------------------
// Release resources created in the OnResetDevice callback here 
//--------------------------------------------------------------------------------------
void CALLBACK OnLostDevice( void* pUserContext )
{
	SAFE_RELEASE(g_pFont);
	SAFE_RELEASE(g_pEffect);
}


//--------------------------------------------------------------------------------------
// Release resources created in the OnCreateDevice callback here
//--------------------------------------------------------------------------------------
void CALLBACK OnDestroyDevice( void* pUserContext )
{
	for (int i = 0; i < 3; ++i)
		SAFE_RELEASE(g_pTextures[i]);

	SAFE_RELEASE(g_pVertexDec);
	SAFE_RELEASE(g_pVB);
}



//--------------------------------------------------------------------------------------
// Initialize everything and go into a render loop
//--------------------------------------------------------------------------------------
INT WINAPI WinMain( HINSTANCE, HINSTANCE, LPSTR, int )
{
    // Enable run-time memory check for debug builds.
#if defined(DEBUG) | defined(_DEBUG)
    _CrtSetDbgFlag( _CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF );
#endif

    // Set the callback functions
    DXUTSetCallbackDeviceCreated( OnCreateDevice );
    DXUTSetCallbackDeviceReset( OnResetDevice );
    DXUTSetCallbackDeviceLost( OnLostDevice );
    DXUTSetCallbackDeviceDestroyed( OnDestroyDevice );
    DXUTSetCallbackMsgProc( MsgProc );
    DXUTSetCallbackFrameRender( OnFrameRender );
    DXUTSetCallbackFrameMove( OnFrameMove );

    // Initialize DXUT and create the desired Win32 window and Direct3D device for the application
    DXUTInit( true, true, true ); // Parse the command line, handle the default hotkeys, and show msgboxes
    DXUTSetCursorSettings( true, true ); // Show the cursor and clip it when in full screen
    DXUTCreateWindow( L"Billboarding Shader" );
    DXUTCreateDevice( D3DADAPTER_DEFAULT, true, g_nWindowWidth, g_nWindowHeight, IsDeviceAcceptable, ModifyDeviceSettings );

	DXUTMainLoop();

    return DXUTGetExitCode();
}