//--------------------------------------------------------------------------------------
//	Refraction Shader - ITB747
//
//	Author: Michael Samiec - QUT
//	Version: 1.0
//	Date: 12/4/07
//
//	This program demonstrates a refraction lighting effect. The pixel shader of this demo
//	is based upon nVidia's Refractive demo in their 9.5 SDK.
//
//	The skybox02.dds texture is sourced from Microsoft's DirectX SDK.
//
//	This program is based upon the EmptyProject template provided 
//	by Microsoft through the DirectX Sample Browser.
//
//	Copyright (c) Microsoft Corporation. All rights reserved.
//--------------------------------------------------------------------------------------
#include "dxstdafx.h"

// function signatures
HRESULT	RenderText();
void	SetCamera();

// Global variables

LPD3DXEFFECT					g_pEffect = NULL;		// effect pointer that encapsulates the shader
LPD3DXFONT						g_pFont = NULL;			// font used for drawing text on screen
LPDIRECT3DCUBETEXTURE9			g_pCubeTexture = NULL;	// environment texture

// object meshes
LPD3DXMESH						g_pMeshSphere = NULL;
LPD3DXMESH						g_pMeshBox = NULL;
LPD3DXMESH						g_pMeshCylinder = NULL;
LPD3DXMESH						g_pMeshTeapot = NULL;
LPD3DXMESH						g_pMeshTorus = NULL;

// skybox mesh
LPD3DXMESH						g_pMeshSkybox = NULL;

// matrix handles
D3DXHANDLE						g_handleMatWVP = NULL;
D3DXHANDLE						g_handleMatWIT = NULL;
D3DXHANDLE						g_handleMatW = NULL;

// camera position handle
D3DXHANDLE						g_handleCamPos = NULL;

// camera variables
D3DXVECTOR3						g_vecCamPos;
D3DXVECTOR3						g_vecCamLook(0.0f, 0.0f, 0.0f);
D3DXVECTOR3						g_vecCamUp	(0.0f, 1.0f, 0.0f);

// light direction
D3DXVECTOR3						g_vecLightDir(1.0f, 1.0f, -1.0f);

// colour used for text rendering
D3DCOLOR						g_colourFont = D3DCOLOR_XRGB(0, 0, 0);

// used to rotate object and camera
FLOAT							g_fCameraOffset = 0.0f;
FLOAT							g_fObjectRotY = 0.0f;
FLOAT							g_fObjectRotX = 0.0f;

// switch used for object selection
INT								g_nObjectSelect = 0;

// controls camera's orbit distance
FLOAT							g_fCameraOrbit = 2.5f;

INT								g_nWindowWidth = 640;		// current window width
INT								g_nWindowHeight = 480;		// current window height
LPCWSTR							g_strFileName(L"Effect.fx");// effect file name

//--------------------------------------------------------------------------------------
// Rejects any devices that aren't acceptable by returning false
//--------------------------------------------------------------------------------------
bool CALLBACK IsDeviceAcceptable( D3DCAPS9* pCaps, D3DFORMAT AdapterFormat, 
                                  D3DFORMAT BackBufferFormat, bool bWindowed, void* pUserContext )
{
    // Typically want to skip backbuffer formats that don't support alpha blending
    IDirect3D9* pD3D = DXUTGetD3DObject(); 
    if( FAILED( pD3D->CheckDeviceFormat( pCaps->AdapterOrdinal, pCaps->DeviceType,
                    AdapterFormat, D3DUSAGE_QUERY_POSTPIXELSHADER_BLENDING, 
                    D3DRTYPE_TEXTURE, BackBufferFormat ) ) )
        return false;

	// check support for pixel and vertex shader versions 2.0
	if (pCaps->PixelShaderVersion < D3DPS_VERSION(2, 0) || pCaps->VertexShaderVersion < D3DVS_VERSION(2, 0))
		return false;

    return true;
}


//--------------------------------------------------------------------------------------
// Before a device is created, modify the device settings as needed
//--------------------------------------------------------------------------------------
bool CALLBACK ModifyDeviceSettings( DXUTDeviceSettings* pDeviceSettings, const D3DCAPS9* pCaps, void* pUserContext )
{
	// if device isn't HAL inform of performance issues
	if (pCaps->DeviceType != D3DDEVTYPE_HAL)
		MessageBox(NULL, L"Full hardware support not avaliable. Performance will be affected.", L"Warning", MB_OK);
    
    return true;
}


//--------------------------------------------------------------------------------------
// Create any D3DPOOL_MANAGED resources here 
//--------------------------------------------------------------------------------------
HRESULT CALLBACK OnCreateDevice( IDirect3DDevice9* pd3dDevice, const D3DSURFACE_DESC* pBackBufferSurfaceDesc, void* pUserContext )
{
	HRESULT hr;

	// create object meshes
	V_RETURN(D3DXCreateSphere(pd3dDevice, 1.0f, 20, 20, &g_pMeshSphere, NULL))
	V_RETURN(D3DXCreateBox(pd3dDevice, 1.2f, 1.2f, 1.2f, &g_pMeshBox, NULL))
	V_RETURN(D3DXCreateCylinder(pd3dDevice, 0.0f, 0.5f, 2.0f, 25, 25, &g_pMeshCylinder, NULL))
	V_RETURN(D3DXCreateTeapot(pd3dDevice, &g_pMeshTeapot, NULL))
	V_RETURN(D3DXCreateTorus(pd3dDevice, 0.6f, 1.0f, 15, 25, &g_pMeshTorus, NULL))

	// create skybox
	V_RETURN(D3DXCreateBox(pd3dDevice, 10.0f, 10.0f, 10.0f, &g_pMeshSkybox, NULL))

	// create environment map texture
	V_RETURN(D3DXCreateCubeTextureFromFile(pd3dDevice, L"skybox02.dds", &g_pCubeTexture))

    return S_OK;
}


//--------------------------------------------------------------------------------------
// Create any D3DPOOL_DEFAULT resources here 
//--------------------------------------------------------------------------------------
HRESULT CALLBACK OnResetDevice( IDirect3DDevice9* pd3dDevice, 
                                const D3DSURFACE_DESC* pBackBufferSurfaceDesc, void* pUserContext )
{
	HRESULT hr;
	D3DXMATRIX matProj, matCamera;

	// create effect
	ID3DXBuffer* pBuffer = NULL;
	if (FAILED(D3DXCreateEffectFromFile(pd3dDevice, g_strFileName, 0, 0, D3DXSHADER_DEBUG,
										0, &g_pEffect, &pBuffer)))
	{
		// if creation fails, and debug information has been returned, output debug info
		if (pBuffer)
		{
			OutputDebugStringA((char*)pBuffer->GetBufferPointer());
			SAFE_RELEASE(pBuffer);
		}

		MessageBox(0, L"D3DXCreateEffectFromFile() - FAILED", L"ERROR", 0);
		return E_FAIL;
	}

	// get handles
	g_handleMatWVP = g_pEffect->GetParameterByName(0, "g_matWVP");
	g_handleMatWIT = g_pEffect->GetParameterByName(0, "g_matWIT");
	g_handleMatW = g_pEffect->GetParameterByName(0, "g_matW");
	g_handleCamPos = g_pEffect->GetParameterByName(0, "g_vecCameraPos");

	// set variables within effect that only need to be set once
	V(g_pEffect->SetTexture("g_cubeTexture", g_pCubeTexture))

	// calculate and set projection matrix
	D3DXMatrixPerspectiveFovLH(&matProj, D3DX_PI * 0.5f, 4.0f/3.0f, 0.5f, 100.0f);
	V_RETURN(pd3dDevice->SetTransform(D3DTS_PROJECTION, &matProj))

	// update view matrix
	SetCamera();

	// create font used for rendering text
	V_RETURN(D3DXCreateFont(pd3dDevice, 16, 0, FW_BOLD, 0, false, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS,
							DEFAULT_QUALITY, DEFAULT_PITCH | FF_DONTCARE, L"Arial", &g_pFont))

    return S_OK;
}

//--------------------------------------------------------------------------------------
// Updates and sets view matrix
// NB: g_pEffect != NULL
//--------------------------------------------------------------------------------------

void SetCamera()
{
	HRESULT hr;
	D3DXMATRIX matCamera;
	LPDIRECT3DDEVICE9 pd3dDevice = DXUTGetD3DDevice();

	// orbits camera around centrepoint
	g_vecCamPos = D3DXVECTOR3(g_fCameraOrbit * sin(g_fCameraOffset), 0.0f, g_fCameraOrbit * cos(g_fCameraOffset));

	// calculate and set view matrix
	D3DXMatrixLookAtLH(&matCamera,	&g_vecCamPos,
									&g_vecCamLook,
									&g_vecCamUp);
	V(pd3dDevice->SetTransform(D3DTS_VIEW, &matCamera))

	// set value in effect
	V(g_pEffect->SetValue(g_handleCamPos, &g_vecCamPos, sizeof(D3DXVECTOR3)))
}

//--------------------------------------------------------------------------------------
// Renders all text required by scene
// NB: Must be called between LPDIRECT3DDEVICE9::BeginScene and LPDIRECT3DDEVICE9::EndScene
//--------------------------------------------------------------------------------------

HRESULT RenderText()
{
	HRESULT hr;
	RECT rectPos; // used to position text on screen coordinates
	
	// text rendered to screen
	LPCWSTR textInfo1(L"LMB controls object rotation\nRMB controls camera rotation\nF1 cycles through objects\nF2 turns on/off the reflective component");

	// define rectangle extremities
	rectPos.top = 10; 
	rectPos.left = 10;
	rectPos.bottom = g_nWindowHeight - 10;
	rectPos.right = g_nWindowWidth - 10;

	// draw text
	V_RETURN(g_pFont->DrawText(0, textInfo1, -1, &rectPos, DT_LEFT | DT_BOTTOM | DT_NOCLIP, g_colourFont))

	return S_OK;
}

//--------------------------------------------------------------------------------------
// Handle updates to the scene
//--------------------------------------------------------------------------------------
void CALLBACK OnFrameMove( IDirect3DDevice9* pd3dDevice, double fTime, float fElapsedTime, void* pUserContext )
{
}

//--------------------------------------------------------------------------------------
// Render the scene 
//--------------------------------------------------------------------------------------
void CALLBACK OnFrameRender( IDirect3DDevice9* pd3dDevice, double fTime, float fElapsedTime, void* pUserContext )
{
	D3DXMATRIX matView, matProj, matWorld, matRotX, matRotY;
	D3DXMATRIX matWVP, matWIT;

	HRESULT hr;
	UINT unPasses;

	// clear z, back and stencil buffers
	pd3dDevice->Clear(0, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER, D3DCOLOR_XRGB(0,0,0), 1.0, 0);

	// get matrices
	V(pd3dDevice->GetTransform(D3DTS_VIEW, &matView))
	V(pd3dDevice->GetTransform(D3DTS_PROJECTION, &matProj))

	// calculate world matrix for object
	D3DXMatrixRotationY(&matRotY, g_fObjectRotY);
	D3DXMatrixRotationX(&matRotX, g_fObjectRotX);
	D3DXMatrixMultiply(&matWorld, &matRotX, &matRotY);

	// calculate world view projection matrix
	D3DXMatrixMultiply(&matWVP, &matWorld, &matView);
	D3DXMatrixMultiply(&matWVP, &matWVP, &matProj);

	// calculate world inverse transpose matrix
	D3DXMatrixInverse(&matWIT, NULL, &matWorld);
	D3DXMatrixTranspose(&matWIT, &matWIT);

	// set matrices in effect
	V(g_pEffect->SetMatrix(g_handleMatWVP, &matWVP))
	V(g_pEffect->SetMatrix(g_handleMatWIT, &matWIT))
	V(g_pEffect->SetMatrix(g_handleMatW, &matWorld))

	V(pd3dDevice->BeginScene())

	// render objects using this effect
	V(g_pEffect->SetTechnique("RefractionTech"))

	// stores number of passes required for selected technique
	V(g_pEffect->Begin(&unPasses, 0))

	// iterate through each pass
	for(UINT unPass = 0; unPass < unPasses; ++unPass)
	{
		V(g_pEffect->BeginPass(unPass))

		// draw selected object
		switch (g_nObjectSelect)
		{
		case 0:
			V(g_pMeshTeapot->DrawSubset(0))
			break;
		case 1:
			V(g_pMeshSphere->DrawSubset(0))
			break;
		case 2:
			V(g_pMeshBox->DrawSubset(0))
			break;
		case 3:
			V(g_pMeshCylinder->DrawSubset(0))
			break;
		case 4:
		default:
			V(g_pMeshTorus->DrawSubset(0))
			break;
		}

		V(g_pEffect->EndPass())
	}

	V(g_pEffect->End())

	V(g_pEffect->SetTechnique("SkyBoxTech"))

	// only set WVP matrix as its the only one the Skybox tech uses
	D3DXMatrixMultiply(&matWVP, &matView, &matProj);
	V(g_pEffect->SetMatrix(g_handleMatWVP, &matWVP))

	// stores number of passes required for selected technique
	V(g_pEffect->Begin(&unPasses, 0))

	// iterate through each pass
	for(UINT unPass = 0; unPass < unPasses; ++unPass)
	{
		V(g_pEffect->BeginPass(unPass))

		// render skybox
		V(g_pMeshSkybox->DrawSubset(0))

		V(g_pEffect->EndPass())
	}

	V(g_pEffect->End())

	V(RenderText())

	V(pd3dDevice->EndScene())
}


//--------------------------------------------------------------------------------------
// Handle messages to the application 
//--------------------------------------------------------------------------------------
LRESULT CALLBACK MsgProc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam, 
                          bool* pbNoFurtherProcessing, void* pUserContext )
{
	// used to control object and camera rotation
	static BOOL	bMoveObject = false;
	static BOOL	bMoveCamera = false;
	static INT	nLastXPos = 0;
	static INT	nLastYPos = 0;
	HRESULT hr;

	switch(uMsg)
	{
		case WM_KEYUP:
			switch(wParam)
			{
			case VK_F1:
				// cycle through objects
				if (g_nObjectSelect < 4)
					g_nObjectSelect++;
				else
					g_nObjectSelect = 0;
				break;
			case VK_F2:
				BOOL bReflection;
				V(g_pEffect->GetBool("g_bReflection", &bReflection))
				V(g_pEffect->SetBool("g_bReflection", !bReflection))
			}
			break;

		// store current window width and height
		case WM_SIZE:
			g_nWindowWidth = LOWORD(lParam);
			g_nWindowHeight = HIWORD(lParam);
			break;

		case WM_MOUSEMOVE:
		{
			if (bMoveObject)
			{
				// calculate difference in x position
				INT nCurrXPos = LOWORD(lParam);
				INT nDiff = nCurrXPos - nLastXPos; 

				// increment object's rotation
				g_fObjectRotY -= (FLOAT)nDiff / 100.0f;
				nLastXPos = nCurrXPos;	

				// calculate difference in y position
				INT nCurrYPos = HIWORD(lParam);
				nDiff = nCurrYPos - nLastYPos;

				// increment object's rotation
				g_fObjectRotX += (FLOAT)nDiff / 50.0f;
				nLastYPos = nCurrYPos;
			}

			// rotate camera around object
			if (bMoveCamera)
			{
				// calculate difference in x position
				INT nCurrXPos = LOWORD(lParam);
				INT nDiff = nCurrXPos - nLastXPos;

				// adjust camera offset
				g_fCameraOffset += (FLOAT)nDiff / 50.0f;

				// update view matrix
				SetCamera();

				nLastXPos = nCurrXPos;
			}
			break;
		}

		case WM_LBUTTONDOWN:
		{
			bMoveObject = true;
			nLastXPos = LOWORD(lParam);
			nLastYPos = HIWORD(lParam);
			break;
		}

		case WM_LBUTTONUP:
		{
			bMoveObject = false;
			break;
		}

		case WM_RBUTTONDOWN:
		{
			bMoveCamera = true;
			nLastXPos = LOWORD(lParam);
			nLastYPos = HIWORD(lParam);			
			break;
		}

		case WM_RBUTTONUP:
		{
			bMoveCamera = false;
			break;
		}
	}
	return 0;
}


//--------------------------------------------------------------------------------------
// Release resources created in the OnResetDevice callback here 
//--------------------------------------------------------------------------------------
void CALLBACK OnLostDevice( void* pUserContext )
{
	SAFE_RELEASE(g_pFont);
	SAFE_RELEASE(g_pEffect);
}


//--------------------------------------------------------------------------------------
// Release resources created in the OnCreateDevice callback here
//--------------------------------------------------------------------------------------
void CALLBACK OnDestroyDevice( void* pUserContext )
{
	SAFE_RELEASE(g_pMeshSphere);
	SAFE_RELEASE(g_pMeshBox);
	SAFE_RELEASE(g_pMeshCylinder);
	SAFE_RELEASE(g_pMeshTeapot);
	SAFE_RELEASE(g_pMeshTorus);
	SAFE_RELEASE(g_pMeshSkybox);
	SAFE_RELEASE(g_pCubeTexture);
}



//--------------------------------------------------------------------------------------
// Initialize everything and go into a render loop
//--------------------------------------------------------------------------------------
INT WINAPI WinMain( HINSTANCE, HINSTANCE, LPSTR, int )
{
    // Enable run-time memory check for debug builds.
#if defined(DEBUG) | defined(_DEBUG)
    _CrtSetDbgFlag( _CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF );
#endif

    // Set the callback functions
    DXUTSetCallbackDeviceCreated( OnCreateDevice );
    DXUTSetCallbackDeviceReset( OnResetDevice );
    DXUTSetCallbackDeviceLost( OnLostDevice );
    DXUTSetCallbackDeviceDestroyed( OnDestroyDevice );
    DXUTSetCallbackMsgProc( MsgProc );
    DXUTSetCallbackFrameRender( OnFrameRender );
    DXUTSetCallbackFrameMove( OnFrameMove );

    // Initialize DXUT and create the desired Win32 window and Direct3D device for the application
    DXUTInit( true, true, true ); // Parse the command line, handle the default hotkeys, and show msgboxes
    DXUTSetCursorSettings( true, true ); // Show the cursor and clip it when in full screen
    DXUTCreateWindow( L"Refraction Demo" );
    DXUTCreateDevice( D3DADAPTER_DEFAULT, true, g_nWindowWidth, g_nWindowHeight, IsDeviceAcceptable, ModifyDeviceSettings );

    // Start the render loop
    DXUTMainLoop();

    return DXUTGetExitCode();
}


