//--------------------------------------------------------------------------------------
//	Reflection Shader - ITB747
//
//	Author: Michael Samiec - QUT
//	Version: 1.0
//	Date: 8/4/07
//
//	This program demonstrates a planar reflection effect using the stencil buffer. The rendering 
//	steps of the procedure are as follows - 
//		1. Render entire scene normally
//		2. Render mirror surface into stencil buffer
//		3. Calculate reflection matrix and apply to objects
//		4. Render objects with stencil buffer active and z-buffer disabled
//
//	This program is based upon the EmptyProject template provided by Microsoft through the 
//	DirectX Sample Browser.
//
//	Copyright (c) Microsoft Corporation. All rights reserved.
//--------------------------------------------------------------------------------------
#include "dxstdafx.h"

// function signatures
HRESULT	RenderText();
void	InitApp();
void	RenderMirror();
void	RenderObject(LPD3DXMESH a_pMesh, D3DXMATRIX& a_rWorldMat);

// Global variables

LPD3DXEFFECT					g_pEffect = NULL;		// effect pointer that encapsulates the shader
LPD3DXFONT						g_pFont = NULL;			// font used for drawing text on screen

LPD3DXMESH						g_pMeshSphere = NULL;
LPD3DXMESH						g_pMeshBox = NULL;
LPD3DXMESH						g_pMeshCylinder = NULL;
LPD3DXMESH						g_pMeshTeapot = NULL;
LPD3DXMESH						g_pMeshMirror = NULL;

// matrix handles
D3DXHANDLE						g_handleMatWVP = NULL;
D3DXHANDLE						g_handleMatWIT = NULL;
D3DXHANDLE						g_handleMatWorld = NULL;

// handle to light direction
D3DXHANDLE						g_handleVecLightDir = NULL;

// material handles
D3DXHANDLE						g_handleMatAmb = NULL;
D3DXHANDLE						g_handleMatDiff = NULL;

// camera variables
D3DXVECTOR3						g_vecCamPos	(10.0f, 0.0f, 10.0f);
D3DXVECTOR3						g_vecCamLook(0.0f, 0.0f, 0.0f);
D3DXVECTOR3						g_vecCamUp	(0.0f, 1.0f, 0.0f);

// light direction
D3DXVECTOR3						g_vecLightDir(1.0f, 1.0f, -1.0f);

// light colours
D3DXCOLOR						g_lightAmbient	= D3DXCOLOR(0.3f, 0.4f, 0.3f, 1.0f);
D3DXCOLOR						g_lightDiffuse	= D3DXCOLOR(1.0f, 1.0f, 1.0f, 1.0f);

// object colours
D3DXCOLOR						g_matObjectAmb	= D3DXCOLOR(0.5f, 0.8f, 0.5f, 1.0f);
D3DXCOLOR						g_matObjectDiff	= D3DXCOLOR(0.5f, 0.8f, 0.5f, 1.0f);

// mirror colours
D3DXCOLOR						g_matMirrorAmb	= D3DXCOLOR(0.6f, 0.1f, 0.1f, 0.5f);
D3DXCOLOR						g_matMirrorDiff	= D3DXCOLOR(0.6f, 0.1f, 0.1f, 0.5f);

// colour used for text rendering
D3DCOLOR						g_colourFont = D3DCOLOR_XRGB(255, 255, 255);

// base mirror world matrix
D3DXMATRIX						g_matWorldMirror;

// used to allow user to rotate camera
FLOAT							g_fCameraRotY = 0.0f;
FLOAT							g_fCameraRotX = 0.0f;

// rotates objects
FLOAT							g_fObjRot = 0.0f;

// render options
BOOL							g_bClipMirror = TRUE;		// indicates if reflection should be clipped to the mirror
BOOL							g_bBlendImage = TRUE;		// indicates if the reflected image should be blended with the surface

const FLOAT						TILESPACING = 1.5f;			// used to distance mirror tiles from each other
const INT						TILESIZE = 5;				// width and height of the mirror grid

INT								g_nWindowWidth = 640;		// current window width
INT								g_nWindowHeight = 480;		// current window height

LPCWSTR							g_strFileName(L"Effect.fx");// effect file name

//--------------------------------------------------------------------------------------
// Rejects any devices that aren't acceptable by returning false
//--------------------------------------------------------------------------------------
bool CALLBACK IsDeviceAcceptable( D3DCAPS9* pCaps, D3DFORMAT AdapterFormat, 
                                  D3DFORMAT BackBufferFormat, bool bWindowed, void* pUserContext )
{
    // Typically want to skip backbuffer formats that don't support alpha blending
    IDirect3D9* pD3D = DXUTGetD3DObject(); 
    if( FAILED( pD3D->CheckDeviceFormat( pCaps->AdapterOrdinal, pCaps->DeviceType,
                    AdapterFormat, D3DUSAGE_QUERY_POSTPIXELSHADER_BLENDING, 
                    D3DRTYPE_TEXTURE, BackBufferFormat ) ) )
        return false;

	// check support for pixel and vertex shader versions 2.0
	if (pCaps->PixelShaderVersion < D3DPS_VERSION(2, 0) || pCaps->VertexShaderVersion < D3DVS_VERSION(2, 0))
		return false;

    return true;
}


//--------------------------------------------------------------------------------------
// Before a device is created, modify the device settings as needed
//--------------------------------------------------------------------------------------
bool CALLBACK ModifyDeviceSettings( DXUTDeviceSettings* pDeviceSettings, const D3DCAPS9* pCaps, void* pUserContext )
{
	// if device isn't HAL inform of performance issues
	if (pCaps->DeviceType != D3DDEVTYPE_HAL)
		MessageBox(NULL, L"Full hardware support not avaliable. Performance will be affected.", L"Warning", MB_OK);

	// ensure a stencil buffer is avaliable
    IDirect3D9* pD3D = DXUTGetD3DObject();
    if(SUCCEEDED(	pD3D->CheckDeviceFormat(pDeviceSettings->AdapterOrdinal, pDeviceSettings->DeviceType, pDeviceSettings->AdapterFormat,
					D3DUSAGE_DEPTHSTENCIL, D3DRTYPE_SURFACE, D3DFMT_D24S8)))
	{
	    if(SUCCEEDED(	pD3D->CheckDepthStencilMatch(pDeviceSettings->AdapterOrdinal, pDeviceSettings->DeviceType, pDeviceSettings->AdapterFormat,
						pDeviceSettings->pp.BackBufferFormat, D3DFMT_D24S8)))
    	{
	        pDeviceSettings->pp.AutoDepthStencilFormat = D3DFMT_D24S8;
    	}
    }
    
    return true;
}


//--------------------------------------------------------------------------------------
// Create any D3DPOOL_MANAGED resources here 
//--------------------------------------------------------------------------------------
HRESULT CALLBACK OnCreateDevice( IDirect3DDevice9* pd3dDevice, const D3DSURFACE_DESC* pBackBufferSurfaceDesc, void* pUserContext )
{
	HRESULT hr;

	// create object meshes
	V_RETURN(D3DXCreateSphere(pd3dDevice, 1.0f, 20, 20, &g_pMeshSphere, NULL))
	V_RETURN(D3DXCreateBox(pd3dDevice, 1.2f, 1.2f, 1.2f, &g_pMeshBox, NULL))
	V_RETURN(D3DXCreateCylinder(pd3dDevice, 0.0f, 0.5f, 2.0f, 25, 25, &g_pMeshCylinder, NULL))
	V_RETURN(D3DXCreatePolygon(pd3dDevice, 10.0f, 4, &g_pMeshMirror, NULL))
	V_RETURN(D3DXCreateTeapot(pd3dDevice, &g_pMeshTeapot, NULL))

    return S_OK;
}


//--------------------------------------------------------------------------------------
// Create any D3DPOOL_DEFAULT resources here 
//--------------------------------------------------------------------------------------
HRESULT CALLBACK OnResetDevice( IDirect3DDevice9* pd3dDevice, 
                                const D3DSURFACE_DESC* pBackBufferSurfaceDesc, void* pUserContext )
{
	HRESULT hr;
	D3DXMATRIX matProj, matCamera;

	// create effect
	ID3DXBuffer* pBuffer = NULL;
	if (FAILED(D3DXCreateEffectFromFile(pd3dDevice, g_strFileName, 0, 0, D3DXSHADER_DEBUG,
										0, &g_pEffect, &pBuffer)))
	{
		// if creation fails, and debug information has been returned, output debug info
		if (pBuffer)
		{
			OutputDebugStringA((char*)pBuffer->GetBufferPointer());
			SAFE_RELEASE(pBuffer);
		}

		MessageBox(0, L"D3DXCreateEffectFromFile() - FAILED", L"ERROR", 0);
		return E_FAIL;
	}

	// get handles
	g_handleMatWVP = g_pEffect->GetParameterByName(0, "g_matWorldViewProjection");
	g_handleMatWIT = g_pEffect->GetParameterByName(0, "g_matWorldInverseTranspose");
	g_handleMatAmb = g_pEffect->GetParameterByName(0, "g_vecMaterialAmbient");
	g_handleMatDiff = g_pEffect->GetParameterByName(0, "g_vecMaterialDiffuse");
	g_handleVecLightDir = g_pEffect->GetParameterByName(0, "g_vecLightDirection");

	// set variables within effect that only need to be set once
	V(g_pEffect->SetTechnique("ReflectionTech"))
	V(g_pEffect->SetValue("g_vecLightDirection", &g_vecLightDir, sizeof(D3DXVECTOR3)))
	V(g_pEffect->SetValue("g_vecLightAmbient", &g_lightAmbient, sizeof(D3DXCOLOR)))
	V(g_pEffect->SetValue("g_vecLightDiffuse", &g_lightDiffuse, sizeof(D3DXCOLOR)))

	// calculate and set projection matrix
	D3DXMatrixPerspectiveFovLH(&matProj, D3DX_PI * 0.5f, 4.0f/3.0f, 0.5f, 100.0f);
	V_RETURN(pd3dDevice->SetTransform(D3DTS_PROJECTION, &matProj))

	// create font used for rendering text
	V_RETURN(D3DXCreateFont(pd3dDevice, 16, 0, FW_BOLD, 0, false, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS,
							DEFAULT_QUALITY, DEFAULT_PITCH | FF_DONTCARE, L"Arial", &g_pFont))

    return S_OK;
}

//--------------------------------------------------------------------------------------
// Performs all application specific initialization
//--------------------------------------------------------------------------------------
void InitApp()
{
	D3DXMATRIX matRotY, matRotZ, matScale;

	// set base mirror world matrix
	D3DXMatrixRotationY(&matRotY, D3DX_PI/2); // position plane along x axis
	D3DXMatrixRotationX(&matRotZ, D3DX_PI/4); // turn a diamond into a square
	D3DXMatrixScaling(&matScale, 0.15f, 0.15f, 0.15f);
	D3DXMatrixMultiply(&g_matWorldMirror, &matRotY, &matRotZ);
	D3DXMatrixMultiply(&g_matWorldMirror, &g_matWorldMirror, &matScale);

	// normalize light direction
	D3DXVec3Normalize(&g_vecLightDir, &g_vecLightDir);
}

//--------------------------------------------------------------------------------------
// Renders all text required by scene
// NB: Must be called between LPDIRECT3DDEVICE9::BeginScene and LPDIRECT3DDEVICE9::EndScene
//--------------------------------------------------------------------------------------

HRESULT RenderText()
{
	HRESULT hr;
	RECT rectPos; // used to position text on screen coordinates
	
	// text rendered to screen
	LPCWSTR textInfo1(L"LMB controls camera rotation\nF1 turns on/off mirror clipping\nF2 turns on/off reflection blending");

	// define rectangle extremities
	rectPos.top = 10; 
	rectPos.left = 10;
	rectPos.bottom = g_nWindowHeight - 10;
	rectPos.right = g_nWindowWidth - 10;

	// draw text
	V_RETURN(g_pFont->DrawText(0, textInfo1, -1, &rectPos, DT_LEFT | DT_BOTTOM | DT_NOCLIP, g_colourFont))

	return S_OK;
}

//--------------------------------------------------------------------------------------
// Handle updates to the scene
//--------------------------------------------------------------------------------------
void CALLBACK OnFrameMove( IDirect3DDevice9* pd3dDevice, double fTime, float fElapsedTime, void* pUserContext )
{
	D3DXMATRIX matView;
	
	// rotate objects 1 full rotation and then reset
	g_fObjRot += D3DX_PI/2 * fElapsedTime;

	if (g_fObjRot >= D3DX_PI*2)
		g_fObjRot -= D3DX_PI*2;

	// update camera position
	g_vecCamPos = D3DXVECTOR3(7.5f, 10.0f * g_fCameraRotX, 10.0f * g_fCameraRotY);

	// define and set view matrix
	D3DXMatrixLookAtLH(&matView,	&g_vecCamPos,
									&g_vecCamLook,
									&g_vecCamUp);
	pd3dDevice->SetTransform(D3DTS_VIEW, &matView);
}

//--------------------------------------------------------------------------------------
// Renders mirror to scene
// NB: Must be called between LPDIRECT3DDEVICE9::BeginScene and LPDIRECT3DDEVICE9::EndScene
//		and g_pEffect != NULL
//--------------------------------------------------------------------------------------
void RenderMirror()
{
	HRESULT hr;
	D3DXMATRIX matTrans, matWVP, matWIT;
	D3DXMATRIX matWorld, matView, matProj;

	LPDIRECT3DDEVICE9 pd3dDevice = DXUTGetD3DDevice();

	// get matrices
	V(pd3dDevice->GetTransform(D3DTS_VIEW, &matView))
	V(pd3dDevice->GetTransform(D3DTS_PROJECTION, &matProj))

	for (int i = -TILESIZE; i <= TILESIZE; ++i)
	{	
		for (int j = -TILESIZE; j <= TILESIZE; ++j)
		{
			if ((i+j)%2 == 0) // every second tile is drawn, to give a checkered pattern
			{
				// calculate individual mirror piece world matrix
				D3DXMatrixTranslation(&matTrans, 0.0f, j*TILESPACING, i*TILESPACING);
				D3DXMatrixMultiply(&matWorld, &g_matWorldMirror, &matTrans);

				// calculate world view projection matrix
				D3DXMatrixMultiply(&matWVP, &matWorld, &matView);
				D3DXMatrixMultiply(&matWVP, &matWVP, &matProj);

				// calculate world inverse transpose matrix
				D3DXMatrixInverse(&matWIT, NULL, &matWorld);
				D3DXMatrixTranspose(&matWIT, &matWIT);

				// set matrices in effect and commit changes
				V(g_pEffect->SetMatrix(g_handleMatWVP, &matWVP))
				V(g_pEffect->SetMatrix(g_handleMatWIT, &matWIT))
				V(g_pEffect->CommitChanges())

				// draw mirror piece
				V(g_pMeshMirror->DrawSubset(0))
			}
		}
	}
}

//--------------------------------------------------------------------------------------
// Renders object to scene using a_rWorldMat as the objects world matrix
// NB: Must be called between LPDIRECT3DDEVICE9::BeginScene and LPDIRECT3DDEVICE9::EndScene
//		and g_pEffect != NULL
//--------------------------------------------------------------------------------------
void RenderObject(LPD3DXMESH a_pMesh, D3DXMATRIX& a_rWorldMat)
{
	HRESULT hr;
	D3DXMATRIX matWVP, matWIT;
	D3DXMATRIX matWorld, matView, matProj;

	LPDIRECT3DDEVICE9 pd3dDevice = DXUTGetD3DDevice();	

	// get matrices
	V(pd3dDevice->GetTransform(D3DTS_VIEW, &matView))
	V(pd3dDevice->GetTransform(D3DTS_PROJECTION, &matProj))

	// calculate world view projection matrix
	D3DXMatrixMultiply(&matWVP, &a_rWorldMat, &matView);
	D3DXMatrixMultiply(&matWVP, &matWVP, &matProj);

	// calculate world inverse transpose matrix
	D3DXMatrixInverse(&matWIT, NULL, &a_rWorldMat);
	D3DXMatrixTranspose(&matWIT, &matWIT);

	// set matrices in effect and commit changes
	V(g_pEffect->SetMatrix(g_handleMatWVP, &matWVP))
	V(g_pEffect->SetMatrix(g_handleMatWIT, &matWIT))
	V(g_pEffect->CommitChanges())

	// draw mesh
	V((a_pMesh)->DrawSubset(0))
}

//--------------------------------------------------------------------------------------
// Render the scene 
//--------------------------------------------------------------------------------------
void CALLBACK OnFrameRender( IDirect3DDevice9* pd3dDevice, double fTime, float fElapsedTime, void* pUserContext )
{
	D3DXMATRIX matTrans, matRotY;
	D3DXMATRIX matWorldSphere, matWorldBox, matWorldCylinder, matWorldTeapot;	// object world matrices
	D3DXMATRIX matReflection;									// reflection matrix
	D3DXVECTOR3 vecReflectedLight;								// reflected light direction
	D3DXPLANE oReflectPlane(1.0f, 0.0f, 0.0f, 0.0f);			// plane used to calculate reflection matrix from

	HRESULT hr;
	UINT unPasses;

	// clear z, back and stencil buffers
	pd3dDevice->Clear(0, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER | D3DCLEAR_STENCIL, 
						D3DCOLOR_XRGB(10,10,10), 1.0, 0);

	V(pd3dDevice->BeginScene())

	// stores number of passes required for selected technique
	V(g_pEffect->Begin(&unPasses, 0))

	// iterate through each pass
	for(UINT unPass = 0; unPass < unPasses; ++unPass)
	{
		V(g_pEffect->BeginPass(unPass))

		// set non-reflected light direction
		V(g_pEffect->SetValue(g_handleVecLightDir, &g_vecLightDir, sizeof(D3DXVECTOR3)))

		// set mirror materials
		V(g_pEffect->SetValue(g_handleMatAmb, &g_matMirrorAmb, sizeof(D3DXCOLOR)))
		V(g_pEffect->SetValue(g_handleMatDiff, &g_matMirrorDiff, sizeof(D3DXCOLOR)))

		// disable writes to the z-buffer as we will want to render objects behind mirror later
		V(pd3dDevice->SetRenderState(D3DRS_ZWRITEENABLE, FALSE))

		// render mirror
		RenderMirror();

		// re-enable writes to the z-buffer
		V(pd3dDevice->SetRenderState(D3DRS_ZWRITEENABLE, TRUE))

		// set object materials
		V(g_pEffect->SetValue(g_handleMatAmb, &g_matObjectAmb, sizeof(D3DXCOLOR)))
		V(g_pEffect->SetValue(g_handleMatDiff, &g_matObjectDiff, sizeof(D3DXCOLOR)))

		// render non-reflected states of objects

		// render sphere
		D3DXMatrixRotationY(&matRotY, g_fObjRot);
		D3DXMatrixTranslation(&matTrans, 3.0, -2.0, -2.0);
		D3DXMatrixMultiply(&matWorldSphere, &matRotY, &matTrans);

		RenderObject(g_pMeshSphere, matWorldSphere);

		// render cube
		D3DXMatrixTranslation(&matTrans, 3.0, 2.0, 2.0);
		D3DXMatrixMultiply(&matWorldBox, &matRotY, &matTrans);

		RenderObject(g_pMeshBox, matWorldBox);

		// render cone
		D3DXMatrixTranslation(&matTrans, 3.0, 2.0, -2.0);
		D3DXMatrixMultiply(&matWorldCylinder, &matRotY, &matTrans);

		RenderObject(g_pMeshCylinder, matWorldCylinder);

		// render teapot
		D3DXMatrixTranslation(&matTrans, 3.0, -2.0, 2.0);
		D3DXMatrixMultiply(&matWorldTeapot, &matRotY, &matTrans);

		RenderObject(g_pMeshTeapot, matWorldTeapot);


		// turn stencil buffer on
		V(pd3dDevice->SetRenderState(D3DRS_STENCILENABLE, TRUE))
		V(pd3dDevice->SetRenderState(D3DRS_STENCILFUNC, D3DCMP_ALWAYS))
		V(pd3dDevice->SetRenderState(D3DRS_STENCILREF, 0x1))
		V(pd3dDevice->SetRenderState(D3DRS_STENCILMASK, 0xffffffff))
		V(pd3dDevice->SetRenderState(D3DRS_STENCILWRITEMASK, 0xffffffff))
		V(pd3dDevice->SetRenderState(D3DRS_STENCILZFAIL, D3DSTENCILOP_KEEP))
		V(pd3dDevice->SetRenderState(D3DRS_STENCILFAIL, D3DSTENCILOP_KEEP))
		V(pd3dDevice->SetRenderState(D3DRS_STENCILPASS, D3DSTENCILOP_REPLACE))

		// only render to the stencil buffer

		// disable writes to the z-buffer
		pd3dDevice->SetRenderState(D3DRS_ZWRITEENABLE, FALSE);

		// disable writes to the back buffer
		pd3dDevice->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
		pd3dDevice->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_ZERO);
		pd3dDevice->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_ONE);

		// render mirror into stencil buffer
		RenderMirror();

		// if blending enable, set stencil test, otherwise allow all
		if (g_bClipMirror)
			pd3dDevice->SetRenderState(D3DRS_STENCILFUNC, D3DCMP_EQUAL);
		else
			pd3dDevice->SetRenderState(D3DRS_STENCILFUNC, D3DCMP_ALWAYS);

		// don't adjust values within stencil buffer
		pd3dDevice->SetRenderState(D3DRS_STENCILPASS, D3DSTENCILOP_KEEP);

		// re-enable z-buffer writes
		pd3dDevice->SetRenderState(D3DRS_ZWRITEENABLE, TRUE);
		// enable alpha blending for reflected objects
		pd3dDevice->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);

		// change winding to allow flipped objects to render properly
		pd3dDevice->SetRenderState(D3DRS_CULLMODE, D3DCULL_CW);

		if (g_bBlendImage)
		{
			// blend image with destination pixel
			pd3dDevice->SetRenderState( D3DRS_SRCBLEND,     D3DBLEND_SRCALPHA );
			pd3dDevice->SetRenderState( D3DRS_DESTBLEND,    D3DBLEND_INVSRCCOLOR );
		} 
		else
		{
			// discard destination pixel
			pd3dDevice->SetRenderState( D3DRS_SRCBLEND,     D3DBLEND_ONE );
			pd3dDevice->SetRenderState( D3DRS_DESTBLEND,    D3DBLEND_ZERO );
		}

		// calculate reflection matrix
		D3DXMatrixReflect(&matReflection, &oReflectPlane);
		
		// reflect light vector
		D3DXVec3TransformCoord(&vecReflectedLight, &g_vecLightDir, &matReflection);

		// update light position for reflected objects
		g_pEffect->SetValue(g_handleVecLightDir, &vecReflectedLight, sizeof(D3DXVECTOR3));

		// render objects reflected within mirror

		// draw reflected sphere
		D3DXMatrixMultiply(&matWorldSphere, &matWorldSphere, &matReflection);
		RenderObject(g_pMeshSphere, matWorldSphere);

		// draw reflected cube
		D3DXMatrixMultiply(&matWorldBox, &matWorldBox, &matReflection);
		RenderObject(g_pMeshBox, matWorldBox);

		// draw reflected cone
		D3DXMatrixMultiply(&matWorldCylinder, &matWorldCylinder, &matReflection);
		RenderObject(g_pMeshCylinder, matWorldCylinder);

		// draw reflected teapot
		D3DXMatrixMultiply(&matWorldTeapot, &matWorldTeapot, &matReflection);
		RenderObject(g_pMeshTeapot, matWorldTeapot);

		// setup render states for next rendering pass

		// set default winding mode
		V(pd3dDevice->SetRenderState(D3DRS_CULLMODE, D3DCULL_CCW))
		// disable stencil buffer
		V(pd3dDevice->SetRenderState(D3DRS_STENCILENABLE, FALSE))
		// disable alpha blending
		V(pd3dDevice->SetRenderState(D3DRS_ALPHABLENDENABLE, FALSE))

		V(g_pEffect->EndPass())
	}

	V(g_pEffect->End())

	V(RenderText())

	V(pd3dDevice->EndScene())
}


//--------------------------------------------------------------------------------------
// Handle messages to the application 
//--------------------------------------------------------------------------------------
LRESULT CALLBACK MsgProc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam, 
                          bool* pbNoFurtherProcessing, void* pUserContext )
{
	static BOOL	bMoveCamera = FALSE;
	static INT	nLastXPos = 0;
	static INT	nLastYPos = 0;

	switch(uMsg)
	{
		case WM_KEYUP:
			switch(wParam)
			{
			// render options
			case VK_F1:
				g_bClipMirror = !g_bClipMirror;
				break;
			case VK_F2:
				g_bBlendImage = !g_bBlendImage;
				break;
			}
			break;

		// store current window width and height
		case WM_SIZE:
			g_nWindowWidth = LOWORD(lParam);
			g_nWindowHeight = HIWORD(lParam);
			break;

		case WM_MOUSEMOVE:
		{
			if (bMoveCamera)
			{
				// calculate difference in x position
				INT nCurrXPos = LOWORD(lParam);
				INT nDiff = nCurrXPos - nLastXPos; 

				// increment object's rotation
				g_fCameraRotY += (FLOAT)nDiff / 100.0f;
				nLastXPos = nCurrXPos;	

				// calculate difference in y position
				INT nCurrYPos = HIWORD(lParam);
				nDiff = nCurrYPos - nLastYPos;

				// increment object's rotation
				g_fCameraRotX -= (FLOAT)nDiff / 50.0f;
				nLastYPos = nCurrYPos;
			}
			break;
		}

		case WM_LBUTTONDOWN:
		{
			bMoveCamera = TRUE;
			nLastXPos = LOWORD(lParam);
			nLastYPos = HIWORD(lParam);
			break;
		}

		case WM_LBUTTONUP:
		{
			bMoveCamera = FALSE;
			break;
		}
	}
	return 0;
}


//--------------------------------------------------------------------------------------
// Release resources created in the OnResetDevice callback here 
//--------------------------------------------------------------------------------------
void CALLBACK OnLostDevice( void* pUserContext )
{
	SAFE_RELEASE(g_pFont);
	SAFE_RELEASE(g_pEffect);
}


//--------------------------------------------------------------------------------------
// Release resources created in the OnCreateDevice callback here
//--------------------------------------------------------------------------------------
void CALLBACK OnDestroyDevice( void* pUserContext )
{
	SAFE_RELEASE(g_pMeshSphere);
	SAFE_RELEASE(g_pMeshBox);
	SAFE_RELEASE(g_pMeshCylinder);
	SAFE_RELEASE(g_pMeshTeapot);
	SAFE_RELEASE(g_pMeshMirror);
}



//--------------------------------------------------------------------------------------
// Initialize everything and go into a render loop
//--------------------------------------------------------------------------------------
INT WINAPI WinMain( HINSTANCE, HINSTANCE, LPSTR, int )
{
    // Enable run-time memory check for debug builds.
#if defined(DEBUG) | defined(_DEBUG)
    _CrtSetDbgFlag( _CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF );
#endif

    // Set the callback functions
    DXUTSetCallbackDeviceCreated( OnCreateDevice );
    DXUTSetCallbackDeviceReset( OnResetDevice );
    DXUTSetCallbackDeviceLost( OnLostDevice );
    DXUTSetCallbackDeviceDestroyed( OnDestroyDevice );
    DXUTSetCallbackMsgProc( MsgProc );
    DXUTSetCallbackFrameRender( OnFrameRender );
    DXUTSetCallbackFrameMove( OnFrameMove );

    // Initialize DXUT and create the desired Win32 window and Direct3D device for the application
    DXUTInit( true, true, true ); // Parse the command line, handle the default hotkeys, and show msgboxes
    DXUTSetCursorSettings( true, true ); // Show the cursor and clip it when in full screen
    DXUTCreateWindow( L"Reflection Demo" );
    DXUTCreateDevice( D3DADAPTER_DEFAULT, true, g_nWindowWidth, g_nWindowHeight, IsDeviceAcceptable, ModifyDeviceSettings );

	InitApp();

    // Start the render loop
    DXUTMainLoop();

    return DXUTGetExitCode();
}


