//--------------------------------------------------------------------------------------
//	Shadow Volume Shader - ITB747
//
//	This program is a cut down version of Microsoft's Shadow Volume demo provided in their
//	SDK. It has been simplified to highlight the core components of the algorithm to 
//	provide easy understanding for teaching purposes. As such, much of the demo's functions
//	and algorithms remain exactly as they were in the original demo.
//
//	This program was assembled by Michael Samiec on the 7/5/2007.
//
//	This program is based upon the EmptyProject template provided by Microsoft through the 
//	DirectX Sample Browser.
//
//	Copyright (c) Microsoft Corporation. All rights reserved.
//--------------------------------------------------------------------------------------
#include "dxstdafx.h"

// function signatures
void	UpdateCamera();
HRESULT	RenderText();
void	RenderObject(LPD3DXMESH a_pMesh, D3DXMATRIX& a_rWorldMat);
void	RenderScene(bool bShadowVolumes = false);

// Microsoft's function
HRESULT GenerateShadowMesh( IDirect3DDevice9 *pd3dDevice, ID3DXMesh *pMesh, ID3DXMesh **ppOutMesh );

// Global variables

LPD3DXEFFECT					g_pEffect = NULL;		// effect pointer that encapsulates the shader
LPD3DXFONT						g_pFont = NULL;			// font used for drawing text on screen

// normal meshes
LPD3DXMESH						g_pMeshSphere = NULL;
LPD3DXMESH						g_pMeshCylinder = NULL;
LPD3DXMESH						g_pMeshPlane = NULL;

// shadow meshes capable of having their edges extruded in the vertex shader for shadow volume rendering
LPD3DXMESH						g_pMeshSphereShadow = NULL;
LPD3DXMESH						g_pMeshCylinderShadow = NULL;

// matrix handles
D3DXHANDLE						g_handleMatWVP = NULL;
D3DXHANDLE						g_handleMatWV = NULL;
D3DXHANDLE						g_handleMatP = NULL;

// material handles
D3DXHANDLE						g_handleMatAmb = NULL;
D3DXHANDLE						g_handleMatDiff = NULL;

// light direction handle
D3DXHANDLE						g_handleVecLightDir = NULL;

// technique handles
D3DXHANDLE						g_handleTechAmbient = NULL;
D3DXHANDLE						g_handleTechScene = NULL;
D3DXHANDLE						g_handleTechShadow = NULL;

// camera variables
D3DXVECTOR3						g_vecCamPos	(10.0f, 0.0f, 10.0f);
D3DXVECTOR3						g_vecCamLook(0.0f, 0.0f, 0.0f);
D3DXVECTOR3						g_vecCamUp	(0.0f, 1.0f, 0.0f);

// light variables
D3DXVECTOR3						g_vecLightDir;
D3DXVECTOR3						g_vecLightPos;

// light colours
D3DXCOLOR						g_lightAmbient	= D3DXCOLOR(0.3f, 0.4f, 0.3f, 1.0f);
D3DXCOLOR						g_lightDiffuse	= D3DXCOLOR(1.0f, 1.0f, 1.0f, 1.0f);

// object colours
D3DXCOLOR						g_matObjectAmb	= D3DXCOLOR(0.3f, 0.3f, 0.55f, 1.0f);
D3DXCOLOR						g_matObjectDiff	= D3DXCOLOR(0.3f, 0.3f, 0.55f, 1.0f);

// plane colours
D3DXCOLOR						g_matPlaneAmb	= D3DXCOLOR(0.6f, 0.2f, 0.1f, 1.0f);
D3DXCOLOR						g_matPlaneDiff	= D3DXCOLOR(0.6f, 0.2f, 0.1f, 1.0f);

// colour used for text rendering
D3DCOLOR						g_colourFont = D3DCOLOR_XRGB(255, 255, 255);

// used to allow user to rotate camera
FLOAT							g_fCameraRotY = 0.0f;
FLOAT							g_fCameraRotZ = 0.0f;

// rotates object and light
FLOAT							g_fObjRot = 0.0f;
FLOAT							g_fLightRot = 0.0f;

// render options
BOOL							g_bAnimateSphere = TRUE;	
BOOL							g_bAnimateLight = TRUE;

INT								g_nWindowWidth = 640;		// current window width
INT								g_nWindowHeight = 480;		// current window height

LPCWSTR							g_strFileName(L"Effect.fx");// effect file name


//--------------------------------------------------------------------------------------
// Rejects any devices that aren't acceptable by returning false
//--------------------------------------------------------------------------------------
bool CALLBACK IsDeviceAcceptable( D3DCAPS9* pCaps, D3DFORMAT AdapterFormat, 
                                  D3DFORMAT BackBufferFormat, bool bWindowed, void* pUserContext )
{
    // Typically want to skip backbuffer formats that don't support alpha blending
    IDirect3D9* pD3D = DXUTGetD3DObject(); 
    if( FAILED( pD3D->CheckDeviceFormat( pCaps->AdapterOrdinal, pCaps->DeviceType,
                    AdapterFormat, D3DUSAGE_QUERY_POSTPIXELSHADER_BLENDING, 
                    D3DRTYPE_TEXTURE, BackBufferFormat ) ) )
        return false;

	// check support for pixel and vertex shader versions 2.0
	if (pCaps->PixelShaderVersion < D3DPS_VERSION(2, 0) || pCaps->VertexShaderVersion < D3DVS_VERSION(2, 0))
		return false;

    return true;
}


//--------------------------------------------------------------------------------------
// Before a device is created, modify the device settings as needed
//--------------------------------------------------------------------------------------
bool CALLBACK ModifyDeviceSettings( DXUTDeviceSettings* pDeviceSettings, const D3DCAPS9* pCaps, void* pUserContext )
{
	// if device isn't HAL inform of performance issues
	if (pCaps->DeviceType != D3DDEVTYPE_HAL)
		MessageBox(NULL, L"Full hardware support not avaliable. Performance will be affected.", L"Warning", MB_OK);

	// ensure a stencil buffer is avaliable
    IDirect3D9* pD3D = DXUTGetD3DObject();
    if(SUCCEEDED(	pD3D->CheckDeviceFormat(pDeviceSettings->AdapterOrdinal, pDeviceSettings->DeviceType, pDeviceSettings->AdapterFormat,
					D3DUSAGE_DEPTHSTENCIL, D3DRTYPE_SURFACE, D3DFMT_D24S8)))
	{
	    if(SUCCEEDED(	pD3D->CheckDepthStencilMatch(pDeviceSettings->AdapterOrdinal, pDeviceSettings->DeviceType, pDeviceSettings->AdapterFormat,
						pDeviceSettings->pp.BackBufferFormat, D3DFMT_D24S8)))
    	{
	        pDeviceSettings->pp.AutoDepthStencilFormat = D3DFMT_D24S8;
    	}
    }

    return true;
}


//--------------------------------------------------------------------------------------
// Create any D3DPOOL_MANAGED resources here 
//--------------------------------------------------------------------------------------
HRESULT CALLBACK OnCreateDevice( IDirect3DDevice9* pd3dDevice, const D3DSURFACE_DESC* pBackBufferSurfaceDesc, void* pUserContext )
{
	HRESULT hr;

	// create object meshes
	V_RETURN(D3DXCreateSphere(pd3dDevice, 0.6f, 50, 50, &g_pMeshSphere, NULL))
	V_RETURN(D3DXCreateCylinder(pd3dDevice, 0.75f, 0.75f, 5.0f, 50, 50, &g_pMeshCylinder, NULL))
	V_RETURN(D3DXCreatePolygon(pd3dDevice, 50.0f, 4, &g_pMeshPlane, NULL))
	
    return S_OK;
}


//--------------------------------------------------------------------------------------
// Create any D3DPOOL_DEFAULT resources here 
//--------------------------------------------------------------------------------------
HRESULT CALLBACK OnResetDevice( IDirect3DDevice9* pd3dDevice, 
                                const D3DSURFACE_DESC* pBackBufferSurfaceDesc, void* pUserContext )
{
	HRESULT hr;
	D3DXMATRIX matProj, matCamera;

	// create effect
	ID3DXBuffer* pBuffer = NULL;
	if (FAILED(D3DXCreateEffectFromFile(pd3dDevice, g_strFileName, 0, 0, D3DXSHADER_DEBUG,
										0, &g_pEffect, &pBuffer)))
	{
		// if creation fails, and debug information has been returned, output debug info
		if (pBuffer)
		{
			OutputDebugStringA((char*)pBuffer->GetBufferPointer());
			SAFE_RELEASE(pBuffer);
		}

		MessageBox(0, L"D3DXCreateEffectFromFile() - FAILED", L"ERROR", 0);
		return E_FAIL;
	}

	// get handles to variables within effect
	g_handleMatWVP = g_pEffect->GetParameterByName(0, "g_matWVP");
	g_handleMatWV = g_pEffect->GetParameterByName(0, "g_matWV");
	g_handleMatP = g_pEffect->GetParameterByName(0, "g_matP");

	g_handleMatAmb = g_pEffect->GetParameterByName(0, "g_vecMaterialAmbient");
	g_handleMatDiff = g_pEffect->GetParameterByName(0, "g_vecMaterialDiffuse");

	g_handleVecLightDir = g_pEffect->GetParameterByName(0, "g_vecLightDir");

	g_handleTechAmbient = g_pEffect->GetTechniqueByName("RenderSceneAmbient");
	g_handleTechScene = g_pEffect->GetTechniqueByName("RenderScene");
	g_handleTechShadow = g_pEffect->GetTechniqueByName("RenderShadowVolume2Sided");

	// set variables within effect that only need to be set once
	V(g_pEffect->SetValue("g_vecLightAmbient", &g_lightAmbient, sizeof(D3DXCOLOR)))
	V(g_pEffect->SetValue("g_vecLightDiffuse", &g_lightDiffuse, sizeof(D3DXCOLOR)))

	// calculate and set projection matrix
	D3DXMatrixPerspectiveFovLH(&matProj, D3DX_PI * 0.5f, 4.0f/3.0f, 0.5f, 500.0f);
	V_RETURN(pd3dDevice->SetTransform(D3DTS_PROJECTION, &matProj))
	V_RETURN(g_pEffect->SetFloat("g_fFarClip", 500.0f))	// set far clipping plane

	// create font used for rendering text
	V_RETURN(D3DXCreateFont(pd3dDevice, 16, 0, FW_BOLD, 0, false, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS,
							DEFAULT_QUALITY, DEFAULT_PITCH | FF_DONTCARE, L"Arial", &g_pFont))

	// create shadow meshes
	V_RETURN(GenerateShadowMesh(pd3dDevice, g_pMeshSphere, &g_pMeshSphereShadow))
	V_RETURN(GenerateShadowMesh(pd3dDevice, g_pMeshCylinder, &g_pMeshCylinderShadow))

	UpdateCamera();

    return S_OK;
}

//--------------------------------------------------------------------------------------
// Updates the camera (view matrix)
//--------------------------------------------------------------------------------------
void UpdateCamera()
{
	HRESULT hr;
	D3DXMATRIX matView, matRotY, matRotZ, matCam;

	if (g_fCameraRotZ > 1.0f)
		g_fCameraRotZ = 1.0f;
	else if (g_fCameraRotZ < -0.2f)
		g_fCameraRotZ = -0.2f;

	D3DXMatrixRotationY(&matRotY, g_fCameraRotY);
	D3DXMatrixRotationZ(&matRotZ, g_fCameraRotZ);
	D3DXMatrixMultiply(&matCam, &matRotZ, &matRotY);

	// update camera position
	D3DXVECTOR3 vecOrgCamPos(7.0f, 0.0f, 0.0f);
	D3DXVec3TransformCoord(&g_vecCamPos, &vecOrgCamPos, &matCam); 

	// define and set view matrix
	D3DXMatrixLookAtLH(&matView,	&g_vecCamPos,
									&g_vecCamLook,
									&g_vecCamUp);
	V(DXUTGetD3DDevice()->SetTransform(D3DTS_VIEW, &matView))
}

//--------------------------------------------------------------------------------------
// Renders all text required by scene
// NB: Must be called between LPDIRECT3DDEVICE9::BeginScene and LPDIRECT3DDEVICE9::EndScene
//--------------------------------------------------------------------------------------

HRESULT RenderText()
{
	HRESULT hr;
	RECT rectPos; // used to position text on screen coordinates
	
	// text rendered to screen
	LPCWSTR textInfo1(L"LMB controls camera rotation\nF1 turns sphere movement on/off\nF2 turns light rotation on/off");

	// define rectangle extremities
	rectPos.top = 10; 
	rectPos.left = 10;
	rectPos.bottom = g_nWindowHeight - 10;
	rectPos.right = g_nWindowWidth - 10;

	// draw text
	V_RETURN(g_pFont->DrawText(0, textInfo1, -1, &rectPos, DT_LEFT | DT_BOTTOM | DT_NOCLIP, g_colourFont))

	return S_OK;
}

//--------------------------------------------------------------------------------------
// Handle updates to the scene
//--------------------------------------------------------------------------------------
void CALLBACK OnFrameMove( IDirect3DDevice9* pd3dDevice, double fTime, float fElapsedTime, void* pUserContext )
{
	if (g_bAnimateSphere)
	{
		// rotate sphere around column
		g_fObjRot += fElapsedTime * 5.0f;

		if (g_fObjRot >= D3DX_PI*2)
			g_fObjRot -= D3DX_PI*2;
	}

	if (g_bAnimateLight)
	{
		// rotate light
		g_fLightRot += fElapsedTime;

		if (g_fLightRot >= D3DX_PI*2)
			g_fLightRot -= D3DX_PI*2;

		D3DXVECTOR3 lightLook(0.0f, 0.0f, 0.0f);

		// calculate new light position
		g_vecLightPos = D3DXVECTOR3(150.0f * sin(g_fLightRot), 50.0f, 150.0f * cos(g_fLightRot));

		// calculate new light direction
		g_vecLightDir = g_vecLightPos - lightLook;
		D3DXVec3Normalize(&g_vecLightDir, &g_vecLightDir);
	}
}

//--------------------------------------------------------------------------------------
// Renders object to scene using a_rWorldMat as the objects world matrix
// NB: Must be called between LPDIRECT3DDEVICE9::BeginScene and LPDIRECT3DDEVICE9::EndScene
//		and g_pEffect != NULL
//--------------------------------------------------------------------------------------
void RenderObject(LPD3DXMESH a_pMesh, D3DXMATRIX& a_rWorldMat)
{
	HRESULT hr;
	D3DXMATRIX matWVP, matWV;
	D3DXMATRIX matWorld, matView, matProj;

	LPDIRECT3DDEVICE9 pd3dDevice = DXUTGetD3DDevice();	

	// get matrices
	V(pd3dDevice->GetTransform(D3DTS_VIEW, &matView))
	V(pd3dDevice->GetTransform(D3DTS_PROJECTION, &matProj))

	// calculate world view projection matrix
	D3DXMatrixMultiply(&matWV, &a_rWorldMat, &matView);
	D3DXMatrixMultiply(&matWVP, &matWV, &matProj);

	// set matrices in effect
	V(g_pEffect->SetMatrix(g_handleMatWVP, &matWVP))
	V(g_pEffect->SetMatrix(g_handleMatWV, &matWV))
	V(g_pEffect->SetMatrix(g_handleMatP, &matProj))

	V(g_pEffect->CommitChanges())

	// draw mesh
	V((a_pMesh)->DrawSubset(0))
}

//--------------------------------------------------------------------------------------
// Renders objects within the scene, setting desired materials along the way
// NB: bShadowVolumes - specifies if this render pass is for shadow volumes or not
//--------------------------------------------------------------------------------------
void RenderScene(bool bShadowVolumes)
{
	HRESULT hr;
	D3DXMATRIX matTrans, matRotY, matRotX;
	D3DXMATRIX matWorld;

	// set plane materials
	V(g_pEffect->SetValue(g_handleMatAmb, &g_matPlaneAmb, sizeof(D3DXCOLOR)))
	V(g_pEffect->SetValue(g_handleMatDiff, &g_matPlaneDiff, sizeof(D3DXCOLOR)))

	// render plane
	D3DXMatrixTranslation(&matTrans, 0.0f, -2.5f, 0.0f);
	D3DXMatrixRotationX(&matRotX, -D3DX_PI / 2.0f);
	D3DXMatrixRotationY(&matRotY, -D3DX_PI / 4.0f);
	D3DXMatrixMultiply(&matWorld, &matRotX, &matRotY);
	D3DXMatrixMultiply(&matWorld, &matWorld, &matTrans);

	// don't render plane if rendering shadow volumes
	if (!bShadowVolumes)
		RenderObject(g_pMeshPlane, matWorld);

	// set object materials
	V(g_pEffect->SetValue(g_handleMatAmb, &g_matObjectAmb, sizeof(D3DXCOLOR)))
	V(g_pEffect->SetValue(g_handleMatDiff, &g_matObjectDiff, sizeof(D3DXCOLOR)))

	// setup object's world matrix
	D3DXMatrixRotationY(&matRotY, g_fObjRot);
	D3DXMatrixTranslation(&matTrans, 3.0, 0.0, 0.0);
	D3DXMatrixMultiply(&matWorld, &matTrans, &matRotY);

	if (!bShadowVolumes)
	{
		// render normal objects
		RenderObject(g_pMeshSphere, matWorld);
		RenderObject(g_pMeshCylinder, matRotX);
	}
	else
	{
		// render shadow objects
		RenderObject(g_pMeshSphereShadow, matWorld);
		RenderObject(g_pMeshCylinderShadow, matRotX);
	}		
}

//--------------------------------------------------------------------------------------
// Render the scene 
//--------------------------------------------------------------------------------------
void CALLBACK OnFrameRender( IDirect3DDevice9* pd3dDevice, double fTime, float fElapsedTime, void* pUserContext )
{
	HRESULT hr;
	UINT unPasses;

	// clear z, back and stencil buffers
	V(pd3dDevice->Clear(0, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER | D3DCLEAR_STENCIL, 0x00000000, 1.0, 0))

	V(pd3dDevice->BeginScene())

	// first render scene with ambient lighting only to define z buffer
	V(g_pEffect->SetTechnique(g_handleTechAmbient))

	// stores number of passes required for selected technique
	V(g_pEffect->Begin(&unPasses, 0))

	// iterate through each pass
	for(UINT unPass = 0; unPass < unPasses; ++unPass)
	{
		V(g_pEffect->BeginPass(unPass))

		RenderScene();

		V(g_pEffect->EndPass())
	}

	V(g_pEffect->End())

	// next, render shadow volumes into the stencil buffer
	V(g_pEffect->SetTechnique(g_handleTechShadow)) 

	// calculate light direction in view space
	D3DXMATRIX matView;
	D3DXVECTOR4 vecLight;
	D3DXVECTOR4	vecLightOrg(g_vecLightPos.x, g_vecLightPos.y, g_vecLightPos.z, 1.0f);
	V(pd3dDevice->GetTransform(D3DTS_VIEW, &matView))
	D3DXVec4Transform(&vecLight, &vecLightOrg, &matView);

	// set light direction
	V(g_pEffect->SetValue(g_handleVecLightDir, &vecLight, sizeof(D3DXVECTOR4)))

	// stores number of passes required for selected technique
	V(g_pEffect->Begin(&unPasses, 0))

	// iterate through each pass
	for(UINT unPass = 0; unPass < unPasses; ++unPass)
	{
		V(g_pEffect->BeginPass(unPass))

		// render shadow volumes
		RenderScene(true);

		V(g_pEffect->EndPass())
	}

	V(g_pEffect->End())

	// lastly, render the scene
	V(g_pEffect->SetTechnique(g_handleTechScene)) 

	// stores number of passes required for selected technique
	V(g_pEffect->Begin(&unPasses, 0))

	// iterate through each pass
	for(UINT unPass = 0; unPass < unPasses; ++unPass)
	{
		V(g_pEffect->BeginPass(unPass))

		RenderScene();

		V(g_pEffect->EndPass())
	}

	V(g_pEffect->End())

	V(RenderText())

	V(pd3dDevice->EndScene())
}


//--------------------------------------------------------------------------------------
// Handle messages to the application 
//--------------------------------------------------------------------------------------
LRESULT CALLBACK MsgProc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam, 
                          bool* pbNoFurtherProcessing, void* pUserContext )
{
	static BOOL	bMoveCamera = FALSE;
	static INT	nLastXPos = 0;
	static INT	nLastYPos = 0;

	switch(uMsg)
	{
		case WM_KEYUP:
			switch(wParam)
			{
			// render options
			case VK_F1:
				g_bAnimateSphere = !g_bAnimateSphere;
				break;
			case VK_F2:
				g_bAnimateLight = !g_bAnimateLight;
				break;
			}
			break;

		// store current window width and height
		case WM_SIZE:
			g_nWindowWidth = LOWORD(lParam);
			g_nWindowHeight = HIWORD(lParam);
			break;

		case WM_MOUSEMOVE:
		{
			if (bMoveCamera)
			{
				// calculate difference in x position
				INT nCurrXPos = LOWORD(lParam);
				INT nDiff = nCurrXPos - nLastXPos; 

				// adjust camera's rotation
				g_fCameraRotY -= (FLOAT)nDiff / 100.0f;
				nLastXPos = nCurrXPos;	

				// calculate difference in y position
				INT nCurrYPos = HIWORD(lParam);
				nDiff = nCurrYPos - nLastYPos;

				// adjust object's rotation
				g_fCameraRotZ -= (FLOAT)nDiff / 100.0f;
				nLastYPos = nCurrYPos;

				UpdateCamera();
			}
			break;
		}

		case WM_LBUTTONDOWN:
		{
			bMoveCamera = TRUE;
			nLastXPos = LOWORD(lParam);
			nLastYPos = HIWORD(lParam);
			break;
		}

		case WM_LBUTTONUP:
		{
			bMoveCamera = FALSE;
			break;
		}
	}
	return 0;
}


//--------------------------------------------------------------------------------------
// Release resources created in the OnResetDevice callback here 
//--------------------------------------------------------------------------------------
void CALLBACK OnLostDevice( void* pUserContext )
{
	SAFE_RELEASE(g_pFont);
	SAFE_RELEASE(g_pEffect);
	SAFE_RELEASE(g_pMeshSphereShadow);
	SAFE_RELEASE(g_pMeshCylinderShadow);
}


//--------------------------------------------------------------------------------------
// Release resources created in the OnCreateDevice callback here
//--------------------------------------------------------------------------------------
void CALLBACK OnDestroyDevice( void* pUserContext )
{
	SAFE_RELEASE(g_pMeshSphere);
	SAFE_RELEASE(g_pMeshCylinder);
	SAFE_RELEASE(g_pMeshPlane);
}



//--------------------------------------------------------------------------------------
// Initialize everything and go into a render loop
//--------------------------------------------------------------------------------------
INT WINAPI WinMain( HINSTANCE, HINSTANCE, LPSTR, int )
{
    // Enable run-time memory check for debug builds.
#if defined(DEBUG) | defined(_DEBUG)
    _CrtSetDbgFlag( _CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF );
#endif

    // Set the callback functions
    DXUTSetCallbackDeviceCreated( OnCreateDevice );
    DXUTSetCallbackDeviceReset( OnResetDevice );
    DXUTSetCallbackDeviceLost( OnLostDevice );
    DXUTSetCallbackDeviceDestroyed( OnDestroyDevice );
    DXUTSetCallbackMsgProc( MsgProc );
    DXUTSetCallbackFrameRender( OnFrameRender );
    DXUTSetCallbackFrameMove( OnFrameMove );

    // Initialize DXUT and create the desired Win32 window and Direct3D device for the application
    DXUTInit( true, true, true ); // Parse the command line, handle the default hotkeys, and show msgboxes
    DXUTSetCursorSettings( true, true ); // Show the cursor and clip it when in full screen
    DXUTCreateWindow( L"Shadow Volume Demo" );
    DXUTCreateDevice( D3DADAPTER_DEFAULT, true, g_nWindowWidth, g_nWindowHeight, IsDeviceAcceptable, ModifyDeviceSettings );

    // Start the render loop
    DXUTMainLoop();

    return DXUTGetExitCode();
}

//************************************************************
//	CODE SOURCED FROM MICROSOFT's SHADOW VOLUME DEMO
//	The following code defines an algorithm to take a normal D3DXMESH
//	and define another mesh that can be extruded along the edges without
//	tearing holes in the mesh. It is used for extruding shadow volumes from
//	a light source.
//************************************************************

#define ADJACENCY_EPSILON 0.0001f
#define EXTRUDE_EPSILON 0.1f
#define AMBIENT 0.10f

struct SHADOWVERT
{
    D3DXVECTOR3 Position;
    D3DXVECTOR3 Normal;

    const static D3DVERTEXELEMENT9 Decl[3];
};

const D3DVERTEXELEMENT9 SHADOWVERT::Decl[3] =
{
    { 0, 0,  D3DDECLTYPE_FLOAT3, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_POSITION, 0 },
    { 0, 12, D3DDECLTYPE_FLOAT3, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_NORMAL,   0 },
    D3DDECL_END()
};

struct CEdgeMapping
{
    int m_anOldEdge[2];  // vertex index of the original edge
    int m_aanNewEdge[2][2]; // vertex indexes of the new edge
                            // First subscript = index of the new edge
                            // Second subscript = index of the vertex for the edge

public:
    CEdgeMapping()
    {
        FillMemory( m_anOldEdge, sizeof(m_anOldEdge), -1 );
        FillMemory( m_aanNewEdge, sizeof(m_aanNewEdge), -1 );
    }
};

//--------------------------------------------------------------------------------------
// Takes an array of CEdgeMapping objects, then returns an index for the edge in the
// table if such entry exists, or returns an index at which a new entry for the edge
// can be written.
// nV1 and nV2 are the vertex indexes for the old edge.
// nCount is the number of elements in the array.
// The function returns -1 if an available entry cannot be found.  In reality,
// this should never happens as we should have allocated enough memory.
int FindEdgeInMappingTable( int nV1, int nV2, CEdgeMapping *pMapping, int nCount )
{
    for( int i = 0; i < nCount; ++i )
    {
        // If both vertex indexes of the old edge in mapping entry are -1, then
        // we have searched every valid entry without finding a match.  Return
        // this index as a newly created entry.
        if( ( pMapping[i].m_anOldEdge[0] == -1 && pMapping[i].m_anOldEdge[1] == -1 ) ||

            // Or if we find a match, return the index.
            ( pMapping[i].m_anOldEdge[1] == nV1 && pMapping[i].m_anOldEdge[0] == nV2 ) )
        {
            return i;
        }
    }

    return -1;  // We should never reach this line
}


//--------------------------------------------------------------------------------------
// Takes a mesh and generate a new mesh from it that contains the degenerate invisible
// quads for shadow volume extrusion.
HRESULT GenerateShadowMesh( IDirect3DDevice9 *pd3dDevice, ID3DXMesh *pMesh, ID3DXMesh **ppOutMesh )
{
    HRESULT hr = S_OK;
    ID3DXMesh *pInputMesh;

    if( !ppOutMesh )
        return E_INVALIDARG;
    *ppOutMesh = NULL;

    // Convert the input mesh to a format same as the output mesh using 32-bit index.
    hr = pMesh->CloneMesh( D3DXMESH_32BIT, SHADOWVERT::Decl, pd3dDevice, &pInputMesh );
    if( FAILED( hr ) )
        return hr;

    DXUTTRACE( L"Input mesh has %u vertices, %u faces\n", pInputMesh->GetNumVertices(), pInputMesh->GetNumFaces() );

    // Generate adjacency information
    DWORD *pdwAdj = new DWORD[3 * pInputMesh->GetNumFaces()];
    DWORD *pdwPtRep = new DWORD[pInputMesh->GetNumVertices()];
    if( !pdwAdj || !pdwPtRep )
    {
        delete[] pdwAdj; delete[] pdwPtRep;
        pInputMesh->Release();
        return E_OUTOFMEMORY;
    }

    hr = pInputMesh->GenerateAdjacency( ADJACENCY_EPSILON, pdwAdj );
    if( FAILED( hr ) )
    {
        delete[] pdwAdj; delete[] pdwPtRep;
        pInputMesh->Release();
        return hr;
    }

    pInputMesh->ConvertAdjacencyToPointReps( pdwAdj, pdwPtRep );
    delete[] pdwAdj;

    SHADOWVERT *pVBData = NULL;
    DWORD *pdwIBData = NULL;

    pInputMesh->LockVertexBuffer( 0, (LPVOID*)&pVBData );
    pInputMesh->LockIndexBuffer( 0, (LPVOID*)&pdwIBData );

    if( pVBData && pdwIBData )
    {
        // Maximum number of unique edges = Number of faces * 3
        DWORD dwNumEdges = pInputMesh->GetNumFaces() * 3;
        CEdgeMapping *pMapping = new CEdgeMapping[dwNumEdges];
        if( pMapping )
        {
            int nNumMaps = 0;  // Number of entries that exist in pMapping

            // Create a new mesh
            ID3DXMesh *pNewMesh;
            hr = D3DXCreateMesh( pInputMesh->GetNumFaces() + dwNumEdges * 2,
                                 pInputMesh->GetNumFaces() * 3,
                                 D3DXMESH_32BIT,
                                 SHADOWVERT::Decl,
                                 pd3dDevice,
                                 &pNewMesh );
            if( SUCCEEDED( hr ) )
            {
                SHADOWVERT *pNewVBData = NULL;
                DWORD *pdwNewIBData = NULL;

                pNewMesh->LockVertexBuffer( 0, (LPVOID*)&pNewVBData );
                pNewMesh->LockIndexBuffer( 0, (LPVOID*)&pdwNewIBData );

                // nNextIndex is the array index in IB that the next vertex index value
                // will be store at.
                int nNextIndex = 0;

                if( pNewVBData && pdwNewIBData )
                {
                    ZeroMemory( pNewVBData, pNewMesh->GetNumVertices() * pNewMesh->GetNumBytesPerVertex() );
                    ZeroMemory( pdwNewIBData, sizeof(DWORD) * pNewMesh->GetNumFaces() * 3 );

                    // pNextOutVertex is the location to write the next
                    // vertex to.
                    SHADOWVERT *pNextOutVertex = pNewVBData;

                    // Iterate through the faces.  For each face, output new
                    // vertices and face in the new mesh, and write its edges
                    // to the mapping table.

                    for( UINT f = 0; f < pInputMesh->GetNumFaces(); ++f )
                    {
                        // Copy the vertex data for all 3 vertices
                        CopyMemory( pNextOutVertex, pVBData + pdwIBData[f * 3], sizeof(SHADOWVERT) );
                        CopyMemory( pNextOutVertex + 1, pVBData + pdwIBData[f * 3 + 1], sizeof(SHADOWVERT) );
                        CopyMemory( pNextOutVertex + 2, pVBData + pdwIBData[f * 3 + 2], sizeof(SHADOWVERT) );

                        // Write out the face
                        pdwNewIBData[nNextIndex++] = f * 3;
                        pdwNewIBData[nNextIndex++] = f * 3 + 1;
                        pdwNewIBData[nNextIndex++] = f * 3 + 2;

                        // Compute the face normal and assign it to
                        // the normals of the vertices.
                        D3DXVECTOR3 v1, v2;  // v1 and v2 are the edge vectors of the face
                        D3DXVECTOR3 vNormal;
                        v1 = *(D3DXVECTOR3*)(pNextOutVertex + 1) - *(D3DXVECTOR3*)pNextOutVertex;
                        v2 = *(D3DXVECTOR3*)(pNextOutVertex + 2) - *(D3DXVECTOR3*)(pNextOutVertex + 1);
                        D3DXVec3Cross( &vNormal, &v1, &v2 );
                        D3DXVec3Normalize( &vNormal, &vNormal );

                        pNextOutVertex->Normal = vNormal;
                        (pNextOutVertex + 1)->Normal = vNormal;
                        (pNextOutVertex + 2)->Normal = vNormal;

                        pNextOutVertex += 3;

                        // Add the face's edges to the edge mapping table

                        // Edge 1
                        int nIndex;
                        int nVertIndex[3] = { pdwPtRep[pdwIBData[f * 3]],
                                              pdwPtRep[pdwIBData[f * 3 + 1]],
                                              pdwPtRep[pdwIBData[f * 3 + 2]] };
                        nIndex = FindEdgeInMappingTable( nVertIndex[0], nVertIndex[1], pMapping, dwNumEdges );

                        // If error, we are not able to proceed, so abort.
                        if( -1 == nIndex )
                        {
                            hr = E_INVALIDARG;
                            goto cleanup;
                        }

                        if( pMapping[nIndex].m_anOldEdge[0] == -1 && pMapping[nIndex].m_anOldEdge[1] == -1 )
                        {
                            // No entry for this edge yet.  Initialize one.
                            pMapping[nIndex].m_anOldEdge[0] = nVertIndex[0];
                            pMapping[nIndex].m_anOldEdge[1] = nVertIndex[1];
                            pMapping[nIndex].m_aanNewEdge[0][0] = f * 3;
                            pMapping[nIndex].m_aanNewEdge[0][1] = f * 3 + 1;

                            ++nNumMaps;
                        } else
                        {
                            // An entry is found for this edge.  Create
                            // a quad and output it.
                            assert( nNumMaps > 0 );

                            pMapping[nIndex].m_aanNewEdge[1][0] = f * 3;      // For clarity
                            pMapping[nIndex].m_aanNewEdge[1][1] = f * 3 + 1;

                            // First triangle
                            pdwNewIBData[nNextIndex++] = pMapping[nIndex].m_aanNewEdge[0][1];
                            pdwNewIBData[nNextIndex++] = pMapping[nIndex].m_aanNewEdge[0][0];
                            pdwNewIBData[nNextIndex++] = pMapping[nIndex].m_aanNewEdge[1][0];

                            // Second triangle
                            pdwNewIBData[nNextIndex++] = pMapping[nIndex].m_aanNewEdge[1][1];
                            pdwNewIBData[nNextIndex++] = pMapping[nIndex].m_aanNewEdge[1][0];
                            pdwNewIBData[nNextIndex++] = pMapping[nIndex].m_aanNewEdge[0][0];

                            // pMapping[nIndex] is no longer needed. Copy the last map entry
                            // over and decrement the map count.

                            pMapping[nIndex] = pMapping[nNumMaps-1];
                            FillMemory( &pMapping[nNumMaps-1], sizeof( pMapping[nNumMaps-1] ), 0xFF );
                            --nNumMaps;
                        }

                        // Edge 2
                        nIndex = FindEdgeInMappingTable( nVertIndex[1], nVertIndex[2], pMapping, dwNumEdges );

                        // If error, we are not able to proceed, so abort.
                        if( -1 == nIndex )
                        {
                            hr = E_INVALIDARG;
                            goto cleanup;
                        }

                        if( pMapping[nIndex].m_anOldEdge[0] == -1 && pMapping[nIndex].m_anOldEdge[1] == -1 )
                        {
                            pMapping[nIndex].m_anOldEdge[0] = nVertIndex[1];
                            pMapping[nIndex].m_anOldEdge[1] = nVertIndex[2];
                            pMapping[nIndex].m_aanNewEdge[0][0] = f * 3 + 1;
                            pMapping[nIndex].m_aanNewEdge[0][1] = f * 3 + 2;

                            ++nNumMaps;
                        } else
                        {
                            // An entry is found for this edge.  Create
                            // a quad and output it.
                            assert( nNumMaps > 0 );

                            pMapping[nIndex].m_aanNewEdge[1][0] = f * 3 + 1;
                            pMapping[nIndex].m_aanNewEdge[1][1] = f * 3 + 2;

                            // First triangle
                            pdwNewIBData[nNextIndex++] = pMapping[nIndex].m_aanNewEdge[0][1];
                            pdwNewIBData[nNextIndex++] = pMapping[nIndex].m_aanNewEdge[0][0];
                            pdwNewIBData[nNextIndex++] = pMapping[nIndex].m_aanNewEdge[1][0];

                            // Second triangle
                            pdwNewIBData[nNextIndex++] = pMapping[nIndex].m_aanNewEdge[1][1];
                            pdwNewIBData[nNextIndex++] = pMapping[nIndex].m_aanNewEdge[1][0];
                            pdwNewIBData[nNextIndex++] = pMapping[nIndex].m_aanNewEdge[0][0];

                            // pMapping[nIndex] is no longer needed. Copy the last map entry
                            // over and decrement the map count.

                            pMapping[nIndex] = pMapping[nNumMaps-1];
                            FillMemory( &pMapping[nNumMaps-1], sizeof( pMapping[nNumMaps-1] ), 0xFF );
                            --nNumMaps;
                        }

                        // Edge 3
                        nIndex = FindEdgeInMappingTable( nVertIndex[2], nVertIndex[0], pMapping, dwNumEdges );

                        // If error, we are not able to proceed, so abort.
                        if( -1 == nIndex )
                        {
                            hr = E_INVALIDARG;
                            goto cleanup;
                        }

                        if( pMapping[nIndex].m_anOldEdge[0] == -1 && pMapping[nIndex].m_anOldEdge[1] == -1 )
                        {
                            pMapping[nIndex].m_anOldEdge[0] = nVertIndex[2];
                            pMapping[nIndex].m_anOldEdge[1] = nVertIndex[0];
                            pMapping[nIndex].m_aanNewEdge[0][0] = f * 3 + 2;
                            pMapping[nIndex].m_aanNewEdge[0][1] = f * 3;

                            ++nNumMaps;
                        } else
                        {
                            // An entry is found for this edge.  Create
                            // a quad and output it.
                            assert( nNumMaps > 0 );

                            pMapping[nIndex].m_aanNewEdge[1][0] = f * 3 + 2;
                            pMapping[nIndex].m_aanNewEdge[1][1] = f * 3;

                            // First triangle
                            pdwNewIBData[nNextIndex++] = pMapping[nIndex].m_aanNewEdge[0][1];
                            pdwNewIBData[nNextIndex++] = pMapping[nIndex].m_aanNewEdge[0][0];
                            pdwNewIBData[nNextIndex++] = pMapping[nIndex].m_aanNewEdge[1][0];

                            // Second triangle
                            pdwNewIBData[nNextIndex++] = pMapping[nIndex].m_aanNewEdge[1][1];
                            pdwNewIBData[nNextIndex++] = pMapping[nIndex].m_aanNewEdge[1][0];
                            pdwNewIBData[nNextIndex++] = pMapping[nIndex].m_aanNewEdge[0][0];

                            // pMapping[nIndex] is no longer needed. Copy the last map entry
                            // over and decrement the map count.

                            pMapping[nIndex] = pMapping[nNumMaps-1];
                            FillMemory( &pMapping[nNumMaps-1], sizeof( pMapping[nNumMaps-1] ), 0xFF );
                            --nNumMaps;
                        }
                    }

                    // Now the entries in the edge mapping table represent
                    // non-shared edges.  What they mean is that the original
                    // mesh has openings (holes), so we attempt to patch them.
                    // First we need to recreate our mesh with a larger vertex
                    // and index buffers so the patching geometry could fit.

                    DXUTTRACE( L"Faces to patch: %d\n", nNumMaps );

                    // Create a mesh with large enough vertex and
                    // index buffers.

                    SHADOWVERT *pPatchVBData = NULL;
                    DWORD *pdwPatchIBData = NULL;

                    ID3DXMesh *pPatchMesh = NULL;
                    // Make enough room in IB for the face and up to 3 quads for each patching face
                    hr = D3DXCreateMesh( nNextIndex / 3 + nNumMaps * 7,
                                         ( pInputMesh->GetNumFaces() + nNumMaps ) * 3,
                                         D3DXMESH_32BIT,
                                         SHADOWVERT::Decl,
                                         pd3dDevice,
                                         &pPatchMesh );

                    if( FAILED( hr ) )
                        goto cleanup;

                    hr = pPatchMesh->LockVertexBuffer( 0, (LPVOID*)&pPatchVBData );
                    if( SUCCEEDED( hr ) )
                        hr = pPatchMesh->LockIndexBuffer( 0, (LPVOID*)&pdwPatchIBData );

                    if( pPatchVBData && pdwPatchIBData )
                    {
                        ZeroMemory( pPatchVBData, sizeof(SHADOWVERT) * ( pInputMesh->GetNumFaces() + nNumMaps ) * 3 );
                        ZeroMemory( pdwPatchIBData, sizeof(DWORD) * ( nNextIndex + 3 * nNumMaps * 7 ) );

                        // Copy the data from one mesh to the other

                        CopyMemory( pPatchVBData, pNewVBData, sizeof(SHADOWVERT) * pInputMesh->GetNumFaces() * 3 );
                        CopyMemory( pdwPatchIBData, pdwNewIBData, sizeof(DWORD) * nNextIndex );
                    } else
                    {
                        // Some serious error is preventing us from locking.
                        // Abort and return error.

                        pPatchMesh->Release();
                        goto cleanup;
                    }

                    // Replace pNewMesh with the updated one.  Then the code
                    // can continue working with the pNewMesh pointer.

                    pNewMesh->UnlockVertexBuffer();
                    pNewMesh->UnlockIndexBuffer();
                    pNewVBData = pPatchVBData;
                    pdwNewIBData = pdwPatchIBData;
                    pNewMesh->Release();
                    pNewMesh = pPatchMesh;

                    // Now, we iterate through the edge mapping table and
                    // for each shared edge, we generate a quad.
                    // For each non-shared edge, we patch the opening
                    // with new faces.

                    // nNextVertex is the index of the next vertex.
                    int nNextVertex = pInputMesh->GetNumFaces() * 3;

                    for( int i = 0; i < nNumMaps; ++i )
                    {
                        if( pMapping[i].m_anOldEdge[0] != -1 &&
                            pMapping[i].m_anOldEdge[1] != -1 )
                        {
                            // If the 2nd new edge indexes is -1,
                            // this edge is a non-shared one.
                            // We patch the opening by creating new
                            // faces.
                            if( pMapping[i].m_aanNewEdge[1][0] == -1 ||  // must have only one new edge
                                pMapping[i].m_aanNewEdge[1][1] == -1 )
                            {
                                // Find another non-shared edge that
                                // shares a vertex with the current edge.
                                for( int i2 = i + 1; i2 < nNumMaps; ++i2 )
                                {
                                    if( pMapping[i2].m_anOldEdge[0] != -1 &&       // must have a valid old edge
                                        pMapping[i2].m_anOldEdge[1] != -1 &&
                                        ( pMapping[i2].m_aanNewEdge[1][0] == -1 || // must have only one new edge
                                        pMapping[i2].m_aanNewEdge[1][1] == -1 ) )
                                    {
                                        int nVertShared = 0;
                                        if( pMapping[i2].m_anOldEdge[0] == pMapping[i].m_anOldEdge[1] )
                                            ++nVertShared;
                                        if( pMapping[i2].m_anOldEdge[1] == pMapping[i].m_anOldEdge[0] )
                                            ++nVertShared;

                                        if( 2 == nVertShared )
                                        {
                                            // These are the last two edges of this particular
                                            // opening. Mark this edge as shared so that a degenerate
                                            // quad can be created for it.

                                            pMapping[i2].m_aanNewEdge[1][0] = pMapping[i].m_aanNewEdge[0][0];
                                            pMapping[i2].m_aanNewEdge[1][1] = pMapping[i].m_aanNewEdge[0][1];
                                            break;
                                        }
                                        else
                                        if( 1 == nVertShared )
                                        {
                                            // nBefore and nAfter tell us which edge comes before the other.
                                            int nBefore, nAfter;
                                            if( pMapping[i2].m_anOldEdge[0] == pMapping[i].m_anOldEdge[1] )
                                            {
                                                nBefore = i;
                                                nAfter = i2;
                                            } else
                                            {
                                                nBefore = i2;
                                                nAfter = i;
                                            }

                                            // Found such an edge. Now create a face along with two
                                            // degenerate quads from these two edges.

                                            pNewVBData[nNextVertex] = pNewVBData[pMapping[nAfter].m_aanNewEdge[0][1]];
                                            pNewVBData[nNextVertex+1] = pNewVBData[pMapping[nBefore].m_aanNewEdge[0][1]];
                                            pNewVBData[nNextVertex+2] = pNewVBData[pMapping[nBefore].m_aanNewEdge[0][0]];
                                            // Recompute the normal
                                            D3DXVECTOR3 v1 = pNewVBData[nNextVertex+1].Position - pNewVBData[nNextVertex].Position;
                                            D3DXVECTOR3 v2 = pNewVBData[nNextVertex+2].Position - pNewVBData[nNextVertex+1].Position;
                                            D3DXVec3Normalize( &v1, &v1 );
                                            D3DXVec3Normalize( &v2, &v2 );
                                            D3DXVec3Cross( &pNewVBData[nNextVertex].Normal, &v1, &v2 );
                                            pNewVBData[nNextVertex+1].Normal = pNewVBData[nNextVertex+2].Normal = pNewVBData[nNextVertex].Normal;

                                            pdwNewIBData[nNextIndex] = nNextVertex;
                                            pdwNewIBData[nNextIndex+1] = nNextVertex + 1;
                                            pdwNewIBData[nNextIndex+2] = nNextVertex + 2;

                                            // 1st quad

                                            pdwNewIBData[nNextIndex+3] = pMapping[nBefore].m_aanNewEdge[0][1];
                                            pdwNewIBData[nNextIndex+4] = pMapping[nBefore].m_aanNewEdge[0][0];
                                            pdwNewIBData[nNextIndex+5] = nNextVertex + 1;

                                            pdwNewIBData[nNextIndex+6] = nNextVertex + 2;
                                            pdwNewIBData[nNextIndex+7] = nNextVertex + 1;
                                            pdwNewIBData[nNextIndex+8] = pMapping[nBefore].m_aanNewEdge[0][0];

                                            // 2nd quad

                                            pdwNewIBData[nNextIndex+9] = pMapping[nAfter].m_aanNewEdge[0][1];
                                            pdwNewIBData[nNextIndex+10] = pMapping[nAfter].m_aanNewEdge[0][0];
                                            pdwNewIBData[nNextIndex+11] = nNextVertex;

                                            pdwNewIBData[nNextIndex+12] = nNextVertex + 1;
                                            pdwNewIBData[nNextIndex+13] = nNextVertex;
                                            pdwNewIBData[nNextIndex+14] = pMapping[nAfter].m_aanNewEdge[0][0];

                                            // Modify mapping entry i2 to reflect the third edge
                                            // of the newly added face.

                                            if( pMapping[i2].m_anOldEdge[0] == pMapping[i].m_anOldEdge[1] )
                                            {
                                                pMapping[i2].m_anOldEdge[0] = pMapping[i].m_anOldEdge[0];
                                            } else
                                            {
                                                pMapping[i2].m_anOldEdge[1] = pMapping[i].m_anOldEdge[1];
                                            }
                                            pMapping[i2].m_aanNewEdge[0][0] = nNextVertex + 2;
                                            pMapping[i2].m_aanNewEdge[0][1] = nNextVertex;

                                            // Update next vertex/index positions

                                            nNextVertex += 3;
                                            nNextIndex += 15;

                                            break;
                                        }
                                    }
                                }
                            } else
                            {
                                // This is a shared edge.  Create the degenerate quad.

                                // First triangle
                                pdwNewIBData[nNextIndex++] = pMapping[i].m_aanNewEdge[0][1];
                                pdwNewIBData[nNextIndex++] = pMapping[i].m_aanNewEdge[0][0];
                                pdwNewIBData[nNextIndex++] = pMapping[i].m_aanNewEdge[1][0];

                                // Second triangle
                                pdwNewIBData[nNextIndex++] = pMapping[i].m_aanNewEdge[1][1];
                                pdwNewIBData[nNextIndex++] = pMapping[i].m_aanNewEdge[1][0];
                                pdwNewIBData[nNextIndex++] = pMapping[i].m_aanNewEdge[0][0];
                            }
                        }
                    }
                }

cleanup:;
                if( pNewVBData )
                {
                    pNewMesh->UnlockVertexBuffer();
                    pNewVBData = NULL;
                }
                if( pdwNewIBData )
                {
                    pNewMesh->UnlockIndexBuffer();
                    pdwNewIBData = NULL;
                }

                if( SUCCEEDED( hr ) )
                {
                    // At this time, the output mesh may have an index buffer
                    // bigger than what is actually needed, so we create yet
                    // another mesh with the exact IB size that we need and
                    // output it.  This mesh also uses 16-bit index if
                    // 32-bit is not necessary.

                    DXUTTRACE( L"Shadow volume has %u vertices, %u faces.\n", ( pInputMesh->GetNumFaces() + nNumMaps ) * 3, nNextIndex / 3 );

                    bool bNeed32Bit = ( pInputMesh->GetNumFaces() + nNumMaps ) * 3 > 65535;
                    ID3DXMesh *pFinalMesh;
                    hr = D3DXCreateMesh( nNextIndex / 3,  // Exact number of faces
                                         ( pInputMesh->GetNumFaces() + nNumMaps ) * 3,
                                         D3DXMESH_WRITEONLY | ( bNeed32Bit ? D3DXMESH_32BIT : 0 ),
                                         SHADOWVERT::Decl,
                                         pd3dDevice,
                                         &pFinalMesh );
                    if( SUCCEEDED( hr ) )
                    {
                        pNewMesh->LockVertexBuffer( 0, (LPVOID*)&pNewVBData );
                        pNewMesh->LockIndexBuffer( 0, (LPVOID*)&pdwNewIBData );

                        SHADOWVERT *pFinalVBData = NULL;
                        WORD *pwFinalIBData = NULL;

                        pFinalMesh->LockVertexBuffer( 0, (LPVOID*)&pFinalVBData );
                        pFinalMesh->LockIndexBuffer( 0, (LPVOID*)&pwFinalIBData );

                        if( pNewVBData && pdwNewIBData && pFinalVBData && pwFinalIBData )
                        {
                            CopyMemory( pFinalVBData, pNewVBData, sizeof(SHADOWVERT) * ( pInputMesh->GetNumFaces() + nNumMaps ) * 3 );

                            if( bNeed32Bit )
                                CopyMemory( pwFinalIBData, pdwNewIBData, sizeof(DWORD) * nNextIndex );
                            else
                            {
                                for( int i = 0; i < nNextIndex; ++i )
                                    pwFinalIBData[i] = (WORD)pdwNewIBData[i];
                            }
                        }

                        if( pNewVBData )
                            pNewMesh->UnlockVertexBuffer();
                        if( pdwNewIBData )
                            pNewMesh->UnlockIndexBuffer();
                        if( pFinalVBData )
                            pFinalMesh->UnlockVertexBuffer();
                        if( pwFinalIBData )
                            pFinalMesh->UnlockIndexBuffer();

                        // Release the old
                        pNewMesh->Release();
                        pNewMesh = pFinalMesh;
                    }

                    *ppOutMesh = pNewMesh;
                }
                else
                    pNewMesh->Release();
            }
            delete[] pMapping;
        } else
            hr = E_OUTOFMEMORY;
    } else
        hr = E_FAIL;

    if( pVBData )
        pInputMesh->UnlockVertexBuffer();

    if( pdwIBData )
        pInputMesh->UnlockIndexBuffer();

    delete[] pdwPtRep;
    pInputMesh->Release();

    return hr;
}

//*********************************************
//	END OF MICROSOFT's CODE
//*********************************************